<?php
    //Database Parameters
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_NAME', 'arthevents');
    //App Root
    define('APPROOT', dirname(dirname(__FILE__)));
    //Public Root
    define('PUBLICROOT', dirname(dirname(dirname(__FILE__)))."/public");
    //URL Root
    define('URLROOT', 'http://localhost/arthevents');
    //Site Name
    define('SITENAME', 'ArthEvents');