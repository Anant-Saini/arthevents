<?php
    //Load Config Class
    require_once('config/config.php');
    require_once('helpers/redirect_helper.php');
    require_once('helpers/session_helper.php');
    require_once('helpers/isLoggedIn_helper.php');
    require_once('helpers/isAdminLoggedIn_helper.php');
    require_once('helpers/isNull_helper.php');
    require_once('helpers/testInput_helper.php');
    //Load Libraries Classes (One by One)
    // require_once('libraries/Core.php');
    // require_once('libraries/Controller.php');
    // require_once('libraries/Database.php');
    //Autoload All Libraries Classes {Note: File name must match Class name}
    spl_autoload_register(function($classname) {
        require_once('libraries/'. $classname .'.php');
    });