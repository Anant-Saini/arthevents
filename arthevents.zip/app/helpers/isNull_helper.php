<?php
    /* This function return 'Not Available' string if variable passed is null otherwise return the variable itself which is passed */
    function isNull($variable) {
        if(is_null($variable)) {
            return 'Not Available';
        } else {
            return $variable;
        }
    }
