<?php
    session_start();
    //Flash Message Helper
    /* EXAMPLE - flash('register_success', 'You are registered');
       DISPLAY IN VIEW- <?php flash('register_unsuccess', 'try again', 'alert alert-danger'); ?>  */
    function flash($name, $message = '', $class = 'alert alert-success') {
        if(!empty($name)) {
            if(!empty($message)) {
                //Case of setting message
                if(!empty($_SESSION[$name])) {
                    unset($_SESSION[$name]);
                    unset($_SESSION[$name.'_class']);
                }
                if( empty($_SESSION[$name]) ) {
                    $_SESSION[$name] = $message;
                    $_SESSION[$name.'_class'] = $class;
                }
            } elseif (empty($message) && !empty($_SESSION[$name]) ) {
                $class = !empty($_SESSION[$name.'_class']) ? $_SESSION[$name.'_class'] : 'alert';
                echo '<div class="row '. $class .'" id="flash-msg" ><div class="col s8" >'. $_SESSION[$name] .'</div><a class="col s4 right white-text" href="#"><i class="material-icons">close</i></a></div>';
                unset($_SESSION[$name]);
                unset($_SESSION[$name.'_class']); 
            }
        }
    }