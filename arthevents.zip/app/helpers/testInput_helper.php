<?php
  /*Test Input For Extra Spaces, HTML or Javascript Script and splashes to prevent SQL injection attacks */
  function testInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }