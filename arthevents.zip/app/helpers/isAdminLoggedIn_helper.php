<?php
  //Return true if user is logged in or else false
  function isAdminLoggedIn() {
    if( isset($_SESSION['admin_email']) ) {
      return true;
    } else {
      return false;
    }
  }