<?php
    //here is a redirect function to help us
    function redirect($url) {
        header('Location: '.URLROOT.'/'.$url);
    }