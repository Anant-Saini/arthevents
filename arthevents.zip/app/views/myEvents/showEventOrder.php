<?php require(APPROOT.'/views/inc/header.php'); ?>
  <section class="section">
  <div class="container">
    <div class="row">
      <div class="col s12">
        <div class="card-panel blue lighten-5 center">
          <div class="row">
            <div class="col s12">
              <!--Horizontal Card For Large Screens -->
              <div class="card small horizontal hide-on-med-and-down hoverable">
                <div class="card-image">
                  <img src="<?php echo URLROOT; ?>/public/img/eventTypeImgs/<?php echo $data['eventOrder']->img_path; ?>" class="responsive-img">
                </div>
                <div class="card-stacked">
                  <div class="card-content">
                    <div class="row">
                      <div class="col s6">
                        <div class="row">
                          <div class="input-field col s12">
                            <i class="material-icons prefix">cake</i>
                            <input type="text" id="ev_name" value="<?php echo $data['eventOrder']->name; ?>" disabled class="black-text">
                            <label for="ev_name" class="active blue-text text-darken-3">Event Name</label>
                          </div>
                          <div class="input-field col s12">
                            <i class="material-icons prefix">deck</i>
                            <input type="text" id="ev_type" value="<?php echo $data['eventOrder']->et_name; ?>" disabled class="black-text">
                            <label for="ev_type" class="active blue-text text-darken-3">Event Type</label>
                          </div>
                          <div class="input-field col s12">
                            <i class="material-icons prefix">person</i>
                            <input type="text" id="ev_for" value="<?php echo $data['eventOrder']->ev_for; ?>" disabled class="black-text">
                            <label for="ev_for" class="active blue-text text-darken-3">Event For</label>
                          </div>
                        </div>
                      </div>
                      <div class="col s6">
                        <div class="row">
                          <div class="input-field col s12">
                            <i class="material-icons prefix">date_range</i>
                            <input type="text" id="ev_date" value="<?php echo $data['eventOrder']->date; ?>" disabled class="black-text">
                            <label for="ev_date" class="active blue-text text-darken-3">Date</label>
                          </div>
                          <div class="input-field col s12">
                            <i class="material-icons prefix">schedule</i>
                            <input type="text" id="ev_time" value="<?php echo $data['eventOrder']->time; ?>" disabled class="black-text">
                            <label for="ev_time" class="active blue-text text-darken-3">Time</label>
                          </div>
                          <div class="input-field col s12">
                            <i class="material-icons prefix">hourglass_bottom</i>
                            <input type="text" id="status" value="<?php echo $data['eventOrder']->ev_status; ?>" disabled class="black-text">
                            <label for="status" class="active blue-text text-darken-3">Status</label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!--Vertical Card for Med and Down Screens-->
              <div class="card small hide-on-large-only hide-on-small-only hoverable">
                <div class="card-content">
                  <div class="row">
                    <div class="col s12 m3">
                      <img src="<?php echo URLROOT; ?>/public/img/eventTypeImgs/<?php echo $data['eventOrder']->img_path; ?>" class="responsive-img">
                    </div>
                    <div class="col s12 m9">
                      <div class="row">
                        <div class="col s12 m6">
                          <div class="row">
                            <div class="input-field col s12">
                              <i class="material-icons prefix">cake</i>
                              <input type="text" id="ev_name" value="<?php echo $data['eventOrder']->name; ?>" disabled class="black-text">
                              <label for="ev_name" class="active blue-text text-darken-3">Event Name</label>
                            </div>
                            <div class="input-field col s12">
                              <i class="material-icons prefix">deck</i>
                              <input type="text" id="ev_type" value="<?php echo $data['eventOrder']->et_name; ?>" disabled class="black-text">
                              <label for="ev_type" class="active blue-text text-darken-3">Event Type</label>
                            </div>
                            <div class="input-field col s12">
                              <i class="material-icons prefix">person</i>
                              <input type="text" id="ev_for" value="<?php echo $data['eventOrder']->ev_for; ?>" disabled class="black-text">
                              <label for="ev_for" class="active blue-text text-darken-3">Event For</label>
                            </div>
                          </div>
                        </div>
                        <div class="col s12 m6">
                          <div class="row">
                            <div class="input-field col s12">
                              <i class="material-icons prefix">date_range</i>
                              <input type="text" id="ev_date" value="<?php echo $data['eventOrder']->date; ?>" disabled class="black-text">
                              <label for="ev_date" class="active blue-text text-darken-3">Date</label>
                            </div>
                            <div class="input-field col s12">
                              <i class="material-icons prefix">schedule</i>
                              <input type="text" id="ev_time" value="<?php echo $data['eventOrder']->time; ?>" disabled class="black-text">
                              <label for="ev_time" class="active blue-text text-darken-3">Time</label>
                            </div>
                            <div class="input-field col s12">
                              <i class="material-icons prefix">hourglass_bottom</i>
                              <input type="text" id="status" value="<?php echo $data['eventOrder']->ev_status; ?>" disabled class="black-text">
                              <label for="status" class="active blue-text text-darken-3">Status</label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!--Vertical Card for small Screens-->
              <div class="card hide-on-med-and-up hoverable">
                <div class="card-content">
                  <div class="row">
                    <div class="col s12">
                      <img src="<?php echo URLROOT; ?>/public/img/eventTypeImgs/<?php echo $data['eventOrder']->img_path; ?>" class="" style="height:250px; width:100%;">
                    </div>
                    <div class="col s12">
                      <div class="section">
                        <div class="divider blue darken-3" style="height:8px"></div>
                      </div>
                    </div>  
                    <div class="input-field col s12">
                      <i class="material-icons prefix">cake</i>
                      <input type="text" id="ev_name" value="<?php echo $data['eventOrder']->name; ?>" disabled class="black-text">
                      <label for="ev_name" class="active blue-text text-darken-3">Event Name</label>
                    </div>
                    <div class="input-field col s12">
                      <i class="material-icons prefix">deck</i>
                      <input type="text" id="ev_type" value="<?php echo $data['eventOrder']->et_name; ?>" disabled class="black-text">
                      <label for="ev_type" class="active blue-text text-darken-3">Event Type</label>
                    </div>
                    <div class="input-field col s12">
                      <i class="material-icons prefix">person</i>
                      <input type="text" id="ev_for" value="<?php echo $data['eventOrder']->ev_for; ?>" disabled class="black-text">
                      <label for="ev_for" class="active blue-text text-darken-3">Event For</label>
                    </div>
                    <div class="input-field col s12">
                      <i class="material-icons prefix">date_range</i>
                      <input type="text" id="ev_date" value="<?php echo $data['eventOrder']->date; ?>" disabled class="black-text">
                      <label for="ev_date" class="active blue-text text-darken-3">Date</label>
                    </div>
                    <div class="input-field col s12">
                      <i class="material-icons prefix">schedule</i>
                      <input type="text" id="ev_time" value="<?php echo $data['eventOrder']->time; ?>" disabled class="black-text">
                      <label for="ev_time" class="active blue-text text-darken-3">Time</label>
                    </div>
                    <div class="input-field col s12">
                      <i class="material-icons prefix">hourglass_bottom</i>
                      <input type="text" id="status" value="<?php echo $data['eventOrder']->ev_status; ?>" disabled class="black-text">
                      <label for="status" class="active blue-text text-darken-3">Status</label>
                    </div>
                  </div>
                </div>
              </div>
              <!--Event Services Divider-->
              <section class="section blue darken-3">
                <h5 class="white-text"><strong>Event Services</strong></h5>
              </section>
              <!-- Event Products selected by Customer-->
              <ul class="collection hoverable">
                <?php foreach($data['pdObjsArr'] as $pd): ?>
                <li class="collection-item avatar">
                  <div class="row">
                    <div class="col s12 m4 l4">
                    <img src="<?php echo URLROOT; ?>/public/img/productImgs/<?php echo $pd->pd_img_path; ?>" alt="<?php echo $pd->pd_id; ?>" style="height:auto; width:100px;" class="responsive-img">
                    <h6 class="blue-text text-darken-3"><strong><?php echo $pd->name; ?></strong></h6>
                    </div>
                    <div class="col s12 m8 l8">
                      <div class="row">
                        <p class="col s12"><strong>Product Name: </strong><?php echo $pd->pd_name; ?></p>
                        <p class="col s12"><strong>Product Company: </strong><?php echo $pd->company_name; ?></p>
                        <p class="col s12"><strong>Minimum Charge: </strong>₹<?php echo $pd->price_customer; ?></p>
                      </div>
                    </div>
                  </div>
                </li>
                <?php endforeach; ?>
              </ul>
              <!-- Grand Total-->
              <section class="section blue darken-3 white-text"><strong>Grand Total</strong></section>
              <div class="input-field col s12">
                <i class="material-icons prefix">payments</i>
                <input type="text" id="ev_cost_customer" value="₹<?php echo $data['eventOrder']->ev_cost_customer; ?>" disabled class="black-text">
                <label for="ev_cost_customer" class="active"></label>
              </div>
              <!-- Delete Order-->
              <form action="<?php echo URLROOT; ?>/myEvents/deleteEventOrder/<?php echo $data['eventOrder']->ev_order_id; ?>" method="post">
              <input type="submit" class="col s12 btn waves-light red" value="Cancel">  
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
     <a class="col s12 btn waves-effect waves-light blue darken-3" href="<?php echo URLROOT; ?>/myEvents/index"><i class="material-icons left">arrow_back_ios</i> Back</a>
    </div>
  </div>
  </section>
<?php require(APPROOT.'/views/inc/footer.php'); ?>