<?php require(APPROOT.'/views/inc/header.php'); ?>
  <section class="section">
    <div class="container">
      <?php echo flash('Order Placed Success'); ?>
      <?php echo flash('Event Delete Success'); ?>
      <div class="row">
        <div class="col s12 blue darken-3">
        <h5 class="white-text center"><em>My Events</em></h5>
        </div>
      </div>
      <?php if( empty($data['eventOrderObjArr']) ): ?>
        <div class="row">
          <div class="col s12">
          <div class="card blue lighten-5">
            <div class="card-content">
              <h6 class="center">Sorry, There are no events registered on your account.</h6>
            </div> 
          </div>
          </div>
        </div>
      <?php else: ?>
      <div class="row">
        <?php foreach ($data['eventOrderObjArr'] as $eventOrder): ?>
        <div class="col s12 l6">
          <div class="card blue lighten-5">
            <div class="card-image waves-effect waves-block waves-light">
              <img src="<?php echo URLROOT; ?>/public/img/eventTypeImgs/<?php echo $eventOrder->img_path; ?>" alt="<?php echo $eventOrder->img_path; ?>" class="activator">
            </div>
            <div class="card-content">
              <span class="card-title activator blue-text text-darken-3"><strong><?php echo $eventOrder->name; ?></strong><i class="material-icons right">more_vert</i></span>
            </div>
            <div class="card-reveal blue lighten-5">
            <div class="row">  
              <div class="col s12 section">
                <span class="card-title blue-text text-darken-3"><?php echo $eventOrder->name; ?><i class="material-icons right">close</i></span>
              </div>
              <div class="input-field col s12">
                <i class="material-icons prefix">deck</i>
                <input type="text" id="ev_type" value="<?php echo $eventOrder->et_name; ?>" disabled class="black-text">
                <label for="ev_type" class="active blue-text text-darken-3">Event Type</label>
              </div>
              <div class="input-field col s12">
                <i class="material-icons prefix">person</i>
                <input type="text" id="ev_for" value="<?php echo $eventOrder->ev_for; ?>" disabled class="black-text">
                <label for="ev_for" class="active blue-text text-darken-3">Event For</label>
              </div>
              <div class="input-field col s12">
                <i class="material-icons prefix">date_range</i>
                <input type="text" id="ev_date" value="<?php echo $eventOrder->date; ?>" disabled class="black-text">
                <label for="ev_date" class="active blue-text text-darken-3">Date</label>
              </div>
              <div class="input-field col s12">
                <i class="material-icons prefix">schedule</i>
                <input type="text" id="ev_time" value="<?php echo $eventOrder->time; ?>" disabled class="black-text">
                <label for="ev_time" class="active blue-text text-darken-3">Time</label>
              </div>
              <div class="input-field col s12">
                <i class="material-icons prefix">payments</i>
                <input type="text" id="price" value="₹<?php echo $eventOrder->ev_cost_customer; ?>" disabled class="black-text">
                <label for="price" class="active blue-text text-darken-3">Price</label>
              </div>
              <div class="input-field col s12">
                <i class="material-icons prefix">hourglass_bottom</i>
                <input type="text" id="status" value="<?php echo $eventOrder->ev_status; ?>" disabled class="black-text">
                <label for="status" class="active blue-text text-darken-3">Status</label>
              </div>
            </div>
            </div>
            <div class="card-action">
              <div class="row">
                <a href="<?php echo URLROOT; ?>/myEvents/showEventOrder/<?php echo $eventOrder->ev_order_id; ?>" class="col s12 btn waves-light blue darken-3">Show</a>  
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
      <div class="row">
        <a href="<?php echo URLROOT; ?>/eventOrders" class="col s12 btn waves-effect waves-light blue darken-3">Have an event on Mind?</a>
      </div>
    </div>
  </section>
<?php require(APPROOT.'/views/inc/footer.php'); ?>