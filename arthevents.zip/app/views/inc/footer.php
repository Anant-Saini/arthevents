<!-- Footer -->
<footer class="page-footer blue darken-3">
    <div class="container">
        <div class="row">
            <div class="col s12 l6">
            <h5>Made and Designed By Anant Saini</h5>
            <p>All rights of publishing and distribution are owned by firm.</p>
            </div>
            <div class="col s12 l4 offset-l2">
            <h5>Connect</h5>
            <ul class="row">
                <li class="col s3"><a href="#" class="blue-text text-lighten-5">Facebook</a></li>
                <li class="col s3"><a href="#" class="blue-text text-lighten-5">Instagram</a></li>
                <li class="col s3"><a href="#" class="blue-text text-lighten-5">Twitter</a></li>
                <li class="col s3"><a href="#" class="blue-text text-lighten-5">Telegram</a></li>
            </ul>
            </div>
        </div>
    </div>
    <div class="footer-copyright grey darken-4">
        <div class="container center-align">&copy; 2020 ArthEvents</div>
    </div>
</footer>
<!-- Compiled and minified JavaScript of Materialize -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<!-- Custom Script Tag-->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        //Tooltipped
        const tooltippedElems = document.querySelectorAll('.tooltipped');
        M.Tooltip.init(tooltippedElems, { exitDelay: 0 });
    });
</script>
<!--Custom JS File-->
<script src="<?php echo URLROOT; ?>/public/js/main.js"></script>
</body>
</html>