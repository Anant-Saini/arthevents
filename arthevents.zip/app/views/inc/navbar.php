<div class="navbar-fixed">
<nav class="blue lighten-5">
    <div class="nav-wrapper container">
      <a href="<?php echo URLROOT; ?>/" class="brand-logo blue-text text-darken-3 flow-text">Arth Events</a>
      <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="medium material-icons grey-text text-darken-4">menu</i></a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="<?php echo URLROOT; ?>/#about" class="grey-text text-darken-4 flow-text">About</a></li>
        <li><a href="<?php echo URLROOT; ?>/#services" class="grey-text text-darken-4 flow-text">Services</a></li>
        <li><a href="<?php echo URLROOT; ?>/#contact" class="grey-text text-darken-4 flow-text">Contact Us</a></li>
        <?php if( !isLoggedIn() ): ?>
        <li><a href="<?php echo URLROOT; ?>/users/register" class="blue-text text-darken-3 flow-text">Register</a></li>
        <li><a href="<?php echo URLROOT; ?>/users/login" class="blue-text text-darken-3 flow-text">Login</a></li>
        <?php else: ?>
        <li><a href="<?php echo URLROOT; ?>/eventOrders/index" class="blue-text text-darken-3 flow-text">Conduct Event</a></li>
        <li class=""><a href="<?php echo URLROOT; ?>/userAccountSettings/index" class="blue-text text-darken-3 tooltipped" data-position="bottom" data-tooltip="Account Settings"><i class="material-icons">settings</i></a></li>
        <li class="tooltipped" data-position="bottom" data-tooltip="My Events"><a href="<?php echo URLROOT; ?>/myEvents/index" class="blue-text text-darken-3"><i class="material-icons">event</i></a></li>
        <?php endif; ?>
      </ul>
    </div>
</nav>
</div>
<!-- SideNav Content -->
<ul id="slide-out" class="sidenav blue lighten-5">
    <li><a href="<?php echo URLROOT; ?>/#about" class="grey-text text-darken-4 flow-text">About</a></li>
    <li><a href="<?php echo URLROOT; ?>/#services" class="grey-text text-darken-4 flow-text">Services</a></li>
    <li><a href="<?php echo URLROOT; ?>/#contact" class="grey-text text-darken-4 flow-text">Contact Us</a></li>
    <?php if( !isLoggedIn() ): ?>
    <li><a href="<?php echo URLROOT; ?>/users/register" class="blue-text text-darken-3 flow-text">Register</a></li>
    <li><a href="<?php echo URLROOT; ?>/users/login" class="blue-text text-darken-3 flow-text">Login</a></li>
    <?php else: ?>
    <li><a href="<?php echo URLROOT; ?>/eventOrders/index" class="blue-text text-darken-3 flow-text">Conduct Event</a></li>
    <li class="tooltipped" data-position="bottom" data-tooltip="Account Settings"><a href="<?php echo URLROOT; ?>/userAccountSettings/index" class="blue-text text-darken-3"><i class="material-icons">settings</i></a></li>
    <li class="tooltipped" data-position="bottom" data-tooltip="My Events"><a href="<?php echo URLROOT; ?>/myEvents/index" class="blue-text text-darken-3"><i class="material-icons">event</i></a></li>
    <?php endif; ?>
</ul>