<?php require(APPROOT.'/views/inc/header.php'); ?>
    <!--Flash Messages-->
    <section class="section blue darken-3">
        <div class="container">
            <div class="center white-text"><h6><em>A Leading Event Organising Firm</em></h6></div>
            <?php flash('account_delete_success'); ?>
        </div>
    </section>
    <!-- Parallax One -->
    <div class="parallax-container">
      <div class="parallax"><img src="<?php echo URLROOT; ?>/public/img/main/bachelorette.jpg"></div>
    </div>
    <!--About Us Begins Here---->
    <section id="about" class="section blue lighten-5 scrollspy">
    <div class="row container">
        <div class="col s12 l4">
            <h2 class="blue-text text-darken-3">Who are we ?</h2>
            <img src="<?php echo URLROOT; ?>/public/img/main/logo.png" alt="arthevents" class="responsive-img hide-on-med-and-down">
        </div>
        <div class="col s12 l8">
            <p class="">Arth-Events.com began in 2005. After years in the event management industry, we realized that it was near impossible for the average Rahul or Nikita to manage their own wedding fully by themselves. Traditional wedding arrangements are simply too complicated, time consuming, and expensive to manage.</p>
            <p class="">We created the Arth-Events.com with the client's perspective in mind. We wanted to offer a platform that would require no brokers, no more headaches, no more tantrums of catterers and decorators. We keep it simple, so that our client can get his dream-wedding or dream-birthday-party just by telling us whatever he/she wants. It is us who work hard day and night to make your event happen on the scheduled date and time. All you need to do is either select our pre-decided bundles for various events or you can customise your own bundle according to your event's need!</p>
            <p class="">Today, we're proud that we have successfully fullfilled dreams of hundreds people around the world whether it is a bachelorette party in Bankok or a wedding in Italy. We believe everyone deserves atleast one wonderful and memorable event in their whole life.</p>
        </div>
    </div>
    </section>
    <!--Parallax Two-->
    <div class="parallax-container">
        <div class="parallax"><img src="<?php echo URLROOT; ?>/public/img/main/white-wedding.jpg"></div>
    </div>
    <!-- Values -->
    <section class="section blue lighten-5" id="values">
        <div class="row container">
            <div class="col s12 l4">
                <h2 class="blue-text text-darken-3">Our Values</h2>
                <img src="<?php echo URLROOT; ?>/public/img/main/values.jpg" alt="our_values" class="responsive-img circle hide-on-med-and-down">
            </div>
            <div class="col s12 l6 offset-l2">
                <ul class="collapsible">
                    <li>
                        <div class="collapsible-header blue-text text-darken-3">
                            <div class="col s3"><i class="material-icons">favorite_border</i></div>
                            <div class="col s9">Every Individual Deserves a Memorable Event</div>
                        </div>
                        <div class="collapsible-body"><span>We believe every individual should have the power of conducting a party or wedding or baby-showers or any other events which they have desired. If you can point and click, you can throw a wonderful party anytime anywhere you want by placing an order through our website with the help of customisable bundles for every event you have thought of.</span>
                        </div>
                    </li>
                    <li>
                        <div class="collapsible-header blue-text text-darken-3">
                            <div class="col s3"><i class="material-icons">face</i></div>
                            <div class="col s9">Our Customers Mean the World</div>
                        </div>
                        <div class="collapsible-body"><span>At Arth-Events.com, we strive to provide exactly what our customers are looking for. A huge part of our brainstorming process is looking at our client feedback to make sure you're well taken care of.</span>
                        </div>
                    </li>
                    <li>
                        <div class="collapsible-header blue-text text-darken-3">
                            <div class="col s3"><i class="material-icons">high_quality</i></div>
                            <div class="col s9">In-House Made</div>
                        </div>
                        <div class="collapsible-body"><span>We are personally committed to delivering the very best. Everything, from customer support to event planning and organizing, is done by our dedicated (and adorable) team in Delhi, India.</span>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </section>
    <!-- Divider Black -->
    <div class="divider black"></div>
    <!-- Services Tab -->
    <section class="section blue lighten-5 scrollspy" id="services">
    <div class="row container">
        <div class="col s12 l4">
            <h2 class="blue-text text-darken-3">Services</h2>
            <p>Don't worry if you are planning a destination wedding and don't know whether your guests will make it to the venue or not. Or you may just want vehicle services from your home to event venue. We offer it all and that also at a very reasonable cost. We understand your needs and thus plan transportation in advance.</p>
            <p>Moreover, you can book entire flight or railway coaches with us for your guests.</p>
        </div>
        <div class="col s12 l6 offset-l2">
            <ul class="tabs">
                <li class="tab col s3">
                <a href="#test1" class="active blue-text text-darken-3">Catering</a>
                </li>
                <li class="tab col s3">
                <a href="#test2" class="blue-text text-darken-3">Venue</a>
                </li>
                <li class="tab col s3">
                <a href="#test3" class="blue-text text-darken-3">Decorations</a>
                </li>
                <li class="tab col s3">
                <a href="#test4" class="blue-text text-darken-3">Transportation</a>
                </li>
            </ul>
            <div id="test1" class="col s12">
            <p class="blue-text flow-text text-darken-3">Catering</p>
            <p>We offer our clients the best possible cattering service according to their budget. We outsource services from world class chefs and caterers. Food taste and quality are our top most priority and we are not ready to compromise on it a little bit. The wide range of food items and excellent serving facilities is what makes our caterering experience different from others. All our staff from top chefs to waiters are trained from reputed Hotel Management institutes thus making them expert of this field.</p>
            </div>
            <div id="test2" class="col s12">
            <p class="blue-text flow-text text-darken-3">Venue</p>
            <p>Whether you want a grand hotel or a destination wedding or it may be a farmhouse, we have it all in our store. We provide best in class accomodation to all your guest and family members. From tent facility in farmhouse to managing guest affairs we have it all covered. We offer wide selection of event venues which include locations in city as well as locations in countryside. Whether you want a small get-together or a large extravagant wedding, we have a location in mind. Don't worry about the cost because we have options for every class of our society.</p>
            </div>
            <div id="test3" class="col s12">
            <p class="blue-text flow-text text-darken-3">Decorations</p>
            <p>Generally, this is the most overlooked part of an event but with Arth Events, you get world class decoration practices in your event. We are the people who genuinely care for the looks of your event and want each visitor to compliment for its decoration. We keep on experimenting and always try to bring latest trending decoration designs in your event. Don't worry if you have a theme in mind or you want to customize your decoration because as we have told you before we make your dreams come true. Just tell us what you have in your mind we'll make it happen.</p>
            </div>
            <div id="test4" class="col s12">
            <p class="flow-text blue-text text-darken-3">Transportation</p>
            <p>Now comes the main part whether it is cake cutting ceremony, mandap ceremony for wedding, games for bachelorette party or anchoring for any other event. We specialize in all these activities and ensure best possible experience for you and your audience. We have priests for all kind of wedding events and experienced hosts so that your event can provide non-stop entertainment for its attendies. All which is required from your side is list of guests and a mood for hospitality.</p>
            </div>
        </div>
    </div>
    </section>
    <!--Contact Form -->
    <section class="section scrollspy" id="contact">
    <div class="row container">
        <div class="col s12 l5">
            <h2 class="blue-text text-darken-3">Get in Touch</h2>
            <h4 class="blue-text text-darken-3">Email</h4>
			<p>Send us email <a href="mailto:arthevents@gmail.com" class="blue-text text-darken-2">arthevents@gmail.com</a></p>
			<h4 class="blue-text text-darken-3">Phone Number</h4>
			<p>+91 9458251057, +91 9837775700</p>
			<h4 class="blue-text text-darken-3">Address</h4>
			<p><strong>House Number</strong> B-4, Laxmanpuram Colony near Transport Nagar, Dehradun Road, Saharanpur (247001), Uttar Pradesh, India</p>
        </div>
        <div class="col s12 l5 offset-l2">
            <form action="">
                <div class="input-field blue-text text-darken-3">
                <i class="material-icons prefix">account_box</i>
                <input type="text" name="name" id="name">
                <label for="email">Your Name</label>
                </div>
                <div class="input-field blue-text text-darken-3">
                <i class="material-icons prefix">email</i>
                <input type="email" name="email" id="email">
                <label for="email">Your Email</label>
                </div>
                <div class="input-field blue-text text-darken-3">
                <i class="material-icons prefix">message</i>
                <textarea name="message" id="message" class="materialize-textarea"></textarea>
                <label for="message">Your Message</label>
                </div>
                <div class="input-field center">
                    <button class="btn waves-effect waves-light blue darken-3" type="submit">Send <i class="material-icons right">send</i></button>
                </div>
            </form>
        </div>
    </div>
    </section>
<?php require(APPROOT.'/views/inc/footer.php'); ?>