<?php require(APPROOT.'/views/dashboard/inc/header.php'); ?>
<!--Page Title Section-->
<section class="blue lighten-5">
  <div class="container">
    <div class="row">
      <div class="col s12">
        <h4 class="blue-text text-darken-3"><i class="fa fa-lg fa-user" aria-hidden="true"></i> ArthEvents Admin</h4>
      </div>
    </div>
  </div>
</section>
<!--Login Form-->
<section class="section">
  <div class="row container">
    <form action="<?php echo URLROOT; ?>/dashboards/index" method="post" class="col s12">
        <div class="row">
          <div class="input-field col s12 blue-text text-darken-3">
          <i class="material-icons prefix">email</i>
          <input type="email" name="email" id="email" value="<?php echo $data['email']; ?>" class="validate" required>
          <label for="email" class="active">Your Email</label>
          <span class="helper-text red-text"><?php echo $data['email_err']; ?></span>
          </div>
        </div>
        <div class="row">
          <div class="input-field col s12 blue-text text-darken-3">
          <i class="material-icons prefix">vpn_key</i>
          <input type="password" name="pwd" id="pwd" value="<?php echo $data['pwd']; ?>" class="validate" required>
          <label for="pwd" class="active">Your Password</label>
          <span class="helper-text red-text"><?php echo $data['pwd_err']; ?></span>
          </div>
        </div>
        <div class="row">
          <div class="col s12 center">
          <button class="waves-effect waves-light btn blue darken-3" type="submit">Login <i class="material-icons right">send</i></button>
          </div>
        </div>
    </form>
  </div>
</section>
<?php require(APPROOT.'/views/dashboard/inc/footer.php'); ?>