<?php require(APPROOT.'/views/dashboard/inc/header.php'); ?>
<!--Page Title Section-->
<section class="blue lighten-5">
  <div class="container">
    <div class="row">
      <div class="col s12">
        <h4 class="blue-text text-darken-3"><i class="fa fa-lg fa-tachometer" aria-hidden="true"></i> Dashboard</h4>
      </div>
    </div>
  </div>
</section>
<!-- Action Button section -->
<section class="grey lighten-4">
  <div class="container">
  <div class="row">
    <div class="col s12 m12 l3">
      <a href="<?php echo URLROOT; ?>/seeEvents/fulfillEvents" class="btn-large waves-effect waves-light orange darken-3">Fulfill Events</a>
    </div>
    <div class="col s12 m12 l3">
      <a href="<?php echo URLROOT; ?>/seeServiceProviders/addServiceProvider" class="btn-large waves-effect waves-light teal darken-3" style="padding: auto; margin: 2px;">Add S-Providers</a>
    </div>
    <div class="col s12 m12 l3">
      <a href="<?php echo URLROOT; ?>/seeUsers/index" class="btn-large waves-effect waves-light lime darken-3">See Users</a>
    </div>
  </div>
  </div>
</section>
<!-- main content of page-->
<section>
  <div class="container">
    <section class="section">
      <h4 class="blue-text text-darken-3"><em>Upcoming Events that require your <span class="red-text">Attention</span>!</em></h4>
    </section>
    <div class="row">
      <div class="col s12 l8">
        <div class="divider"></div>
        <?php if( empty($data['upcomEventOrders']) ): ?>
          <h5><strong>Currently no order is there to fulfill!</strong></h5>
        <?php else: ?>
          <table class="responsive-table striped">
            <thead>
              <tr>
                <th>#</th>
                <th>Name</th>
                <th>Date</th>
                <th>Cost</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
            <?php $i = 1; ?>
            <?php foreach($data['upcomEventOrders'] as $event): ?>
              <tr>
                <td><?php echo $i; ?></td>
                <td><?php echo $event->name; ?></td>
                <td><?php echo date("d-m-Y", strtotime($event->date)); ?></td>
                <td>₹ <?php echo $event->ev_cost_customer; ?></td>
                <td><a href="<?= URLROOT; ?>/seeEvents/showEventDetails/<?php echo $event->ev_order_id; ?>" class="btn-small blue darken-3 waves-effect waves-light">Details</a></td>
              </tr>
              <?php $i++; ?>
            <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
      <div class="col s12 l3 offset-l1">
      <!-- SideBar Actions-->
        <div class="row">
          <div class="col s12 blue darken-3 center white-text valign-center">
            <h5><strong>Events</strong></h5>
            <h4><i class="fa fa-lg fa-calendar" aria-hidden="true"></i> <?php echo $data['numEvents']; ?></h4>
            <h4><a href="<?php echo URLROOT; ?>/seeEvents/index" class="btn-small waves-effect waves-light blue darken-3" style="border: solid white 2px;">View</a></h4>
          </div>
          <div class="col s12 teal darken-3 center white-text valign-center">
            <h5><strong>Service Providers</strong></h5>
            <h4><i class="fa fa-lg fa-cutlery" aria-hidden="true"></i> <?php echo $data['numSerProviders']; ?></h4>
            <h4><a href="<?php echo URLROOT; ?>/seeServiceProviders/index" class="btn-small waves-effect waves-light teal darken-3" style="border: solid white 2px;">View</a></h4>
          </div>
          <div class="col s12 lime darken-3 center white-text valign-center">
            <h5><strong>Users</strong></h5>
            <h4><i class="fa fa-lg fa-users" aria-hidden="true"></i> <?php echo $data['numUsers']; ?></h4>
            <h4><a href="<?php echo URLROOT; ?>/seeUsers/index" class="btn-small waves-effect waves-light lime darken-3"   style="border: solid white 2px;">View</a></h4>
          </div>
        </div>
      </div>
    </div>
  </div>
</section> 
<?php require(APPROOT.'/views/dashboard/inc/footer.php'); ?>