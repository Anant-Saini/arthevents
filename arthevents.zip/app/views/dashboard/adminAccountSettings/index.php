<?php require(APPROOT.'/views/dashboard/inc/header.php'); ?>
<!--Page Title Section-->
<section class="blue lighten-5">
  <div class="container">
    <div class="row">
      <div class="col s12">
        <h4 class="blue-text text-darken-3"><i class="fa fa-lg fa-user" aria-hidden="true"></i> Edit Profile</h4>
      </div>
    </div>
  </div>
</section>
<!-- Some Buttons -->
<div class="container">
  <div class="row">
  <div class="col s12 l6 m6 center-align">
    <div class="section">
    <a href="<?php echo URLROOT; ?>/dashboards/index" class="btn waves-effect waves-light blue darken-3 section"><i class="material-icons left">navigate_before</i>Back to Dashboard</a>
    </div>
  </div>
  <div class="col s12 l6 m6 center-align">
    <div class="section">
    <a href="<?php echo URLROOT; ?>/adminAccountSettings/changePassword" class="btn waves-effect waves-light blue darken-3 section"><i class="material-icons left">lock</i>Change Password</a>
    </div>
  </div>
  </div>
</div>
<!-- Flash Message-->
<div class="container">
  <?php flash('adminDetailsUpdated'); ?>
  <?php flash('userPwdUpdateSuccess'); ?>
  <?php flash('img_updated'); ?>
</div>
<!--Admin Profile Form-->
<section class="section">
  <div class="container">
    <div class="row">
      <div class="col s12 m6 l6">
        <div class="card blue lighten-5 center">
          <div class="card-title blue-text text-darken-3">
            <h4>Admin Image</h4>
          </div>
          <div class="divider"></div>
          <div class="card-content">
            <div class="row">
              <div class="card-image">
                <img src="<?php echo URLROOT; ?>/public/img/dashboardImgs/<?php echo $data['img_path']; ?>" style="max-width: 300px; height: auto;border: 3px black solid; margin: auto;" alt="admin_image" onclick="triggerClick()" id="adminImgDisplay">
              </div>
            </div>
            <div class="card-action">
              <form action="<?= URLROOT; ?>/adminAccountSettings/updateAdminImg"  method="post" enctype="multipart/form-data">
              <div class="row">
                <input type="file" name="adminImg" onchange="displayImage(this)" id="adminImg" class="hide">
                <button type="submit" name="updateImage" class="col s12 center btn waves-effect waves-light blue darken-3">Upload/Edit</button>
                <div class="col s12" style="padding: 2px;"></div>
                <button type="submit" name="deleteImage" class="col s12 center btn waves-effect waves-light red darken-3">Delete Image</button>
              </div>
              </form>
            </div>
          </div>    
        </div>
      </div>
      <div class="col s12 m6 l6">
        <div class="card blue lighten-5 center">
          <div class="card-title blue-text text-darken-3">
            <h4>Admin Details</h4>
          </div>
          <div class="divider"></div>
          <div class="card-content">
            <form action="<?php echo URLROOT; ?>/adminAccountSettings/index" method="post">
            <div class="row">
              <div class="input-field col s12">
                <i class="material-icons prefix">face</i>
                <input type="text" name="name" id="name" value="<?php echo $data['name']; ?>" class="black-text" required>
                <label for="name" class="active blue-text text-darken-3">Admin Name</label>
                <span class="helper-text red-text"><?php echo $data['name_err']; ?></span>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
                <i class="material-icons prefix">mail</i>
                <input type="email" name="email" id="email" value="<?php echo $data['email']; ?>" class="black-text" required>
                <label for="email" class="active blue-text text-darken-3">Admin Email</label>
                <span class="helper-text red-text"><?php echo $data['email_err']; ?></span>
              </div>
            </div>
            <div class="card-action">
              <div class="row">
                <div class="col s6 center">
                <button type="submit" name="updateDetails" class="btn waves-effect waves-light blue darken-3">Save</button>
                </div>
                <div class="col s6 center">
                <a href="<?php echo URLROOT; ?>/dashboards/index" class="btn waves-effect waves-light blue darken-3">Back</a>
                </div>
              </div>
            </div>
            </form>
          </div>    
        </div>
      </div>
    </div>
  </div>
</section>
<?php require(APPROOT.'/views/dashboard/inc/footer.php'); ?>