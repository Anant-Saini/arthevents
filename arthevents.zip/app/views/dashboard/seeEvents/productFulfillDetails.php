<?php require(APPROOT.'/views/dashboard/inc/header.php'); ?>
<!--Page Title Section-->
<section class="pink darken-3">
  <div class="container">
    <div class="row">
      <div class="col s12">
        <h4 class="white-text"><i class="fa fa-lg fa-gift" aria-hidden="true"></i> Product</h4>
      </div>
    </div>
  </div>
</section>
<!-- Back To Event -->
<div class="container">
  <div class="row">
    <div class="col s12 m6 l4">
      <a href="<?= URLROOT; ?>/seeEvents/showEventDetails/<?= $data['evId']; ?>" class="btn waves-effect waves-light pink darken-3"><i class="material-icons left">arrow_back</i>Back</a>
    </div>
  </div>
</div>
<!-- Product Details-->
<section class="section">
  <div class="container">
    <div class="row">
      <div class="col s12 m12 l6">
        <div class="card blue lighten-5">
          <div class="card-image">
          <img src="<?php echo URLROOT; ?>/public/img/productImgs/<?= $data['imgPath']; ?>" alt="product-image" class="responsive-img">
          </div>
          <div class="card-content">
          <h5 class="blue-text text-darken-3 center" style="padding-bottom: 4px;"><?= $data['pdName']; ?></h5>
            <ul class="collection with-header hoverable">
              <li class="collection-header center blue white-text darken-3"><strong>Product Features</strong></li>
              <?php for($i=1; $i<=5; $i++): ?>
                <?php $variable = 'feature'.$i; ?>
                <?php if( !is_null( $data[$variable] ) ): ?>
                <li class="collection-item"><?= $data[$variable]; ?></li>
                <?php endif; ?>
              <?php endfor; ?>
            </ul>
          </div>
        </div>
      </div>
      <div class="col s12 m12 l6 blue lighten-5" style="border-radius: 2%; border: solid 2px black;">
        <div class="center blue-text text-darken-3">
          <h4>Service Provider Info</h4>
        </div>
        <div class="divider"></div>
        <div class="container">

          <div class="row" style="margin-top: 1.2rem;">
            <div class="input-field col s12">
              <i class="material-icons prefix">face</i>
              <input type="text" name="spName" id="spName" value="<?php echo $data['spName']; ?>" disabled class="black-text">
              <label for="spName" class="active blue-text text-darken-3">Service Provider Name</label>
            </div>
            <div class="input-field col s12">
              <i class="material-icons prefix">business</i>
              <input type="text" name="companyName" id="companyName" value="<?php echo $data['companyName']; ?>" disabled class="black-text">
              <label for="companyName" class="active blue-text text-darken-3">Company Name</label>
            </div>
            <div class="input-field col s12">
              <i class="material-icons prefix">category</i>
              <input type="text" name="stype" id="stype" value="<?php echo $data['stype']; ?>" disabled class="black-text">
              <label for="stype" class="active blue-text text-darken-3">Service Type</label>
            </div>
          </div>

        </div>
        <div class="center blue-text text-darken-3">
          <h4>Contact Details</h4>
        </div>
        <div class="divider"></div>
        <div class="container">

          <div class="row" style="margin-top: 1.2rem;">
            <div class="input-field col s12">
              <i class="material-icons prefix">mail</i>
              <input type="text" name="spEmail" id="spEmail" value="<?php echo $data['spEmail']; ?>" disabled class="black-text">
              <label for="spEmail" class="active blue-text text-darken-3">Email</label>
            </div>
            <div class="input-field col s12">
              <i class="material-icons prefix">phone</i>
              <input type="text" name="mob1" id="mob1" value="<?php echo $data['mob1']; ?>" disabled class="black-text">
              <label for="mob1" class="active blue-text text-darken-3">Mobile Number</label>
            </div>
            <div class="input-field col s12">
              <i class="material-icons prefix">phone</i>
              <input type="text" name="mob2" id="mob2" value="<?php echo $data['mob2']; ?>" disabled class="black-text">
              <label for="mob2" class="active blue-text text-darken-3">Alternate Mobile Number</label>
            </div>
          </div>
        
        </div>
        <div class="center blue-text text-darken-3">
          <h4>Address</h4>
        </div>
        <div class="divider"></div>
        <div class="container">

          <div class="row" style="margin-top: 1.2rem;">
            <div class="input-field col s12">
              <i class="material-icons prefix">home</i>
              <textarea name="address" id="address" style="min-height: 1.5rem;" class="materialize-textarea black-text" disabled><?php echo $data['address']; ?></textarea>
              <label for="address" class="active blue-text text-darken-3">Address</label>
            </div>
          </div>

        </div>
        <div class="center blue-text text-darken-3">
          <h4>Product Charges</h4>
        </div>
        <div class="divider"></div>
        <div class="container">

          <div class="row" style="margin-top: 1.2rem;">
            <div class="input-field col s12">
              <i class="material-icons prefix">payment</i>
              <input type="text" name="priceCustomer" id="priceCustomer" value="₹<?php echo $data['priceCustomer']; ?>" disabled class="black-text">
              <label for="priceCustomer" class="active blue-text text-darken-3">For Customer</label>
            </div>
            <div class="input-field col s12">
              <i class="material-icons prefix">payment</i>
              <input type="text" name="priceAdmin" id="priceAdmin" value="₹<?php echo $data['priceAdmin']; ?>" disabled class="black-text">
              <label for="priceAdmin" class="active blue-text text-darken-3">For You</label>
            </div>
            <div class="input-field col s12">
              <i class="material-icons prefix">account_balance_wallet</i>
              <input type="text" name="profit-loss" id="profit-loss" value="₹<?php echo $data['priceCustomer']-$data['priceAdmin']; ?>" disabled class="black-text">
              <label for="profit-loss" class="active blue-text text-darken-3">Profit(+)/Loss(-)</label>
            </div>
          </div>
        
        </div>
      </div>
    </div>
  </div>
</section>
<?php require(APPROOT.'/views/dashboard/inc/footer.php'); ?>