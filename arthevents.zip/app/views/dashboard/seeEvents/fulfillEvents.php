<?php require(APPROOT.'/views/dashboard/inc/header.php'); ?>
<!--Page Title Section-->
<section class="orange darken-3">
  <div class="container">
    <div class="row">
      <div class="col s12">
        <h4 class="white-text"><i class="fa fa-lg fa-calendar" aria-hidden="true"></i> Events</h4>
      </div>
    </div>
  </div>
</section>
<!--Event Search Bar-->
<div class="grey lighten-5">
  <div class="container">
    <div class="row">
      <div class="col s12 l4">
        <p><strong class="blue-text text-darken-3">Upcoming:</strong> Events having date >= today</p>
      </div>
      <div class="col s12 l4">
        <p><strong class="blue-text text-darken-3">Bygone:</strong> Events having date < today</p>
      </div>
      <div class="col s12 l4">
        <form action="<?= URLROOT; ?>/seeEvents/fulfillEvents/1/<?= $data['status']; ?>/<?= $data['dateStatus']; ?>" method="post" id="fulfillEventsForm">
          <div class="row">
            <div class="input-field col s8">
              <select onchange="selectFunction(this.value)">
                <option value="uncompleted/upcoming" <?= ($data['status'] == 'uncompleted' && $data['dateStatus'] == 'upcoming') ? 'selected' : ''; ?>>Upcoming Uncompleted</option>
                <option value="uncompleted/bygone" <?= ($data['status'] == 'uncompleted' && $data['dateStatus'] == 'bygone') ? 'selected' : ''; ?>>Bygone Uncompleted</option>
                <option value="completed/upcoming" <?= ($data['status'] == 'completed' && $data['dateStatus'] == 'upcoming') ? 'selected' :''; ?>>Upcoming Completed</option>
                <option value="completed/bygone" <?= ($data['status'] == 'completed' && $data['dateStatus'] == 'bygone') ? 'selected' :''; ?>>Bygone Completed</option>
                <option value="declined/upcoming" <?= ($data['status'] == 'declined' && $data['dateStatus'] == 'upcoming') ? 'selected' :''; ?>>Upcoming Declined</option>
                <option value="declined/bygone" <?= ($data['status'] == 'declined' && $data['dateStatus'] == 'bygone') ? 'selected' :''; ?>>Bygone Declined</option>
              </select>
              <label class="blue-text text-darken-3"><strong>Event Status</strong></label>
            </div>
            <div class="col s4 input-field">
              <button type="submit" class="btn waves-effect waves-light blue darken-3">Go</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- Actual Event Data from SQL -->
<section class="container">
  <?php if( empty( $data['eventData'] ) ): ?>
    <p><strong>No Events Exist In This Category!</strong></p>
  <?php else: ?>
    <table class="highlight responsive-table">
      <thead>
        <tr>
          <th>#</th>
          <th>Name</th>
          <th>Date</th>
          <th>Cost</th>
          <th>Status</th>
          <th></th>
        </tr>
      </thead>
      <?php $i = (($data['currPage'] * 10) - 10) + 1; ?>
      <tbody>
        <?php foreach($data['eventData'] as $event): ?>
        <tr>
          <td><?= $i; ?></td>
          <td><?= $event->name; ?></td>
          <td><?= date("d-m-Y", strtotime($event->date)); ?></td>
          <td><?= $event->ev_cost_customer; ?></td>
          <td><?= $event->ev_status; ?></td>
          <td><a href="<?= URLROOT; ?>/seeEvents/showEventDetails/<?php echo $event->ev_order_id; ?>" class="btn-small blue darken-3 waves-effect waves-light">Details</a></td>
        </tr>
        <?php $i++; ?>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</section>
<!-- Pagination Field -->
<section class="section">
  <div class="container center">
    <ul class="pagination">
      <?php if($data['currPage'] - 1 > 0): ?>
        <li class="waves-effect"><a href="<?= URLROOT; ?>/seeEvents/fulfillEvents/<?= $data['currPage'] - 1; ?>/<?= $data['status']; ?>/<?= $data['dateStatus']; ?>"><i class="material-icons">chevron_left</i></a></li>
      <?php endif; ?>
      <?php $page = $data['currPage']; ?>
      <?php for($i = 1; $i <= 3; $i++): ?>
        <?php if($page > $data['numOfPages']): ?>
          <?php break; ?>
        <?php else: ?>
          <li class="<?php echo ($page == $data['currPage']) ? "active" : "waves-effect"; ?>"><a href="<?= URLROOT; ?>/seeEvents/fulfillEvents/<?= $page; ?>/<?= $data['status']; ?>/<?= $data['dateStatus']; ?>"><?= $page; ?></a></li>
          <?php $page++; ?>
        <?php endif; ?>
      <?php endfor; ?>
      <?php if($data['currPage'] + 3 <= $data['numOfPages']): ?>
        <li class="waves-effect"><a href="<?= URLROOT; ?>/seeEvents/fulfillEvents/<?= $data['currPage'] + 3; ?>/<?= $data['status']; ?>/<?= $data['dateStatus']; ?>"><i class="material-icons">chevron_right</i></a></li>
      <?php endif; ?>
    </ul>
  </div>
</section>
<?php require(APPROOT.'/views/dashboard/inc/footer.php'); ?>