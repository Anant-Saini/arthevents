<?php require(APPROOT.'/views/dashboard/inc/header.php'); ?>
<!--Page Title Section-->
<section class="blue darken-3">
  <div class="container">
    <div class="row">
      <div class="col s12">
        <h4 class="white-text"><i class="fa fa-lg fa-calendar" aria-hidden="true"></i> Event Details</h4>
      </div>
    </div>
  </div>
</section>
<!-- Back To users -->
<div class="container">
  <div class="row">
    <div class="col s12 m6 l4">
      <a href="<?= URLROOT; ?>/seeEvents/index" class="btn waves-effect waves-light lime darken-3"><i class="material-icons left">arrow_back</i>Events</a>
    </div>
    <div class="col s12 m6 l4">
      <a href="<?= URLROOT; ?>/dashboards/index" class="btn waves-effect waves-light blue darken-3" style="margin-top: 5px;"><i class="material-icons left">arrow_back</i>Dashboard</a>
    </div>
    <div class="col s12 m6 l4">
      <a href="<?= URLROOT; ?>/seeEvents/fulfillEvents" class="btn waves-effect waves-light orange darken-3" style="margin-top: 5px;"><i class="material-icons left">arrow_back</i>Fulfill Events</a>
    </div>
  </div>
</div>
<!-- Event Details-->
<section class="section">
  <div class="container">
    <?php flash('event_status_changed'); ?>
    <div class="row">
      <div class="col s12 m12 l6">
        <div class="card blue lighten-5">
          <div class="card-image">
          <img src="<?php echo URLROOT; ?>/public/img/eventTypeImgs/<?= $data['imgPath']; ?>" alt="product-image" class="responsive-img" style="max-height: 400px;">
          </div>
          <div class="card-content">
            <h5 class="blue-text text-darken-3 center" style="padding-bottom: 4px;"><?= $data['name']; ?></h5>
            <div class="row">
              <div class="input-field col s12">
                <i class="material-icons prefix">event</i>
                <input type="text" name="ev-id" id="ev-id" value="<?php echo $data['evId']; ?>" disabled class="black-text">
                <label for="ev-id" class="active blue-text text-darken-3">Event Id</label>
              </div>
              <div class="input-field col s12">
                <i class="material-icons prefix">category</i>
                <input type="text" name="evtype" id="evtype" value="<?php echo $data['evType']; ?>" disabled class="black-text">
                <label for="evtype" class="active blue-text text-darken-3">Event Type</label>
              </div>
              <div class="input-field col s12">
                <i class="material-icons prefix">date_range</i>
                <input type="text" name="date" id="date" value="<?php echo $data['date']; ?>" disabled class="black-text">
                <label for="date" class="active blue-text text-darken-3">Date</label>
              </div>
              <div class="input-field col s12">
                <i class="material-icons prefix">schedule</i>
                <input type="text" name="time" id="time" value="<?php echo $data['time']; ?>" disabled class="black-text">
                <label for="time" class="active blue-text text-darken-3">Time</label>
              </div>
              <div class="input-field col s12">
                <i class="material-icons prefix">emoji_people</i>
                <input type="text" name="evFor" id="evFor" value="<?php echo $data['evFor']; ?>" disabled class="black-text">
                <label for="evFor" class="active blue-text text-darken-3">Event For</label>
              </div>
              <div class="input-field col s12">
                <i class="material-icons prefix">phone</i>
                <input type="text" name="mob1" id="mob1" value="<?php echo $data['mob1']; ?>" disabled class="black-text">
                <label for="mob1" class="active blue-text text-darken-3">Customer Mobile</label>
              </div>
              <div class="input-field col s12">
                <i class="material-icons prefix">phone</i>
                <input type="text" name="mob2" id="mob2" value="<?php echo $data['mob2']; ?>" disabled class="black-text">
                <label for="mob2" class="active blue-text text-darken-3">Alternate Customer Mobile</label>
              </div>
            </div>
          </div>
          <?php if($data['evStatus'] == 'uncompleted'): ?>
            <div class="card-action">
              <div class="row">
                <div class="col s6 center"><a href="#confirmModalCompleted" class="btn waves-effect waves-light green darken-3 modal-trigger">Completed</a></div>
                <div class="col s6 center"><a href="#confirmModalDeclined" class="btn waves-effect waves-light orange darken-4 modal-trigger">Declined</a></div>
              </div>
            </div>
          <?php endif; ?>
        </div>
      </div>
      <div class="col s12 m12 l6 blue lighten-5" style="border-radius: 2%; border: solid 2px black;">
        <div class="section center blue-text text-darken-3">
          <h4>Event's Cost Info</h4>
        </div>
        <div class="divider"></div>
        <div class="container">
          <div class="section">
            <div class="row">
              <div class="input-field col s12">
                <i class="material-icons prefix">payments</i>
                <input type="text" name="evPriceCustomer" id="evPriceCustomer" value="₹<?php echo $data['evPriceCustomer']; ?>" disabled class="black-text">
                <label for="evPriceCustomer" class="active blue-text text-darken-3">Total Cost To Customer</label>
              </div>
              <div class="input-field col s12">
                <i class="material-icons prefix">payments</i>
                <input type="text" name="evPriceAdmin" id="evPriceAdmin" value="₹<?php echo $data['evPriceAdmin']; ?>" disabled class="black-text">
                <label for="evPriceAdmin" class="active blue-text text-darken-3">Total Cost To Company</label>
              </div>
              <div class="input-field col s12">
                <i class="material-icons prefix">account_balance_wallet</i>
                <input type="text" name="profit-loss" id="profit-loss" value="₹<?php echo $data['evPriceCustomer'] - $data['evPriceAdmin']; ?>" disabled class="black-text">
                <label for="profit-loss" class="active blue-text text-darken-3">(+)Profit/(-)Loss</label>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col s12 m12 l12 blue lighten-5" style="border-radius: 2%; border: solid 2px black; margin-top: 1.2rem">
        <div class="container">
          <div class="section center blue-text text-darken-3">
            <h4>Products Info</h4>
          </div>
          <div class="divider"></div>
          <div class="section">
            <table class="responsive-table highlight">
              <thead>
                <tr>
                  <th>Service Type</th>
                  <th>Product Name</th>
                  <th>Profit(+)/Loss(-)</th>
                  <th>Company</th>
                  <th>Product Details</th>
                </tr>
              </thead>
              <tbody>
              <?php foreach($data['pdInfoArr'] as $pdInfo): ?>
                <tr>
                  <td><?= $pdInfo->type; ?></td>
                  <td><?= $pdInfo->pd_name; ?></td>
                  <td>₹<?= $pdInfo->price_customer - $pdInfo->price_admin; ?></td>
                  <td><?= $pdInfo->company_name; ?></td>
                  <td><a href="<?= URLROOT; ?>/seeEvents/productFulfillDetails/<?= $pdInfo->pd_id; ?>/<?= $data['evId']; ?>" class="btn waves-effect waves-light blue darken-3">Details</a></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Confirm Modal Structure -->
<div id="confirmModalCompleted" class="modal blue lighten-5">
  <div class="modal-content">
    <h4 class="blue-text text-darken-3">Are you Sure?</h4>
    <p>Marking status of Event as <strong>Completed</strong> cannot be reversed once changed. So make changes only when you are completely sure!</p>
  </div>
  <div class="modal-footer blue lighten-5">
    <a href="#!" class="modal-close waves-effect waves-green btn yellow darken-4">Step Back</a>
    <a href="<?= URLROOT; ?>/seeEvents/changeEventStatus/<?= $data['evId']; ?>/completed" class="modal-close waves-effect waves-green btn green darken-3">I am Sure</a>
  </div>
</div>
<div id="confirmModalDeclined" class="modal blue lighten-5">
  <div class="modal-content">
    <h4 class="blue-text text-darken-3">Are you Sure?</h4>
    <p>Marking status of Event as <strong>Declined</strong> cannot be reversed once changed. So make changes only when you are completely sure!</p>
  </div>
  <div class="modal-footer blue lighten-5">
    <a href="#!" class="modal-close waves-effect waves-green btn yellow darken-4">Step Back</a>
    <a href="<?= URLROOT; ?>/seeEvents/changeEventStatus/<?= $data['evId']; ?>/declined" class="modal-close waves-effect waves-green btn green darken-3">I am Sure</a>
  </div>
</div>
<?php require(APPROOT.'/views/dashboard/inc/footer.php'); ?>