<!-- Footer -->
<footer class="page-footer blue darken-3">
  <div class="container">
    <div class="row">
      <div class="col s12 l6">
      <h5>Made and Designed By Anant Saini</h5>
      <p>All rights of publishing and distribution are owned by firm.</p>
      </div>
      <div class="col s12 l4 offset-l2">
      <h5>Connect</h5>
      <ul class="row">
        <li class="col s3"><a href="#" class="blue-text text-lighten-5"><i class="fa fa-facebook"></i></a></li>
        <li class="col s3"><a href="#" class="blue-text text-lighten-5"><i class="fa fa-instagram"></i></a></li>
        <li class="col s3"><a href="#" class="blue-text text-lighten-5"><i class="fa fa-twitter"></i></a></li>
        <li class="col s3"><a href="#" class="blue-text text-lighten-5"><i class="fa fa-telegram"></i></a></li>
      </ul>
      </div>
    </div>
  </div>
  <div class="footer-copyright grey darken-4">
    <div class="container center-align">&copy; 2020 ArthEvents</div>
  </div>
</footer>
<!-- Compiled and minified JavaScript of Materialize -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<!-- Custom Javascript-->
<script>
  document.addEventListener('DOMContentLoaded', function() {
    var tooltippedElems = document.querySelectorAll('.tooltipped');
    M.Tooltip.init(tooltippedElems, { });
    var sidenavElems = document.querySelectorAll('.sidenav');
    M.Sidenav.init(sidenavElems, { });
    var modalElems = document.querySelectorAll('.modal');
    M.Modal.init(modalElems, { });
    var textareaElems = document.querySelectorAll('.materialize-textarea');
    var selectElems = document.querySelectorAll('select');
    M.FormSelect.init(selectElems, { });
    var autocompleteElems = document.querySelectorAll('.autocomplete');
    M.Autocomplete.init(autocompleteElems, { });
    //Flash Message Close Functionality
    const flashMsgElem = document.getElementById('flash-msg');
    if( flashMsgElem ) {
        document.querySelector('#flash-msg').addEventListener('click', (e) => {
          if( e.target.className === 'material-icons' ) {
            document.getElementById('flash-msg').style.display = 'none';
          }
      });
    }
    //Get autocomplete element
    let searchInput = document.getElementById('search-input');
    //Add Event Listener to autocomplete
    searchInput.addEventListener('input', getSuggestions);
    function getSuggestions() {
      let searchInputValue = this.value;
      let urlUser = `<?= URLROOT; ?>/seeUsers/giveUserNameSuggestions/?si=${searchInputValue}`;
      let urlSerPro = `<?= URLROOT; ?>/seeServiceProviders/giveSerProNameSuggestions/?si=${searchInputValue}`;
      let urlEvent = `<?= URLROOT; ?>/seeEvents/giveEventNameSuggestions/?si=${searchInputValue}`;
      if( searchInputValue === "") {
        M.Autocomplete.init(searchInput, {
              data: {"No Input!": null}
            });
      } else {
        let xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
          if( this.readyState == 4 && this.status == 200) {
            const suggestions = JSON.parse(this.responseText);
            M.Autocomplete.init(searchInput, {
              data: suggestions
            });
          }
        }
        switch(this.name) {
          case 'event-search': xhr.open('GET', urlEvent, true);
                               break;
          case 'user-search': xhr.open('GET', urlUser, true);
                               break;
          case 'serv-pro-search': xhr.open('GET', urlSerPro, true);
                               break;
        }
        xhr.send();
      }
    }
    //Get searched-data
    const searchedData = document.querySelector('.searched-data');
    //Get searched-submit
    const searchSubmit = document.getElementById('search-submit');
    searchSubmit.addEventListener('click', (e) => {
      e.preventDefault();
      //Initialising different URLs
      let urlUser = `<?= URLROOT; ?>/seeUsers/searchUserByName/?un=${searchInput.value}`;
      let urlSerPro = `<?= URLROOT; ?>/seeServiceProviders/searchSerProByName/?spn=${searchInput.value}`;
      let urlEvent = `<?= URLROOT; ?>/seeEvents/searchEventByName/?en=${searchInput.value}`;
      //Making AJAX Call
      let xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function() {
        if( this.readyState == 4 && this.status == 200) {
          searchedData.innerHTML = this.responseText;
        }
      }
      switch(searchSubmit.name) {
        case 'event-search-submit': xhr.open('GET', urlEvent, true);
                              break;
        case 'user-search-submit': xhr.open('GET', urlUser, true);
                              break;
        case 'serv-pro-search-submit': xhr.open('GET', urlSerPro, true);
                              break;
      }
      xhr.send();
    });

  });
  //On change Function of select element
  function selectFunction(selectedValue) {
      let splitArr = selectedValue.split("/");

      let formActionStr = document.getElementById('fulfillEventsForm').action;
      let formActionArr = formActionStr.split("/");
      formActionArr.pop();
      formActionArr.pop();
      formActionArr.push(splitArr[0]);
      formActionArr.push(splitArr[1]);
      formActionStr = formActionArr.join("/");
      document.getElementById('fulfillEventsForm').action = formActionStr;
      
    }
  //ChangeUI function of AddServiceProvider
  var changeUIBtn = document.getElementById('changeUI');
  function changeUI(textContent) {
    let pdContainer = document.getElementById('product-details-container');
    let addSerBtnContainer = document.getElementById('add-service-btn-container');
    if(textContent === 'Add Product') {
     
     pdContainer.classList.remove('hide');
     addSerBtnContainer.classList.add('hide');
     changeUIBtn.textContent = 'Add Product Later';

    } else {

     pdContainer.classList.add('hide');
     addSerBtnContainer.classList.remove('hide');
     changeUIBtn.textContent = 'Add Product';

    }
  }
  //Trigger click function
  function triggerClick() {
    document.querySelector('#adminImg').click();
  }
  //Display Image Function
  function displayImage(e) {
    if(e.files[0]) {
      var reader = new FileReader();
      reader.onload = function(e) {
        document.querySelector('#adminImgDisplay').setAttribute('src', e.target.result);
      }
      reader.readAsDataURL(e.files[0]);
    }
  }
</script>
</body>
</html>