<div class="navbar-fixed">
<nav class="blue lighten-5">
    <div class="nav-wrapper container">
      <a href="<?php echo URLROOT; ?>/dashboards/" class="brand-logo blue-text text-darken-3"><strong>ArthEvents</strong></a>
      <?php if( isAdminLoggedIn() ): ?>
      <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="medium material-icons grey-text text-darken-4">menu</i></a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="<?php echo URLROOT; ?>/dashboards/loggedIn" class="grey-text text-darken-4">Dashboard</a></li>
        <li><a href="<?php echo URLROOT; ?>/seeEvents/index" class="grey-text text-darken-4">Events</a></li>
        <li><a href="<?php echo URLROOT; ?>/seeServiceProviders/index" class="grey-text text-darken-4">Service Providers</a></li>
        <li><a href="<?php echo URLROOT; ?>/seeUsers/index" class="grey-text text-darken-4">Users</a></li>
        <li class=""><a href="<?php echo URLROOT; ?>/adminAccountSettings" class="blue-text text-darken-3 tooltipped" data-position="bottom" data-tooltip="Account Settings"><i class="material-icons left">settings</i><?php echo $_SESSION['admin_name']; ?></a></li>
        <li class="tooltipped" data-position="bottom" data-tooltip="logout"><a href="<?php echo URLROOT; ?>/dashboards/logout" class="blue-text text-darken-3"><i class="material-icons left">all_out</i>Logout</a></li>
      </ul>
      <?php endif; ?>
    </div>
</nav>
</div>
<!-- SideNav Content -->
<?php if( isAdminLoggedIn() ): ?>
<ul id="slide-out" class="sidenav blue lighten-5">
    <li><a href="<?php echo URLROOT; ?>/dashboards/loggedIn" class="grey-text text-darken-4">Dashboard</a></li>
    <li><a href="<?php echo URLROOT; ?>/seeEvents/index" class="grey-text text-darken-4">Events</a></li>
    <li><a href="<?php echo URLROOT; ?>/seeServiceProviders/index" class="grey-text text-darken-4">Service Providers</a></li>
    <li><a href="<?php echo URLROOT; ?>/seeUsers/index" class="grey-text text-darken-4">Users</a></li>
    <li class=""><a href="<?php echo URLROOT; ?>/adminAccountSettings" class="blue-text text-darken-3 tooltipped" data-position="bottom" data-tooltip="Account Settings"><i class="material-icons left">settings</i><?php echo $_SESSION['admin_name']; ?></a></li>
    <li class="tooltipped" data-position="bottom" data-tooltip="logout"><a href="<?php echo URLROOT; ?>/dashboards/logout" class="blue-text text-darken-3"><i class="material-icons left">all_out</i>Logout</a></li>
</ul>
<?php endif; ?>