<?php require(APPROOT.'/views/dashboard/inc/header.php'); ?>
<!--Page Title Section-->
<section class="teal darken-3">
  <div class="container">
    <div class="row">
      <div class="col s12">
        <h4 class="white-text"><i class="fa fa-lg fa-cutlery" aria-hidden="true"></i> Service Provider</h4>
      </div>
    </div>
  </div>
</section>
<!-- Back To users -->
<div class="container">
  <div class="row">
    <div class="col s12 m4 l4">
      <a href="<?= URLROOT; ?>/seeServiceProviders/index" class="btn waves-effect waves-light lime darken-3"><i class="material-icons left">arrow_back</i>Service Providers</a>
    </div>
    <div class="col s12 m4 l4" style="margin-top: 4px;">
      <a href="<?= URLROOT; ?>/seeServiceProviders/editServiceProvider/<?php echo $data['spId']; ?>" class="btn waves-effect waves-light blue darken-3"><i class="material-icons left">create</i>Edit S. Providers</a>
    </div>
    <div class="col s12 m4 l4" style="margin-top: 4px;">
      <a href="#deleteSerProviderModal" class="btn waves-effect waves-light red darken-3 modal-trigger"><i class="material-icons left">delete</i>Delete</a>
    </div>
  </div>
</div>
<!-- User Details-->
<section class="section">
  <div class="container">
    <!-- Flash Status Changed Message-->
    <?php flash('status_changed'); ?>
    <?php flash('product_delete_success'); ?>
    <div class="row">
      <div class="col s12">
        <div class="section blue lighten-5">
          <div class="section center blue-text text-darken-3">
            <h4><?= $data['company_name']; ?></h4>
          </div>
          <div class="divider"></div>
          <div class="container">
            <div class="section">
              <div class="row">
                <div class="input-field col s12 m6 l6">
                  <i class="material-icons prefix">face</i>
                  <input type="text" name="owner_name" id="owner_name" value="<?php echo $data['owner_name']; ?>" disabled class="black-text">
                  <label for="owner_name" class="active blue-text text-darken-3">Owner Name</label>
                </div>
                <div class="input-field col s12 m6 l6">
                  <i class="material-icons prefix">category</i>
                  <input type="text" name="sp_type" id="sp_type" value="<?php echo $data['sp_type']; ?>" disabled class="black-text">
                  <label for="sp_type" class="active blue-text text-darken-3">Service Type</label>
                </div>
              </div>
            </div>
            <div class="center blue-text text-darken-3">
              <h5>Contact Details</h5>
            </div>
            <div class="divider"></div>
            <div class="section">
              <div class="row">
                <div class="input-field col s12 m12 l4">
                  <i class="material-icons prefix">mail</i>
                  <input type="email" name="email" id="email" value="<?php echo $data['email']; ?>" disabled class="black-text">
                  <label for="email" class="active blue-text text-darken-3">Email</label>
                </div>
                <div class="input-field col s12 m6 l4">
                  <i class="material-icons prefix">phone</i>
                  <input type="text" name="mob1" id="mob1" value="<?php echo $data['mob1']; ?>" disabled class="black-text">
                  <label for="mob1" class="active blue-text text-darken-3">Phone No.</label>
                </div>
                <div class="input-field col s12 m6 l4">
                  <i class="material-icons prefix">phone</i>
                  <input type="text" name="mob2" id="mob2" value="<?php echo $data['mob2']; ?>" disabled class="black-text">
                  <label for="mob2" class="active blue-text text-darken-3">Alternate Phone No.</label>
                </div>
              </div>
            </div>
            <div class="center blue-text text-darken-3">
              <h5>Address Details</h5>
            </div>
            <div class="divider"></div>
            <div class="section">
              <div class="row">
                <div class="input-field col s12">
                  <i class="material-icons prefix">home</i>
                  <textarea name="address" style="height:60px;" id="address" disabled class="black-text materialize-textarea"><?php echo $data['address']; ?></textarea>
                  <label for="address" class="active blue-text text-darken-3">User Address</label>
                </div>
              </div>
            </div>
            <div class="center blue-text text-darken-3">
              <h5>Service Provider's Products</h5>
            </div>
            <div class="divider"></div>
            <div class="section">
              <?php if( empty($data['spProductsArray']) ): ?>
                <p class="center">There are no products to show.</p>
              <?php else: ?>  
                <table class="highlight responsive-table">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Name</th>
                      <th>Cost to Customer</th>
                      <th>Cost to Admin</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $i = 1; ?>
                    <?php foreach($data['spProductsArray'] as $product): ?>
                    <tr>
                      <td><?= $i; ?></td>
                      <td><?= $product->pd_name; ?></td>
                      <td>₹<?= $product->price_customer; ?></td>
                      <td>₹<?= $product->price_admin; ?></td>
                      <td><a href="<?= URLROOT; ?>/seeServiceProviders/showProduct/<?= $product->pd_id; ?>/<?= $data['spId']; ?>" class="btn waves-effect waves-light blue darken-3">Details</a></td>
                    </tr>
                    <?php $i++; ?>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              <?php endif; ?>
            </div>
          </div>
          <div class="section center">
            <a href="<?= URLROOT; ?>/seeServiceProviders/addProduct/<?php echo $data['spId']; ?>/<?php echo $data['stypeId']; ?>" class="btn waves-effect waves-light teal darken-3"><i class="material-icons left">add</i>Add Product</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Delete Service Provider Modal Structure -->
<div id="deleteSerProviderModal" class="modal red lighten-3">
  <div class="modal-content">
    <h4>Are you sure?</h4>
    <p>This action will delete this particular service provider permanently and you will not be able to access it again. If you are not sure what you are doing click <strong>BACK!</strong></p>
  </div>
  <div class="modal-footer red lighten-3">
    <div class="row">
      <div class="col">
        <a href="#!" class="white-text modal-close waves-effect waves-light green lighten-1 btn-flat"><i class="material-icons left hide-on-small-only">arrow_back</i>Back</a>
      </div>
      <div class="col">
        <form action="<?php echo URLROOT; ?>/seeServiceProviders/deleteServiceProvider" method="post">
          <input type="hidden" name="spId" value="<?php echo $data['spId']; ?>">
          <button type="submit" class="white-text btn-flat waves-effect waves-light red darken-3"><i class="material-icons left hide-on-small-only">delete_forever</i>Delete</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php require(APPROOT.'/views/dashboard/inc/footer.php'); ?>