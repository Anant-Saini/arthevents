<?php require(APPROOT.'/views/dashboard/inc/header.php'); ?>
<!--Page Title Section-->
<section class="blue darken-3">
  <div class="container">
    <div class="row">
      <div class="col s12">
        <h4 class="white-text"><i class="fa fa-lg fa-pencil" aria-hidden="true"></i> Edit SP Details</h4>
      </div>
    </div>
  </div>
</section>
<!-- Back to Service Provider-->
<div class="container">
  <div class="row">
    <div class="col s12 m4 l4">
      <a href="<?= URLROOT; ?>/seeServiceProviders/showSPDetails/<?= $data['spId']; ?>" class="btn waves-effect waves-light lime darken-3"><i class="material-icons left">arrow_back</i>Back</a>
    </div>
  </div>
</div>
<!--Edit Service Provider Form -->
<div class="container">
    <?php flash('service_provider_updated_successfully'); ?>
</div>
<section class="section">
  <div class="container">
    <div class="row">
      <div class="col s12">
      <div class="card blue lighten-5">
      <form action="<?php echo URLROOT; ?>/seeServiceProviders/editServiceProvider/<?= $data['spId']; ?>" method="post">
      <div class="card-content" id="parent">

        <h5 class="card-title center blue-text text-darken-3"><strong>Personal Details</strong></h5>
        <div class="row">
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">business</i>
          <input type="text" name="companyName" id="companyName" value="<?php echo $data['companyName'] ?>" class="black-text">
          <label for="companyName" class="active blue-text text-darken-3">Company Name (optional)</label>
          <span class="helper-text red-text"><?php echo $data['companyName_err']; ?></span>
          </div>
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">face</i>
          <input type="text" name="name" id="name" value="<?php echo $data['name'] ?>" class="black-text" required>
          <label for="name" class="active blue-text text-darken-3">Service Provider's Name</label>
          <span class="helper-text red-text"><?php echo $data['name_err']; ?></span>
          </div>
        </div>
        <div class="row">
          <div class="input-field col s12">
          <i class="material-icons prefix">category</i>
          <select class="" id="stypeId" name="stypeId">
            <?php foreach($data['serviceTypes'] as $serType): ?>
              <option value="<?php echo $serType->stype_id; ?>" <?= ($data['stypeId'] == $serType->stype_id) ? 'selected' : ''; ?> ><?php echo $serType->name; ?></option>
            <?php endforeach; ?>
          </select>
          <label class="blue-text text-darken-3" for="stypeId">Type of Service</label>
          <span class="helper-text red-text"><?php echo $data['stypeId_err']; ?></span>
          </div>
        </div>

        <h5 class="card-title center blue-text text-darken-3"><strong>Contact Details</strong></h5>
        <div class="row">
          <div class="input-field col s12">
          <i class="material-icons prefix">mail</i>
          <input type="text" name="email" id="email" value="<?php echo $data['email'] ?>" class="black-text">
          <label for="email" class="active blue-text text-darken-3">Email (optional)</label>
          <span class="helper-text red-text"><?php echo $data['email_err']; ?></span>
          </div>
        </div>
        <div class="row">
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">phone</i>
          <input type="text" name="mob1" id="mob1" value="<?php echo $data['mob1'] ?>" class="black-text" required>
          <label for="mob1" class="active blue-text text-darken-3">Mobile Number</label>
          <span class="helper-text red-text"><?php echo $data['mob1_err']; ?></span>
          </div>
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">phone</i>
          <input type="text" name="mob2" id="mob2" value="<?php echo $data['mob2'] ?>" class="black-text">
          <label for="mob2" class="active blue-text text-darken-3">Alternate Mobile Number (optional)</label>
          <span class="helper-text red-text"><?php echo $data['mob2_err']; ?></span>
          </div>
        </div>
       

        <h5 class="card-title center blue-text text-darken-3"><strong>Address Details</strong></h5>
        <div class="row">
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">apartment</i>
          <input type="text" name="officeNo" id="officeNo" value="<?php echo $data['officeNo'] ?>" class="black-text">
          <label for="officeNo" class="active blue-text text-darken-3">Office/Building Number (optional)</label>
          <span class="helper-text red-text"><?php echo $data['officeNo_err']; ?></span>
          </div>
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">add_road</i>
          <input type="text" name="street" id="street" value="<?php echo $data['street'] ?>" class="black-text">
          <label for="street" class="active blue-text text-darken-3">Street/Colony/Road (optional)</label>
          <span class="helper-text red-text"><?php echo $data['street_err']; ?></span>
          </div>
        </div>
        <div class="row">
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">location_city</i>
          <input type="text" name="city" id="city" value="<?php echo $data['city'] ?>" class="black-text">
          <label for="city" class="active blue-text text-darken-3">City/Village/Town (optional)</label>
          <span class="helper-text red-text"><?php echo $data['city_err']; ?></span>
          </div>
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">local_shipping</i>
          <input type="text" name="pincode" id="pincode" value="<?php echo $data['pincode'] ?>" class="black-text">
          <label for="pincode" class="active blue-text text-darken-3">Pincode (optional)</label>
          <span class="helper-text red-text"><?php echo $data['pincode_err']; ?></span>
          </div>
        </div>
        <div class="row">
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">landscape</i>
          <input type="text" name="state" id="state" value="<?php echo $data['state'] ?>" class="black-text">
          <label for="state" class="active blue-text text-darken-3">State (optional)</label>
          <span class="helper-text red-text"><?php echo $data['state_err']; ?></span>
          </div>
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">flag</i>
          <input type="text" name="country" id="country" value="<?php echo $data['country'] ?>" class="black-text">
          <label for="country" class="active blue-text text-darken-3">Country</label>
          <span class="helper-text red-text"><?php echo $data['country_err']; ?></span>
          </div>
        </div>
      </div>
      <div class="card-action center">
        <button type="submit" class="btn-large waves-effect waves-light teal darken-3"><i class="material-icons left">save_alt</i>Save Changes</button>
      </div>
      </form>
      </div>
      </div>
    </div>
  </div>
</section>
<!-- Footer -->
<?php require(APPROOT.'/views/dashboard/inc/footer.php'); ?>