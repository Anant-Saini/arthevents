<?php require(APPROOT.'/views/dashboard/inc/header.php'); ?>
<!--Page Title Section-->
<section class="teal darken-3">
  <div class="container">
    <div class="row">
      <div class="col s12">
        <h4 class="white-text"><i class="fa fa-lg fa-cutlery" aria-hidden="true"></i> Service Providers</h4>
      </div>
    </div>
  </div>
</section>
<!-- Section for flash messages -->
<section class="container">
  <?php flash('service_provider_added_successfully'); ?>
  <?php flash('service_provider_delete_success'); ?>
</section>
<!--Service Provider Search Bar-->
<div class="grey lighten-5">
  <div class="container">
    <div class="row">
      <div class="col s12 l4 offset-l8">
        <form action="<?= URLROOT; ?>/seeServiceProviders/searchSerProByName/?spn=67" method="get">
          <div class="row">
            <div class="input-field col s9">
              <i class="material-icons prefix blue-text text-darken-3">search</i>
              <input type="text" id="search-input" name="serv-pro-search" class="autocomplete grey lighten-5 blue-text text-darken-3">
              <label for="search-input" class="blue-text text-darken-3">Service Provider Name</label>
            </div>
            <div class="input-field col s3">
              <input type="submit" name="serv-pro-search-submit" value="Find" id="search-submit" class="btn blue white-text darken-3">
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- Searched Service Provider from Database -->
<section class="container searched-data">
</section>
<!-- Actual User Data from SQL -->
<section class="container">
  <table class="highlight responsive-table">
    <thead>
      <tr>
        <th>#</th>
        <th>Name</th>
        <th>Company Name</th>
        <th>Email</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php $i = (($data['currPage'] * 10) - 10) + 1; ?>
      <?php foreach($data['serProvidersData'] as $serProvider): ?>
      <tr>
        <td><?= $i; ?></td>
        <td><?= $serProvider->name; ?></td>
        <td><?= $serProvider->company_name; ?></td>
        <td><?= $serProvider->email; ?></td>
        <td><a href="<?= URLROOT; ?>/seeServiceProviders/showSPDetails/<?php echo $serProvider->sp_id; ?>" class="btn-small blue darken-3 waves-effect waves-light">Details</a></td>
      </tr>
      <?php $i++; ?>
      <?php endforeach; ?>
    </tbody>  
  </table>
</section>
<!-- Pagination Field -->
<section class="section">
  <div class="container center">
    <ul class="pagination">
      <?php if($data['currPage'] - 1 > 0): ?>
        <li class="waves-effect"><a href="<?= URLROOT; ?>/seeServiceProviders/<?= $data['currPage'] - 1; ?>"><i class="material-icons">chevron_left</i></a></li>
      <?php endif; ?>
      <?php $page = $data['currPage']; ?>
      <?php for($i = 1; $i <= 3; $i++): ?>
        <?php if($page > $data['numOfPages']): ?>
          <?php break; ?>
        <?php else: ?>
          <li class="<?php echo ($page == $data['currPage']) ? "active" : "waves-effect"; ?>"><a href="<?= URLROOT; ?>/seeServiceProviders/<?= $page; ?>"><?= $page; ?></a></li>
          <?php $page++; ?>
        <?php endif; ?>
      <?php endfor; ?>
      <?php if($data['currPage'] + 3 <= $data['numOfPages']): ?>
        <li class="waves-effect"><a href="<?= URLROOT; ?>/seeServiceProviders/<?= $data['currPage'] + 3; ?>"><i class="material-icons">chevron_right</i></a></li>
      <?php endif; ?>
    </ul>
  </div>
</section>
<!-- Footer -->
<?php require(APPROOT.'/views/dashboard/inc/footer.php'); ?>