<?php require(APPROOT.'/views/dashboard/inc/header.php'); ?>
<!--Page Title Section-->
<section class="teal darken-3">
  <div class="container">
    <div class="row">
      <div class="col s12">
        <h4 class="white-text"><i class="fa fa-lg fa-cutlery" aria-hidden="true"></i><i class="material-icons left">add</i> Add Service Provider</h4>
      </div>
    </div>
  </div>
</section>
<!--Add Service Provider Form -->
<div class="container">
    <!--<?php //flash('login_success'); ?>-->
</div>
<section class="section">
  <div class="container">
    <div class="row">
      <div class="col s12">
      <div class="card blue lighten-5">
      <form action="<?php echo URLROOT; ?>/seeServiceProviders/addServiceProvider" enctype="multipart/form-data" method="post" name="add_service_provider_form">
      <div class="card-content" id="parent">

        <h5 class="card-title center blue-text text-darken-3"><strong>Personal Details</strong></h5>
        <div class="row">
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">business</i>
          <input type="text" name="companyName" id="companyName" value="<?php echo $data['companyName'] ?>" class="black-text">
          <label for="companyName" class="active blue-text text-darken-3">Company Name (optional)</label>
          <span class="helper-text red-text"><?php echo $data['companyName_err']; ?></span>
          </div>
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">face</i>
          <input type="text" name="name" id="name" value="<?php echo $data['name'] ?>" class="black-text" required>
          <label for="name" class="active blue-text text-darken-3">Service Provider's Name</label>
          <span class="helper-text red-text"><?php echo $data['name_err']; ?></span>
          </div>
        </div>
        <div class="row">
          <div class="input-field col s12">
          <i class="material-icons prefix">category</i>
          <select class="" id="stypeId" name="stypeId">
              <option value="none" <?= ($data['stypeId'] == 'none') ? 'selected' : ''; ?>>Choose your option</option>
          <?php foreach($data['serviceTypes'] as $serType): ?>
              <option value="<?php echo $serType->stype_id; ?>" <?= ($data['stypeId'] == $serType->stype_id) ? 'selected' : ''; ?> ><?php echo $serType->name; ?></option>
          <?php endforeach; ?>
          </select>
          <label class="blue-text text-darken-3" for="stypeId">Type of Service</label>
          <span class="helper-text red-text"><?php echo $data['stypeId_err']; ?></span>
          </div>
        </div>

        <h5 class="card-title center blue-text text-darken-3"><strong>Contact Details</strong></h5>
        <div class="row">
          <div class="input-field col s12">
          <i class="material-icons prefix">mail</i>
          <input type="text" name="email" id="email" value="<?php echo $data['email'] ?>" class="black-text">
          <label for="email" class="active blue-text text-darken-3">Email (optional)</label>
          <span class="helper-text red-text"><?php echo $data['email_err']; ?></span>
          </div>
        </div>
        <div class="row">
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">phone</i>
          <input type="text" name="mob1" id="mob1" value="<?php echo $data['mob1'] ?>" class="black-text" required>
          <label for="mob1" class="active blue-text text-darken-3">Mobile Number</label>
          <span class="helper-text red-text"><?php echo $data['mob1_err']; ?></span>
          </div>
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">phone</i>
          <input type="text" name="mob2" id="mob2" value="<?php echo $data['mob2'] ?>" class="black-text">
          <label for="mob2" class="active blue-text text-darken-3">Alternate Mobile Number (optional)</label>
          <span class="helper-text red-text"><?php echo $data['mob2_err']; ?></span>
          </div>
        </div>
       

        <h5 class="card-title center blue-text text-darken-3"><strong>Address Details</strong></h5>
        <div class="row">
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">apartment</i>
          <input type="text" name="officeNo" id="officeNo" value="<?php echo $data['officeNo'] ?>" class="black-text">
          <label for="officeNo" class="active blue-text text-darken-3">Office/Building Number (optional)</label>
          <span class="helper-text red-text"><?php echo $data['officeNo_err']; ?></span>
          </div>
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">add_road</i>
          <input type="text" name="street" id="street" value="<?php echo $data['street'] ?>" class="black-text">
          <label for="street" class="active blue-text text-darken-3">Street/Colony/Road (optional)</label>
          <span class="helper-text red-text"><?php echo $data['street_err']; ?></span>
          </div>
        </div>
        <div class="row">
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">location_city</i>
          <input type="text" name="city" id="city" value="<?php echo $data['city'] ?>" class="black-text">
          <label for="city" class="active blue-text text-darken-3">City/Village/Town (optional)</label>
          <span class="helper-text red-text"><?php echo $data['city_err']; ?></span>
          </div>
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">local_shipping</i>
          <input type="text" name="pincode" id="pincode" value="<?php echo $data['pincode'] ?>" class="black-text">
          <label for="pincode" class="active blue-text text-darken-3">Pincode (optional)</label>
          <span class="helper-text red-text"><?php echo $data['pincode_err']; ?></span>
          </div>
        </div>
        <div class="row">
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">landscape</i>
          <input type="text" name="state" id="state" value="<?php echo $data['state'] ?>" class="black-text">
          <label for="state" class="active blue-text text-darken-3">State (optional)</label>
          <span class="helper-text red-text"><?php echo $data['state_err']; ?></span>
          </div>
          <div class="input-field col s12 m6 l6">
          <i class="material-icons prefix">flag</i>
          <input type="text" name="country" id="country" value="<?php echo $data['country'] ?>" class="black-text">
          <label for="country" class="active blue-text text-darken-3">Country</label>
          <span class="helper-text red-text"><?php echo $data['country_err']; ?></span>
          </div>
        </div>
        <!-- Buttons to save and changeUI -->
        <div class="row center" id="beforeChild">
          <div class="col s12 <?= ($data['show']) ? 'hide' : ''; ?>" id="add-service-btn-container">
              <button type="submit" name="addSerPro" class="btn-large waves-effect waves-light teal darken-3">Save</button>
          </div>
          <div class="divider"></div>
          <div class="col s12" style="margin-top: 5px;">
              <a href="#" id="changeUI" onclick="changeUI(this.textContent)" class="btn-large waves-effect waves-light pink darken-3"><?= ($data['show']) ? 'Add Product Later' : 'Add Product'; ?></a>
          </div>
        </div>
        <!-- Add Product UI -->
        <div class="container <?= ($data['show']) ? '' : 'hide'; ?>" id="product-details-container">
          <div class="row">
            <div class="input-field col s12 m6 l6">
            <i class="material-icons prefix">camera</i>
            <input type="text" name="pdName" id="pdName" value="<?php echo $data['pdName']; ?>" class="black-text" >
            <label for="pdName" class="active blue-text text-darken-3">Product Name</label>
            <span class="helper-text red-text"><?php echo $data['pdName_err']; ?></span>
            </div>
            <div class="file-field input-field col s12 m6 l6">
              <div class="btn">
                <span>Product Image</span>
                <input type="file" name="pdImg" id="pdImg">
              </div>
              <div class="file-path-wrapper">
                <input class="file-path validate" type="text" value="">
              </div>
              <span class="helper-text red-text"><?php echo $data['pdImg_err']; ?></span>
            </div>
          </div>
          <div class="row">
            <div class="input-field col s12">
            <i class="material-icons prefix">campaign</i>
            <input type="text" name="feature1" id="feature1" value="<?php echo $data['feature1'] ?>" class="black-text" >
            <label for="feature1" class="active blue-text text-darken-3">Product Feature 1</label>
            <span class="helper-text red-text"><?php echo $data['feature1_err']; ?></span>
            </div>
          </div>
          <div class="row">
            <div class="input-field col s12">
            <i class="material-icons prefix">campaign</i>
            <input type="text" name="feature2" id="feature2" value="<?php echo $data['feature2'] ?>" class="black-text">
            <label for="feature2" class="active blue-text text-darken-3">Product Feature 2 (optional)</label>
            <span class="helper-text red-text"><?php echo $data['feature2_err']; ?></span>
            </div>
          </div>
          <div class="row">
            <div class="input-field col s12">
            <i class="material-icons prefix">campaign</i>
            <input type="text" name="feature3" id="feature3" value="<?php echo $data['feature3'] ?>" class="black-text">
            <label for="feature3" class="active blue-text text-darken-3">Product Feature 3 (optional)</label>
            <span class="helper-text red-text"><?php echo $data['feature3_err']; ?></span>
            </div>
          </div>
          <div class="row">
            <div class="input-field col s12">
            <i class="material-icons prefix">campaign</i>
            <input type="text" name="feature4" id="feature4" value="<?php echo $data['feature4'] ?>" class="black-text">
            <label for="feature4" class="active blue-text text-darken-3">Product Feature 4 (optional)</label>
            <span class="helper-text red-text"><?php echo $data['feature4_err']; ?></span>
            </div>
          </div>
          <div class="row">
            <div class="input-field col s12">
            <i class="material-icons prefix">campaign</i>
            <input type="text" name="feature5" id="feature5" value="<?php echo $data['feature5'] ?>" class="black-text">
            <label for="feature5" class="active blue-text text-darken-3">Product Feature 5 (optional)</label>
            <span class="helper-text red-text"><?php echo $data['feature5_err']; ?></span>
            </div>
          </div>
          <div class="row">
            <div class="input-field col s12 m6 l6">
            <i class="material-icons prefix">payments</i>
            <input type="number" min="0" name="priceCustomer" id="priceCustomer" value="<?php echo $data['priceCustomer'] ?>" class="black-text" >
            <label for="priceCustomer" class="active blue-text text-darken-3">Price For Customer (₹)</label>
            <span class="helper-text red-text"><?php echo $data['priceCustomer_err']; ?></span>
            </div>
            <div class="input-field col s12 m6 l6">
            <i class="material-icons prefix">payments</i>
            <input type="number" min="0" name="priceAdmin" id="priceAdmin" value="<?php echo $data['priceAdmin'] ?>" class="black-text" >
            <label for="priceAdmin" class="active blue-text text-darken-3">Price For Company (₹)</label>
            <span class="helper-text red-text"><?php echo $data['priceAdmin_err']; ?></span>
            </div>
          </div>
          <!-- Submit Button-->
          <div class="row center">
            <div class="col s12">
                <button type="submit" name="addSerProWithPd" class="btn-large waves-effect waves-light teal darken-3">Save</button>
            </div>
          </div>  
        </div>
      </div>
      </form>
      </div>
      </div>
    </div>
  </div>
</section>
<!-- Footer -->
<?php require(APPROOT.'/views/dashboard/inc/footer.php'); ?>