<?php require(APPROOT.'/views/dashboard/inc/header.php'); ?>
<!--Page Title Section-->
<section class="pink darken-3">
  <div class="container">
    <div class="row">
      <div class="col s12">
        <h4 class="white-text"><i class="fa fa-lg fa-gift" aria-hidden="true"></i> Product</h4>
      </div>
    </div>
  </div>
</section>
<!-- Back To Service Provider -->
<div class="container">
  <div class="row">
    <div class="col s12 m6 l4">
      <a href="<?= URLROOT; ?>/seeServiceProviders/showSPDetails/<?= $data['spId']; ?>" class="btn waves-effect waves-light pink darken-3"><i class="material-icons left">arrow_back</i>Back</a>
    </div>
    <div class="col s12 m6 l4" style="margin-top: 5px;">
      <a href="#deleteProductModal" class="btn waves-effect waves-light red darken-3 modal-trigger"><i class="material-icons left">delete</i>Delete</a>
    </div>
  </div>
</div>
<!-- Product Details-->
<section class="section">
  <div class="container">
    <div class="row">
      <div class="col s12 m12 l6">
        <div class="card blue lighten-5">
          <div class="card-image">
          <img src="<?php echo URLROOT; ?>/public/img/productImgs/<?= $data['imgPath']; ?>" alt="product-image" class="responsive-img">
          </div>
          <div class="card-content">
          <h5 class="blue-text text-darken-3 center" style="padding-bottom: 4px;"><?= $data['name']; ?></h5>
            <ul class="collection with-header hoverable">
              <li class="collection-header center blue white-text darken-3"><strong>Product Features</strong></li>
              <?php for($i=1; $i<=5; $i++): ?>
                <?php $variable = 'feature'.$i; ?>
                <?php if( !is_null( $data[$variable] ) ): ?>
                <li class="collection-item"><?= $data[$variable]; ?></li>
                <?php endif; ?>
              <?php endfor; ?>
            </ul>
          </div>
        </div>
      </div>
      <div class="col s12 m12 l6 blue lighten-5" style="border-radius: 2%; border: solid 2px black;">
        <div class="section center blue-text text-darken-3">
          <h4>Product Info</h4>
        </div>
        <div class="divider"></div>
        <div class="container">
          <div class="section">
            <div class="row">
              <div class="input-field col s12">
                <i class="material-icons prefix">redeem</i>
                <input type="text" name="pd-name" id="pd-name" value="<?php echo $data['name']; ?>" disabled class="black-text">
                <label for="pd_name" class="active blue-text text-darken-3">Product Name</label>
              </div>
              <div class="input-field col s12">
                <i class="material-icons prefix">category</i>
                <input type="text" name="s-type" id="s-type" value="<?php echo $data['stype']; ?>" disabled class="black-text">
                <label for="s_type" class="active blue-text text-darken-3">Service Type</label>
              </div>
              <div class="input-field col s12">
                <i class="material-icons prefix">business</i>
                <input type="text" name="company-name" id="company-name" value="<?php echo $data['companyName']; ?>" disabled class="black-text">
                <label for="company-name" class="active blue-text text-darken-3">Company Name</label>
              </div>
              <div class="input-field col s12">
                <i class="material-icons prefix">payments</i>
                <input type="text" name="priceCustomer" id="priceCustomer" value="₹<?php echo $data['priceCustomer']; ?>" disabled class="black-text">
                <label for="priceCustomer" class="active blue-text text-darken-3">Cost To Customer</label>
              </div>
              <div class="input-field col s12">
                <i class="material-icons prefix">payments</i>
                <input type="text" name="priceAdmin" id="priceAdmin" value="₹<?php echo $data['priceAdmin']; ?>" disabled class="black-text">
                <label for="priceAdmin" class="active blue-text text-darken-3">Cost To Company</label>
              </div>
              <div class="input-field col s12">
                <i class="material-icons prefix">account_balance_wallet</i>
                <input type="text" name="profit-loss" id="profit-loss" value="₹<?php echo $data['priceCustomer'] - $data['priceAdmin']; ?>" disabled class="black-text">
                <label for="profit-loss" class="active blue-text text-darken-3">(+)Profit/(-)Loss</label>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Delete Product Modal Structure -->
<div id="deleteProductModal" class="modal red lighten-3">
  <div class="modal-content">
    <h4>Are you sure?</h4>
    <p>This action will delete this particular product permanently and you will not be able to access it again. If you are not sure what you are doing click <strong>BACK!</strong></p>
  </div>
  <div class="modal-footer red lighten-3">
    <div class="row">
      <div class="col">
        <a href="#!" class="white-text modal-close waves-effect waves-light green lighten-1 btn-flat"><i class="material-icons left hide-on-small-only">arrow_back</i>Back</a>
      </div>
      <div class="col">
        <form action="<?php echo URLROOT; ?>/seeServiceProviders/deleteProduct/<?= $data['spId']; ?>" method="post">
          <input type="hidden" name="pdId" value="<?php echo $data['pdId']; ?>">
          <button type="submit" class="white-text btn-flat waves-effect waves-light red darken-3"><i class="material-icons left hide-on-small-only">delete_forever</i>Delete</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php require(APPROOT.'/views/dashboard/inc/footer.php'); ?>