<?php require(APPROOT.'/views/dashboard/inc/header.php'); ?>
<!--Page Title Section-->
<section class="teal darken-3">
  <div class="container">
    <div class="row">
      <div class="col s12">
        <h4 class="white-text"><i class="fa fa-lg fa-plus" aria-hidden="true"></i> Add Product</h4>
      </div>
    </div>
  </div>
</section>
<!-- Back to Service Provider-->
<div class="container">
  <div class="row">
    <div class="col s12 m4 l4">
      <a href="<?= URLROOT; ?>/seeServiceProviders/showSPDetails/<?= $data['spId']; ?>" class="btn waves-effect waves-light lime darken-3"><i class="material-icons left">arrow_back</i>Back</a>
    </div>
  </div>
</div>
<!--Edit Service Provider Form -->
<div class="container">
    <?php flash('product_added_successfully'); ?>
</div>
<div class="section">
  <div class="container">
    <div class="row">
      <div class="col s12">
        <div class="card blue lighten-5">
        <form action="<?php echo URLROOT; ?>/seeServiceProviders/addProduct/<?= $data['spId']; ?>/<?= $data['stypeId']; ?>" enctype="multipart/form-data" method="post">
          <div class="card-content">
            <div class="row">
              <div class="input-field col s12 m6 l6">
              <i class="material-icons prefix">camera</i>
              <input type="text" name="pdName" id="pdName" value="<?php echo $data['pdName']; ?>" class="black-text" >
              <label for="pdName" class="active blue-text text-darken-3">Product Name</label>
              <span class="helper-text red-text"><?php echo $data['pdName_err']; ?></span>
              </div>
              <div class="file-field input-field col s12 m6 l6">
                <div class="btn">
                  <span>Product Image</span>
                  <input type="file" name="pdImg" id="pdImg">
                </div>
                <div class="file-path-wrapper">
                  <input class="file-path validate" type="text" value="">
                </div>
                <span class="helper-text red-text"><?php echo $data['pdImg_err']; ?></span>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
              <i class="material-icons prefix">campaign</i>
              <input type="text" name="feature1" id="feature1" value="<?php echo $data['feature1'] ?>" class="black-text" >
              <label for="feature1" class="active blue-text text-darken-3">Product Feature 1</label>
              <span class="helper-text red-text"><?php echo $data['feature1_err']; ?></span>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
              <i class="material-icons prefix">campaign</i>
              <input type="text" name="feature2" id="feature2" value="<?php echo $data['feature2'] ?>" class="black-text">
              <label for="feature2" class="active blue-text text-darken-3">Product Feature 2 (optional)</label>
              <span class="helper-text red-text"><?php echo $data['feature2_err']; ?></span>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
              <i class="material-icons prefix">campaign</i>
              <input type="text" name="feature3" id="feature3" value="<?php echo $data['feature3'] ?>" class="black-text">
              <label for="feature3" class="active blue-text text-darken-3">Product Feature 3 (optional)</label>
              <span class="helper-text red-text"><?php echo $data['feature3_err']; ?></span>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
              <i class="material-icons prefix">campaign</i>
              <input type="text" name="feature4" id="feature4" value="<?php echo $data['feature4'] ?>" class="black-text">
              <label for="feature4" class="active blue-text text-darken-3">Product Feature 4 (optional)</label>
              <span class="helper-text red-text"><?php echo $data['feature4_err']; ?></span>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
              <i class="material-icons prefix">campaign</i>
              <input type="text" name="feature5" id="feature5" value="<?php echo $data['feature5'] ?>" class="black-text">
              <label for="feature5" class="active blue-text text-darken-3">Product Feature 5 (optional)</label>
              <span class="helper-text red-text"><?php echo $data['feature5_err']; ?></span>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12 m6 l6">
              <i class="material-icons prefix">payments</i>
              <input type="number" min="0" name="priceCustomer" id="priceCustomer" value="<?php echo $data['priceCustomer'] ?>" class="black-text" >
              <label for="priceCustomer" class="active blue-text text-darken-3">Price For Customer (₹)</label>
              <span class="helper-text red-text"><?php echo $data['priceCustomer_err']; ?></span>
              </div>
              <div class="input-field col s12 m6 l6">
              <i class="material-icons prefix">payments</i>
              <input type="number" min="0" name="priceAdmin" id="priceAdmin" value="<?php echo $data['priceAdmin'] ?>" class="black-text" >
              <label for="priceAdmin" class="active blue-text text-darken-3">Price For Company (₹)</label>
              <span class="helper-text red-text"><?php echo $data['priceAdmin_err']; ?></span>
              </div>
            </div>
            <!-- Submit Button-->
            <div class="row center">
              <div class="col s12">
                <button type="submit" class="btn-large waves-effect waves-light teal darken-3"><i class="material-icons left">add</i>Add</button>
              </div>
            </div>
          </div>
        </form>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Footer -->
<?php require(APPROOT.'/views/dashboard/inc/footer.php'); ?>
