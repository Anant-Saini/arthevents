<?php require(APPROOT.'/views/dashboard/inc/header.php'); ?>
<!--Page Title Section-->
<section class="lime darken-3">
  <div class="container">
    <div class="row">
      <div class="col s12">
        <h4 class="white-text"><i class="fa fa-lg fa-user" aria-hidden="true"></i> User</h4>
      </div>
    </div>
  </div>
</section>
<!-- Back To users -->
<div class="container">
  <div class="row">
    <div class="col s12">
      <a href="<?= URLROOT; ?>/seeUsers/index" class="btn waves-effect waves-light lime darken-3"><i class="material-icons left">arrow_back</i>Users</a>
    </div>
  </div>
</div>
<!-- User Details-->
<section class="section">
  <div class="container">
    <!-- Flash Status Changed Message-->
    <?php flash('status_changed'); ?>
    <div class="row">
      <div class="col s12">
        <div class="section blue lighten-5">
          <div class="section center blue-text text-darken-3">
            <h4>User Details</h4>
          </div>
          <div class="divider"></div>
          <div class="container">
          <div class="section">
            <div class="row">
              <div class="input-field col s12 m6 l6">
                <i class="material-icons prefix">face</i>
                <input type="text" name="name" id="name" value="<?php echo $data['name']; ?>" disabled class="black-text">
                <label for="name" class="active blue-text text-darken-3">User Name</label>
              </div>
              <div class="input-field col s12 m6 l6">
                <i class="material-icons prefix">mail</i>
                <input type="email" name="email" id="email" value="<?php echo $data['email']; ?>" disabled class="black-text">
                <label for="email" class="active blue-text text-darken-3">User Email</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12 m6 l6">
                <i class="material-icons prefix">star_border</i>
                <input type="text" name="status" id="status" value="<?php echo $data['status']; ?>" disabled class="black-text">
                <label for="status" class="active blue-text text-darken-3">User Status</label>
              </div>
              <div class="input-field col s12 m6 l6">
                <i class="material-icons prefix">date_range</i>
                <input type="text" name="created_at" id="created_at" value="<?php echo $data['created_at']; ?>" disabled class="black-text">
                <label for="created_at" class="active blue-text text-darken-3">User Registered On</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12 m6 l6">
                <i class="material-icons prefix">phone</i>
                <input type="text" name="mob1" id="mob1" value="<?php echo $data['mob1']; ?>" disabled class="black-text">
                <label for="mob1" class="active blue-text text-darken-3">Phone No.</label>
              </div>
              <div class="input-field col s12 m6 l6">
                <i class="material-icons prefix">phone</i>
                <input type="text" name="mob2" id="mob2" value="<?php echo $data['mob2']; ?>" disabled class="black-text">
                <label for="mob2" class="active blue-text text-darken-3">Alternate Phone No.</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
                <i class="material-icons prefix">home</i>
                <textarea name="address" id="address" disabled class="black-text materialize-textarea"><?php echo $data['address']; ?></textarea>
                <label for="address" class="active blue-text text-darken-3">User Address</label>
              </div>
            </div>
            <div class="divider"></div>
            <div class="row section">
              <div class="col s12 center">
                <a href="<?= URLROOT; ?>/seeUsers/changeUserStatusById/<?= $data['user_id']; ?>/<?= ($data['status'] == 'allowed') ? "blocked" : "allowed"; ?>" class="btn waves-effect waves-light <?= ($data['status'] == 'allowed') ? "red" : "blue"; ?>"><?= ($data['status'] == 'allowed') ? "Block User" : "Unblock User"; ?></a>
              </div>
            </div>
          </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php require(APPROOT.'/views/dashboard/inc/footer.php'); ?>