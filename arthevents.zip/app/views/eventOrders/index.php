<?php require(APPROOT.'/views/inc/header.php'); ?>
    <div class="container">
    <?php flash('login_success'); ?>
    </div>
    <section class="section blue darken-3">
        <div class="container">
            <div class="white-text center"><h5><em>So, you have an event on mind. Let's talk about it!</em></h5></div>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <div class="row">
                <div class="col s12">
                <div class="card blue lighten-5">
                <form action="<?php echo URLROOT; ?>/eventOrders/index" method="post" name="event_order_form">
                <div class="card-content" id="parent">
    
                    <div class="row">
                        <div class="input-field col s12">
                        <i class="material-icons prefix">cake</i>
                        <input type="text" name="name" id="name" value="<?php echo $data['name'] ?>" class="black-text" required>
                        <label for="name" class="active blue-text text-darken-3">Event Name</label>
                        <span class="helper-text red-text"><?php echo $data['name_err']; ?></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12">
                        <i class="material-icons prefix">deck</i>
                        <select class="icons" id="etype_id" name="etype_id">
                            <option value="none" selected>Choose your option</option>
                        <?php foreach($data['event_types'] as $eventType): ?>
                            <option value="<?php echo $eventType->etype_id; ?>" data-icon="<?php echo URLROOT.'/public/img/eventTypeImgs/'.$eventType->img_path; ?>" class="left"><?php echo $eventType->name; ?></option>
                        <?php endforeach; ?>
                        </select>
                        <label class="blue-text text-darken-3" for="etype_id">Type of Event</label>
                        <span class="helper-text red-text"><?php echo $data['etype_err']; ?></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12">
                        <i class="material-icons prefix">date_range</i>
                        <input type="text" name="date" id="date" value="<?php echo $data['date']; ?>" class="black-text datepicker" required>
                        <label for="date" class="active blue-text text-darken-3">Date of Event</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12">
                        <i class="material-icons prefix">schedule</i>
                        <input type="text" name="time" id="time" value="<?php echo $data['time']; ?>" class="black-text timepicker" required>
                        <label for="time" class="active blue-text text-darken-3">Starting Time of Event</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12">
                        <i class="material-icons prefix">person</i>
                        <input type="text" id="event_for_desc" disabled>
                        <label for="event_for_desc" class="blue-text text-darken-3">Event taking place For</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col s12 m4">
                        <label for="person">
                            <input name="event_for" value="person" type="radio" id="person" checked />
                            <span class="black-text">Person</span>
                        </label>
                        </div>
                        <div class="col s12 m4">
                        <label for="company">
                            <input name="event_for" value="company" type="radio" id="company"/>
                            <span class="black-text">Company</span>
                        </label>
                        </div>
                        <div class="col s12 m4">
                        <label for="couple">
                            <input name="event_for" value="couple" type="radio" id="couple"/>
                            <span class="black-text">Couple</span>
                        </label>
                        </div>
                    </div>
                    <div class="row center" id="beforeChild">
                        <div class="col s12 m6">
                            <button type="submit" name="customize" class="btn-large waves-effect waves-light teal darken-3">Customize Your Event Yourself </button>
                        </div>
                        <div class="col s12 hide-on-med-and-up">
                            <div class="section"></div>
                        </div>
                        <div class="col s12 m6">
                            <button type="submit" name="standard" class="btn-large waves-effect waves-light lime darken-2">Choose From Standard Packages</button>
                        </div>
                    </div>
                    
                </div>
                </form>
                </div>
                </div>
            </div>
        </div>
    </section>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const formSelectElems = document.querySelectorAll('select');
    M.FormSelect.init(formSelectElems, {});
    const datepickerElems = document.querySelectorAll('.datepicker');
    let todayDate = new Date();
    let tillMilliseconds = todayDate.getTime();
    M.Datepicker.init(datepickerElems, {
        format: 'yyyy-mm-dd',
        minDate: new Date(tillMilliseconds + 86400000) 
    });
    const timepickerElems = document.querySelectorAll('.timepicker');
    M.Timepicker.init(timepickerElems, {
        twelveHour: false
    });
    
  });
  //Radio Button Handlers
  let rad = document.event_order_form.event_for;
    let checked = null;
    for(let k=0; k < rad.length; k++) {
        if( rad[k].checked ) {
            checked = rad[k];
            insertDivForRadio(rad[k].id);
        }
    }
    for (var i = 0; i < rad.length; i++) {
        rad[i].addEventListener('change', function() {
            if (this !== checked) {
                checked = this;
                insertDivForRadio(checked.id);
            }
        });
    }
    //Adding DOM element
    function insertDivForRadio(radioId) {
        let existingElem = document.getElementById('event_for_div');
        if(existingElem) {
            existingElem.remove();
        }
        let elem = document.createElement('div');
        elem.className = 'row';
        elem.id = 'event_for_div';
        switch(radioId) {
            case 'person':
                elem.innerHTML = `<div class="input-field col s12">
                        <i class="material-icons prefix">emoji_people</i>
                        <input type="text" name="ev_for_person" id="ev_for_person" value="" class="black-text" required>
                        <label for="ev_for_person" class="active blue-text text-darken-3">Person's Name</label>
                        </div>`;
                break;
            case 'company':
                elem.innerHTML = `<div class="input-field col s12">
                        <i class="material-icons prefix">business_center</i>
                        <input type="text" name="ev_for_company" id="ev_for_company" value="" class="black-text" required>
                        <label for="ev_for_company" class="active blue-text text-darken-3">Company's Name</label>
                        </div>`;
                break;
            case 'couple':
                elem.innerHTML = `<div class="input-field col s12">
                        <i class="material-icons prefix">people_outline</i>
                        <input type="text" name="ev_for_person1" id="ev_for_person1" value="" class="black-text" required>
                        <label for="ev_for_person1" class="active blue-text text-darken-3">First Person's Name</label>
                        </div>
                        <div class="input-field col s12">
                        <i class="material-icons prefix">people_outline</i>
                        <input type="text" name="ev_for_person2" id="ev_for_person2" value="" class="black-text" required>
                        <label for="ev_for_person2" class="active blue-text text-darken-3">Second Person's Name</label>
                        </div>`;
                break;
        }
        let parent = document.getElementById('parent');
        let beforeChild = document.getElementById('beforeChild');
        parent.insertBefore(elem, beforeChild);
    }
</script>
<?php require(APPROOT.'/views/inc/footer.php'); ?>