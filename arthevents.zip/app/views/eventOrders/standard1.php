<?php require(APPROOT.'/views/inc/header.php'); ?>
  <section class="section">
    <div class="container">
    
    </div>
  </section>
<?php require(APPROOT.'/views/inc/footer.php'); ?>