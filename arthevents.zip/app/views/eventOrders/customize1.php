<?php require(APPROOT.'/views/inc/header.php'); ?>
  <section class="section">
    <div class="container">
      <div class="row">
        <div class="col s12">
          <div class="card blue lighten-5">
          <form action="<?php echo URLROOT; ?>/eventOrders/customize1" method="post">
            <div class="card-content">
              <div class="row">
                <div class="input-field col s12">
                <i class="material-icons prefix">room_service</i>
                <input type="text" id="service_heading" class="black-text" disabled>
                <label for="service_heading" class="active blue-text text-darken-3">Select Services you want in your event</label>
                <span class="blue-text text-darken-2"><strong>Kindly don't select venue if you have a place to conduct event eg- home etc.</strong><span>
                <span class="helper-text red-text"><?php echo $data['select_err']; ?></span>
                <?php foreach($data['serviceTypesObjArr'] as $servTypeObj): ?>
                <div class="col s12">
                <p>
                <label for="<?php echo $servTypeObj->stype_id; ?>" class="blue-text text-darken-3">
                  <input type="checkbox" name="stype_id[]" value="<?php echo $servTypeObj->stype_id; ?>" id="<?php echo $servTypeObj->stype_id; ?>" />
                  <span><?php echo $servTypeObj->name; ?></span>
                </label>
                </p>
                </div>
                <?php endforeach; ?>
                </div>
              </div>
              <div class="row">
                <div class="col s12 center">
                  <button type="submit" class="btn-large waves-effect waves-light blue darken-3 white-text"><i class="material-icons left">done</i>Select Products</button>
                </div>
              </div>
            </div>
          </form>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php require(APPROOT.'/views/inc/footer.php'); ?>