<?php require(APPROOT.'/views/inc/header.php'); ?>
<section class="section">
  <div class="container">
    <div class="row">
      <div class="col s12 blue darken-3">
      <h5 class="white-text center section"><em>Here is your final order.</em></h5>
      </div>
    </div>
    <div class="row">
      <div class="col s12">
        <div class="card-panel blue lighten-5 center">
          <div class="row">
            <div class="col s12">
              <!--Horizontal Card For Large Screens -->
              <div class="card small horizontal hide-on-med-and-down hoverable">
                <div class="card-image">
                  <img src="<?php echo URLROOT; ?>/public/img/eventTypeImgs/<?php echo $data['ev_type_img']; ?>" class="responsive-img">
                </div>
                <div class="card-stacked">
                  <div class="card-content">
                    <div class="row">
                      <div class="col s6">
                        <div class="row">
                          <div class="input-field col s12">
                            <i class="material-icons prefix">cake</i>
                            <input type="text" id="ev_name" value="<?php echo $data['ev_name']; ?>" disabled class="black-text">
                            <label for="ev_name" class="active blue-text text-darken-3">Event Name</label>
                          </div>
                          <div class="input-field col s12">
                            <i class="material-icons prefix">deck</i>
                            <input type="text" id="ev_type" value="<?php echo $data['ev_type']; ?>" disabled class="black-text">
                            <label for="ev_type" class="active blue-text text-darken-3">Event Type</label>
                          </div>
                          <div class="input-field col s12">
                            <i class="material-icons prefix">person</i>
                            <input type="text" id="ev_for" value="<?php echo $data['ev_for']; ?>" disabled class="black-text">
                            <label for="ev_for" class="active blue-text text-darken-3">Event For</label>
                          </div>
                        </div>
                      </div>
                      <div class="col s6">
                        <div class="row">
                          <div class="input-field col s12">
                            <i class="material-icons prefix">date_range</i>
                            <input type="text" id="ev_date" value="<?php echo $data['ev_date']; ?>" disabled class="black-text">
                            <label for="ev_date" class="active blue-text text-darken-3">Date</label>
                          </div>
                          <div class="input-field col s12">
                            <i class="material-icons prefix">schedule</i>
                            <input type="text" id="ev_time" value="<?php echo $data['ev_time']; ?>" disabled class="black-text">
                            <label for="ev_time" class="active blue-text text-darken-3">Time</label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!--Vertical Card for Med and Down Screens-->
              <div class="card small hide-on-large-only hide-on-small-only hoverable">
                <div class="card-content">
                  <div class="row">
                    <div class="col s12 m3">
                      <img src="<?php echo URLROOT; ?>/public/img/eventTypeImgs/<?php echo $data['ev_type_img']; ?>" class="responsive-img">
                    </div>
                    <div class="col s12 m9">
                      <div class="row">
                        <div class="col s12 m6">
                          <div class="row">
                            <div class="input-field col s12">
                              <i class="material-icons prefix">cake</i>
                              <input type="text" id="ev_name" value="<?php echo $data['ev_name']; ?>" disabled class="black-text">
                              <label for="ev_name" class="active blue-text text-darken-3">Event Name</label>
                            </div>
                            <div class="input-field col s12">
                              <i class="material-icons prefix">deck</i>
                              <input type="text" id="ev_type" value="<?php echo $data['ev_type']; ?>" disabled class="black-text">
                              <label for="ev_type" class="active blue-text text-darken-3">Event Type</label>
                            </div>
                            <div class="input-field col s12">
                              <i class="material-icons prefix">person</i>
                              <input type="text" id="ev_for" value="<?php echo $data['ev_for']; ?>" disabled class="black-text">
                              <label for="ev_for" class="active blue-text text-darken-3">Event For</label>
                            </div>
                          </div>
                        </div>
                        <div class="col s12 m6">
                          <div class="row">
                            <div class="input-field col s12">
                              <i class="material-icons prefix">date_range</i>
                              <input type="text" id="ev_date" value="<?php echo $data['ev_date']; ?>" disabled class="black-text">
                              <label for="ev_date" class="active blue-text text-darken-3">Date</label>
                            </div>
                            <div class="input-field col s12">
                              <i class="material-icons prefix">schedule</i>
                              <input type="text" id="ev_time" value="<?php echo $data['ev_time']; ?>" disabled class="black-text">
                              <label for="ev_time" class="active blue-text text-darken-3">Time</label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!--Vertical Card for small Screens-->
              <div class="card hide-on-med-and-up hoverable">
                <div class="card-content">
                  <div class="row">
                    <div class="col s12">
                      <img src="<?php echo URLROOT; ?>/public/img/eventTypeImgs/<?php echo $data['ev_type_img']; ?>" class="" style="height:250px; width:100%;">
                    </div>
                    <div class="col s12">
                      <div class="section">
                        <div class="divider blue darken-3" style="height:8px"></div>
                      </div>
                    </div>  
                    <div class="input-field col s12">
                      <i class="material-icons prefix">cake</i>
                      <input type="text" id="ev_name" value="<?php echo $data['ev_name']; ?>" disabled class="black-text">
                      <label for="ev_name" class="active blue-text text-darken-3">Event Name</label>
                    </div>
                    <div class="input-field col s12">
                      <i class="material-icons prefix">deck</i>
                      <input type="text" id="ev_type" value="<?php echo $data['ev_type']; ?>" disabled class="black-text">
                      <label for="ev_type" class="active blue-text text-darken-3">Event Type</label>
                    </div>
                    <div class="input-field col s12">
                      <i class="material-icons prefix">person</i>
                      <input type="text" id="ev_for" value="<?php echo $data['ev_for']; ?>" disabled class="black-text">
                      <label for="ev_for" class="active blue-text text-darken-3">Event For</label>
                    </div>
                    <div class="input-field col s12">
                      <i class="material-icons prefix">date_range</i>
                      <input type="text" id="ev_date" value="<?php echo $data['ev_date']; ?>" disabled class="black-text">
                      <label for="ev_date" class="active blue-text text-darken-3">Date</label>
                    </div>
                    <div class="input-field col s12">
                      <i class="material-icons prefix">schedule</i>
                      <input type="text" id="ev_time" value="<?php echo $data['ev_time']; ?>" disabled class="black-text">
                      <label for="ev_time" class="active blue-text text-darken-3">Time</label>
                    </div>
                  </div>
                </div>
              </div>
              <!--Event Services Divider-->
              <section class="section blue darken-3">
                <h5 class="white-text"><strong>Event Services</strong></h5>
              </section>
              <!-- Event Products selected by Customer-->
              <ul class="collection hoverable">
                <?php foreach($data['pdObjsArr'] as $pd): ?>
                <li class="collection-item avatar">
                  <div class="row">
                    <div class="col s12 m4 l4">
                    <img src="<?php echo URLROOT; ?>/public/img/productImgs/<?php echo $pd->pd_img_path; ?>" alt="<?php echo $pd->pd_id; ?>" style="height:auto; width:100px;" class="responsive-img">
                    <h6 class="blue-text text-darken-3"><strong><?php echo $pd->name; ?></strong></h6>
                    </div>
                    <div class="col s12 m8 l8">
                      <div class="row">
                        <p class="col s12"><strong>Product Name: </strong><?php echo $pd->pd_name; ?></p>
                        <p class="col s12"><strong>Product Company: </strong><?php echo $pd->company_name; ?></p>
                        <p class="col s12"><strong>Minimum Charge: </strong>₹<?php echo $pd->price_customer; ?></p>
                      </div>
                    </div>
                  </div>
                </li>
                <?php endforeach; ?>
              </ul>
              <!-- Grand Total-->
              <section class="section blue darken-3 white-text"><strong>Grand Total</strong></section>
              <div class="input-field col s12">
                <i class="material-icons prefix">payments</i>
                <input type="text" id="ev_cost_customer" value="₹<?php echo $data['ev_cost_customer']; ?>" disabled class="black-text">
                <label for="ev_cost_customer" class="active"></label>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col s12">
        <section class="section blue darken-3 center">
        <h6 class="white-text"><strong>Fill up few details and click place.</strong></h6>
        </section>
        <form action="<?php echo URLROOT; ?>/eventOrders/placeOrder" method="post">
        <div class="row section">
          <div class="col s12 l6">
            <div class="input-field col s12">
              <i class="material-icons prefix">phone</i>
              <input type="text" id="mob1" name="mob1" value="<?php echo $data['u_mob1']; ?>" class="black-text" pattern="^\d{10}$" minlength="10" maxlength="10" required>
              <label for="mob1" class="active blue-text text-darken-3">Mobile Number<sup>*</sup></label>
              <span class="helper-text red-text"></span>
            </div>
          </div>
          <div class="col s12 l6">
            <div class="input-field col s12">
              <i class="material-icons prefix">phone</i>
              <input type="text" id="mob2" name="mob2" value="<?php echo $data['u_mob2']; ?>" class="black-text" pattern="^\d{10}$" minlength="10" maxlength="10">
              <label for="mob2" class="active blue-text text-darken-3">Alternate Mobile Number</label>
            </div>
          </div>
          <div class="col s12 center">
            <p>
            <label for="terms">
              <input type="checkbox" id="terms" required>
              <span class="blue-text text-darken-3">I agree to all terms and condition of Arth Events.</span>
            </label>
            </p>
          </div>
          <button type="submit" class="btn waves-effect waves-light green darken-3 col s12">
            <i class="material-icons">done_all</i>Place
          </button>
        </div>
        </form>
      </div>
    </div>
  </div>
</section>
<?php require(APPROOT.'/views/inc/footer.php'); ?>