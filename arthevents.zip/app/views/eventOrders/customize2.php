<?php require(APPROOT.'/views/inc/header.php'); ?>
  <section class="section">
    <div class="container">
      <div class="row">
        <div class="col s12">
          <div class="card blue lighten-5">
            <div class="card-content">
              <div class="row">
                <div class="col s12">
                <h4 class="blue-text text-darken-3 center"><strong><?php echo $data['sTypeObj']->name; ?></strong></h4>
                <h6 class="blue-text text-darken-3 center"><em>Select a product under the above mentioned service</em></h6>
                <!--<span class="helper-text red-text"><?php echo ''; ?></span>-->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <form action="<?php echo URLROOT; ?>/eventOrders/customize2/<?php echo $data['sTypeObj']->stype_id; ?>" method="post">
      <div class="row">

        <?php foreach($data['pdsUnderStypeArr'] as $pdObj): ?> 
        <div class="col s12 m6 l6">
          <div class="card blue lighten-5">
            <div class="card-image">
            <img src="<?php echo URLROOT; ?>/public/img/productImgs/<?php echo $pdObj->pd_img_path; ?>" alt="product-image" class="responsive-img">
            </div>
            <div class="card-content">
            <h5 class="blue-text text-darken-3 center"><?php echo $pdObj->company_name; ?></h5>
            <h6 class="black-text center"><strong>Product Name </strong><?php echo $pdObj->pd_name; ?></h6>
              <ul class="collection with-header hoverable">
                <li class="collection-header center blue white-text darken-3"><strong>Product Features</strong></li>
                <?php for($i=1; $i<=5; $i++): ?>
                  <?php $variable = 'pd_feature'.$i; ?>
                  <?php if( !is_null($pdObj->$variable) ): ?>
                  <li class="collection-item"><?php echo $pdObj->$variable; ?></li>
                  <?php endif; ?>
                <?php endfor; ?>
              </ul>
            </div>
            <div class="card-action">
              <div class="row">
                <div class="col s6">
                <h6>
                  <label for="<?php echo $pdObj->pd_img_path; ?>">
                    <input name="<?php echo $data['sTypeObj']->stype_id; ?>" type="radio" id="<?php echo $pdObj->pd_img_path; ?>" value="<?php echo $pdObj->pd_id; ?>" required="required"/>
                    <span class="blue-text text-darken-3"><strong>Like It? Select.</strong></span>
                  </label>
                </h6>
                </div>
                <div class="col s6">
                <h6><strong>Min. Charges ₹</strong><?php echo $pdObj->price_customer; ?></h6>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; ?>

      </div>
      <div class="row">
        <button type="submit" class="col s12 btn-large waves-effect waves-light blue darken-3">
        <div class="valign-wrapper">
        <i class="material-icons">navigate_next</i>
        <span style="width: 100%; text-align: center;">Next</span>
        </div>
        </button>
      </div>
      </form>
    </div>
  </section>
<?php require(APPROOT.'/views/inc/footer.php'); ?>