<?php require(APPROOT.'/views/inc/header.php'); ?>
  <section class="section">
    <div class="container">
      <div class="row">
        <div class="col s12">
          <a href="<?php echo URLROOT; ?>/eventOrders/index" class="btn waves-effect waves-light blue darken-3"><i class="material-icons left">arrow_back_ios</i>Back</a>
        </div>
        <div class="col s12">
          <p>Sorry, This part of site is under construction. Kindly Customize Your Event For Now!</p>
        </div>
      </div>
    </div>
  </section>
<?php require(APPROOT.'/views/inc/footer.php'); ?>