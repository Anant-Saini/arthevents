<?php require(APPROOT.'/views/inc/header.php'); ?>
  <!--Page Heading-->
  <div class="row">
    <div class="col s12 center blue lighten-5">
      <h3 class="red-text text-darken-3"><i class="material-icons small">warning</i>Delete Account Permanently</h3>
      <p><strong>Clicking delete will permanently delete your account with all your saved events. Take action carefully.</strong></p>
    </div>
  </div>
  <!--Delete Form-->
  <section class="section">
    <div class="container">
      <div class="row">
        <div class="col s12">
          <div class="card blue lighten-5">
            <div class="card-title red-text text-darken-3 center">
              <h4>Are you sure?</h4>
            </div>
            <div class="divider"></div>
            <div class="card-content black-text">
              <ul class="collection with-header hoverable">
                <li class="collection-header blue darken-3"><h5 class="white-text">If you are not sure what you are doing kindly click BACK. Otherwise clicking delete will result in the following:</h5></li>
                <li class="collection-item blue darken-3 white-text">Permanent erasure of your account data from our system and you won't be able to login again into this account.<li>
                <li class="collection-item blue darken-3 white-text">All your saved events which you want to conduct in future or your past records of successfully conducted events will be erased.<li>
                <li class="collection-item blue darken-3 white-text">Clicking delete will automatically log you out and in order to come back again, you will first need to register yourself with a new account.<li>
              </ul>
            </div>
            <div class="card-action">
              <div class="row">
                <div class="col s6 center">
                  <form action="<?php echo URLROOT; ?>/userAccountSettings/deleteAcc" method="post">
                    <input type="hidden" name="user_id" value="<?php echo $data['user_id']; ?>">
                    <button type="submit" class="btn waves-effect waves-light red darken-3"><i class="material-icons left hide-on-small-only">delete_forever</i>Delete</button>
                  </form>
                </div>
                <div class="col s6 center">
                  <a href="<?php echo URLROOT; ?>/userAccountSettings/index" class="btn waves-effect waves-light blue darken-3"><i class="material-icons left hide-on-small-only">navigate_before</i>Back</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php require(APPROOT.'/views/inc/footer.php'); ?>