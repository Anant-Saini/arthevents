<?php require(APPROOT.'/views/inc/header.php'); ?>
  <!--Page Heading-->
  <div class="row">
    <div class="col s12 center blue lighten-5">
      <h3 class="blue-text text-darken-3"><i class="material-icons small">settings</i>Edit Main Settings</h3>
      <p>Edit the below form and save changes.</p>
      </div>
  </div>
  <!--Form Data-->
  <section class="section">
    <div class="container">
      <div class="row">
        <div class="col s12">
          <div class="card blue lighten-5 center">
            <div class="card-title blue-text text-darken-3">
              <h4>Main Settings</h4>
            </div>
            <div class="divider"></div>
            <div class="card-content">
                <form action="<?php echo URLROOT; ?>/userAccountSettings/editMain" method="post">
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">face</i>
                    <input type="text" name="name" id="name" value="<?php echo $data['name']; ?>" class="black-text" required>
                    <label for="name" class="active blue-text text-darken-3">Your Name</label>
                    <span class="helper-text red-text"><?php echo $data['name_err']; ?></span>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">mail</i>
                    <input type="email" name="email" id="email" value="<?php echo $data['email']; ?>" class="black-text" disabled>
                    <label for="email" class="active blue-text text-darken-3">Your Email</label>
                    <span class="helper-text red-text"><?php echo $data['email_err']; ?></span>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">call</i>
                    <input type="text" name="mob_1" id="mob_1" value="<?php echo $data['mob_1']; ?>" class="black-text">
                    <label for="mob_1" class="active blue-text text-darken-3">Mobile Number</label>
                    <span class="helper-text red-text"><?php echo $data['mob_1_err']; ?></span>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">call</i>
                    <input type="text" name="mob_2" id="mob_2" value="<?php echo $data['mob_2']; ?>" class="black-text">
                    <label for="mob_2" class="active blue-text text-darken-3">Alternate Mobile Number</label>
                    <span class="helper-text red-text"><?php echo $data['mob_2_err']; ?></span>
                  </div>
                </div>
                <div class="card-action">
                  <div class="row">
                    <div class="col s6 center">
                    <button type="submit" class="btn waves-effect waves-light blue darken-3"><i class="material-icons left hide-on-small-only">save_alt</i>Save</button>
                    </div>
                    <div class="col s6 center">
                    <a href="<?php echo URLROOT; ?>/userAccountSettings/index" class="btn waves-effect waves-light blue darken-3"><i class="material-icons left hide-on-small-only">navigate_before</i>Back</a>
                    </div>
                  </div>
                </div>
                </form>
            </div>    
          </div>
        </div>
      </div>
    </div>
  </section>
<?php require(APPROOT.'/views/inc/footer.php'); ?>