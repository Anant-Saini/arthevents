<?php require(APPROOT.'/views/inc/header.php'); ?>
  <!--Page Heading-->
  <div class="row">
    <div class="col s12 center blue lighten-5">
      <h3 class="blue-text text-darken-3"><i class="material-icons small">settings</i>Change Password</h3>
      <p>Fill the below fields to change your password.</p>
      </div>
  </div>
  <!--Form Data-->
  <section class="section">
    <div class="container">
      <div class="row">
        <div class="col s12">
          <div class="card blue lighten-5 center">
            <div class="card-title blue-text text-darken-3">
              <h4>Change Password</h4>
            </div>
            <div class="divider"></div>
            <div class="card-content">
                <form action="<?php echo URLROOT; ?>/userAccountSettings/changePassword" method="post">
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">lock</i>
                    <input type="password" name="old_pwd" value="<?php echo $data['old_pwd']; ?>" id="old_pwd" class="black-text" required>
                    <label for="old_pwd" class="active blue-text text-darken-3">Current Password</label>
                    <span class="helper-text red-text"><?php echo $data['old_pwd_err']; ?></span>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">lock_open</i>
                    <input type="password" name="new_pwd" id="new_pwd" value="<?php echo $data['new_pwd']; ?>" class="black-text" required>
                    <label for="new_pwd" class="active blue-text text-darken-3">New Password</label>
                    <span class="helper-text red-text"><?php echo $data['new_pwd_err']; ?></span>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">lock_open</i>
                    <input type="password" name="conf_new_pwd" id="conf_new_pwd" value="<?php echo $data['conf_new_pwd']; ?>" class="black-text" required>
                    <label for="conf_new_pwd" class="active blue-text text-darken-3">Confirm New Password</label>
                    <span class="helper-text red-text"><?php echo $data['conf_new_pwd_err']; ?></span>
                  </div>
                </div>
                <div class="card-action">
                  <div class="row">
                    <div class="col s6 center">
                    <button type="submit" class="btn waves-effect waves-light blue darken-3"><i class="material-icons left hide-on-small-only">swap_horiz</i>Change</button>
                    </div>
                    <div class="col s6 center">
                    <a href="<?php echo URLROOT; ?>/userAccountSettings/index" class="btn waves-effect waves-light blue darken-3"><i class="material-icons left hide-on-small-only">navigate_before</i>Back</a>
                    </div>
                  </div>
                </div>
                </form>
            </div>    
          </div>
        </div>
      </div>
    </div>
  </section>
<?php require(APPROOT.'/views/inc/footer.php'); ?>