<?php require(APPROOT.'/views/inc/header.php'); ?>
  <!--Page Heading-->
  <div class="row">
    <div class="col s12 center blue lighten-5">
      <h3 class="blue-text text-darken-3"><i class="material-icons small">settings</i>Edit Address Settings</h3>
      <p>Edit the below form and save changes.</p>
      </div>
  </div>
  <!--Form Data-->
  <section class="section">
    <div class="container">
      <div class="row">
        <div class="col s12">
          <div class="card blue lighten-5 center">
            <div class="card-title blue-text text-darken-3">
              <h4>Address Settings</h4>
            </div>
            <div class="divider"></div>
            <div class="card-content">
                <form action="<?php echo URLROOT; ?>/userAccountSettings/editAddress" method="post">
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">house</i>
                    <input type="text" name="house_no" id="house_no" value="<?php echo $data['house_no']; ?>" class="black-text">
                    <label for="house_no" class="active blue-text text-darken-3">House Number</label>
                    <span class="helper-text red-text"><?php echo $data['house_no_err']; ?></span>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">domain</i>
                    <input type="text" name="street" id="street" value="<?php echo $data['street']; ?>" class="black-text">
                    <label for="street" class="active blue-text text-darken-3">Street or Colony</label>
                    <span class="helper-text red-text"><?php echo $data['street_err']; ?></span>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">emoji_flags</i>
                    <input type="text" name="landmark" id="landmark" value="<?php echo $data['landmark']; ?>" class="black-text">
                    <label for="landmark" class="active blue-text text-darken-3">Landmark</label>
                    <span class="helper-text red-text"><?php echo $data['landmark_err']; ?></span>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">location_city</i>
                    <input type="text" name="city" id="city" value="<?php echo $data['city']; ?>" class="black-text">
                    <label for="city" class="active blue-text text-darken-3">City/Town/Village</label>
                    <span class="helper-text red-text"><?php echo $data['city_err']; ?></span>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">local_shipping</i>
                    <input type="text" name="pincode" id="pincode" value="<?php echo $data['pincode']; ?>" class="black-text">
                    <label for="pincode" class="active blue-text text-darken-3">Pincode</label>
                    <span class="helper-text red-text"><?php echo $data['pincode_err']; ?></span>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">terrain</i>
                    <input type="text" name="state" id="state" value="<?php echo $data['state']; ?>" class="black-text">
                    <label for="state" class="active blue-text text-darken-3">State</label>
                    <span class="helper-text red-text"><?php echo $data['state_err']; ?></span>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12">
                    <i class="material-icons prefix">flag</i>
                    <input type="text" name="country" id="country" value="<?php echo $data['country']; ?>" class="black-text" disabled>
                    <label for="country" class="active blue-text text-darken-3">Country</label>
                    <span class="helper-text red-text"><?php echo $data['country_err']; ?></span>
                  </div>
                </div>
                <div class="card-action">
                  <div class="row">
                    <div class="col s6 center">
                    <button type="submit" class="btn waves-effect waves-light blue darken-3"><i class="material-icons left hide-on-small-only">save_alt</i>Save</button>
                    </div>
                    <div class="col s6 center">
                    <a href="<?php echo URLROOT; ?>/userAccountSettings/index" class="btn waves-effect waves-light blue darken-3"><i class="material-icons left hide-on-small-only">navigate_before</i>Back</a>
                    </div>
                  </div>
                </div>
                </form>
            </div>    
          </div>
        </div>
      </div>
    </div>
  </section>
<?php require(APPROOT.'/views/inc/footer.php'); ?>