<?php require(APPROOT.'/views/inc/header.php'); ?>
    <!--Page Heading-->
    <div class="row">
        <div class="col s12 center blue lighten-5">
        <h3 class="blue-text text-darken-3"><i class="material-icons small">settings</i>Account Settings</h3>
        </div>
    </div>
    <!--Logout, Change Password and Delete Account Button-->
    <div class="container">
    <div class="row">
        <div class="col s12 m4 l4 center">
        <div class="section">
        <a href="<?php echo URLROOT; ?>/users/logout" class="btn blue darken-3 waves-effect waves-light"><i class="material-icons left">all_out</i>Logout</a>
        </div>
        </div>
        <div class="col s12 m4 l4 center">
        <div class="section">
        <a href="<?php echo URLROOT; ?>/userAccountSettings/changePassword" class="btn yellow darken-3 waves-effect waves-light"><i class="material-icons left">enhanced_encryption</i>Change Password</a>
        </div>
        </div>
        <div class="col s12 m4 l4 center">
        <div class="section">
        <a href="<?php echo URLROOT; ?>/userAccountSettings/deleteAcc" class="btn waves-effect waves-light red darken-3"><i class="material-icons left">delete</i>Delete Account</a>
        </div>
        </div>
    </div>
    </div>
    <!--Flash Messages-->
    <div class="container">
    <?php flash('user_info_update_success'); ?>
    <?php flash('user_address_info_update_success'); ?>
    <?php flash('user_pwd_update_success'); ?>
    </div> 
    <!--Form Data-->
    <section class="section">
        <div class="container">
            <div class="row">
                <div class="col s12 m6 l5">
                    <div class="card blue lighten-5 center">
                        <div class="card-title blue-text text-darken-3">
                            <h4>Main Settings</h4>
                        </div>
                        <div class="divider"></div>
                        <div class="card-content">
                            <div class="row">
                                <div class="input-field col s12">
                                    <i class="material-icons prefix">face</i>
                                    <input type="text" name="name" id="name" value="<?php echo $data['name']; ?>" disabled class="black-text">
                                    <label for="name" class="active blue-text text-darken-3">Your Name</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s12">
                                    <i class="material-icons prefix">mail</i>
                                    <input type="text" name="email" id="email" value="<?php echo $data['email']; ?>" disabled class="black-text">
                                    <label for="email" class="active blue-text text-darken-3">Your Email</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s12">
                                    <i class="material-icons prefix">call</i>
                                    <input type="text" name="mob_1" id="mob_1" value="<?php echo $data['mob_1']; ?>" disabled class="black-text">
                                    <label for="mob_1" class="active blue-text text-darken-3">Mobile Number</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s12">
                                    <i class="material-icons prefix">call</i>
                                    <input type="text" name="mob_2" id="mob_2" value="<?php echo $data['mob_2']; ?>" disabled class="black-text">
                                    <label for="mob_2" class="active blue-text text-darken-3">Alternate Mobile Number</label>
                                </div>
                            </div>
                            <div class="card-action">
                                <a href="<?php echo URLROOT; ?>/userAccountSettings/editMain" class="btn waves-effect waves-light blue darken-3"><i class="material-icons left">create</i>Edit</a>
                            </div>
                        </div>    
                    </div>
                </div>
                <div class="col s12 m6 l5 offset-l2">
                    <div class="card blue lighten-5 center">
                        <div class="card-title blue-text text-darken-3">
                            <h4>Address Settings</h4>
                        </div>
                        <div class="divider"></div>
                        <div class="card-content">
                            <div class="row">
                                <div class="input-field col s12">
                                    <i class="material-icons prefix">house</i>
                                    <input type="text" name="house_no" id="house_no" value="<?php echo $data['house_no']; ?>" disabled class="black-text">
                                    <label for="house_no" class="active blue-text text-darken-3">House Number</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s12">
                                    <i class="material-icons prefix">domain</i>
                                    <input type="text" id="street" name="street" value="<?php echo $data['street']; ?>" disabled class="black-text">
                                    <label for="street" class="active blue-text text-darken-3">Street or Colony</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s12">
                                    <i class="material-icons prefix">emoji_flags</i>
                                    <input type="text" id="landmark" name="landmark" value="<?php echo $data['landmark']; ?>" disabled class="black-text">
                                    <label for="landmark" class="active blue-text text-darken-3">Landmark</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s12">
                                    <i class="material-icons prefix">location_city</i>
                                    <input type="text" id="city" name="city" value="<?php echo $data['city']; ?>" disabled class="black-text">
                                    <label for="city" class="active blue-text text-darken-3">City/Town/Village</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s12">
                                    <i class="material-icons prefix">local_shipping</i>
                                    <input type="text" id="pincode" name="pincode" value="<?php echo $data['pincode']; ?>" disabled class="black-text">
                                    <label for="pincode" class="active blue-text text-darken-3">Pincode</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s12">
                                    <i class="material-icons prefix">terrain</i>
                                    <input type="text" id="state" name="state" value="<?php echo $data['state']; ?>" disabled class="black-text">
                                    <label for="state" class="active blue-text text-darken-3">State</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s12">
                                    <i class="material-icons prefix">flag</i>
                                    <input type="text" id="country" name="country" value="<?php echo $data['country']; ?>" disabled class="black-text">
                                    <label for="country" class="active blue-text text-darken-3">Country</label>
                                </div>
                            </div>
                            <div class="card-action">
                                <a href="<?php echo URLROOT; ?>/userAccountSettings/editAddress" class="btn waves-effect waves-light blue darken-3"><i class="material-icons left">create</i>Edit</a>
                            </div>
                        </div>    
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Delete Account Button-->
    <div class="row">
        
    </div>
<?php require(APPROOT.'/views/inc/footer.php'); ?>