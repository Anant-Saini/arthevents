<?php require(APPROOT.'/views/inc/header.php'); ?>
    <section class="section">
    <div class="row container">
        <form action="<?php echo URLROOT; ?>/users/register" method="post" class="col s12">
            <div class="row">
                <div class="input-field col s12 blue-text text-darken-3">
                <i class="material-icons prefix">face</i>
                <input type="text" name="name" id="name" value="<?php echo $data['name']; ?>" class="validate" required>
                <label class="active" for="name" data-error="">Your Name</label>
                <span class="helper-text red-text"><?php echo $data['name_err']; ?></span>
                </div>
            </div>
            <div class="row">
                <div class="input-field col s12 blue-text text-darken-3">
                <i class="material-icons prefix">email</i>
                <input type="email" name="email" id="email" value="<?php echo $data['email']; ?>" class="validate" required>
                <label class="active" for="email" data-error="">Your Email</label>
                <span class="helper-text red-text"><?php echo $data['email_err']; ?></span>
                </div>
            </div>
            <div class="row">
                <div class="input-field col s12 blue-text text-darken-3">
                <i class="material-icons prefix">vpn_key</i>
                <input type="password" name="pwd" id="pwd" value="<?php echo $data['pwd']; ?>" class="validate" required>
                <label class="active" for="pwd" data-error="">Your Password</label>
                <span class="helper-text red-text"><?php echo $data['pwd_err']; ?></span>
                </div>
            </div>
            <div class="row">
                <div class="input-field col s12 blue-text text-darken-3">
                <i class="material-icons prefix">vpn_key</i>
                <input type="password" name="confirm_pwd" id="confirm-pwd" value="<?php echo $data['confirm_pwd']; ?>" class="validate" required>
                <label class="active" for="confirm-pwd" data-error="">Confirm Password</label>
                <span class="helper-text red-text"><?php echo $data['confirm_pwd_err']; ?></span>
                </div>
            </div>
            <div class="row">
                <div class="col s12 m4 l4 center">
                <button class="waves-effect waves-light btn blue darken-3 container" type="submit">Register <i class="material-icons right">send</i></button>
                </div>
                <div class="col s12 m2 l2"><p></p></div>
                <div class="col s12 m6 l6 center">
                <a href="<?php echo URLROOT; ?>/users/login" class="btn blue darken-3 container">Already have an account?<i class="material-icons right">login</i></a>
                </div>
            </div>
        </form>
    </div>
    </section>
<?php require(APPROOT.'/views/inc/footer.php'); ?>