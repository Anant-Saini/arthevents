<?php
 class AdminAccountSettings extends Controller {
   private $adminAccModel;
   public function __construct() {
    //check if AdminLoggedIn
    if( !isAdminLoggedIn() ) {
      redirect('dashboards/index');
    }
    $this->adminAccModel = $this->model('AdminAccountSetting');
   }
   //Default Method
   public function index() {
    $adminInfo = $this->adminAccModel->getAdminInfoById($_SESSION['admin_id']);
     if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['updateDetails'])) {
        $data = [
          'name' => testInput($_POST['name']),
          'name_err' => '',
          'email' => testInput($_POST['email']),
          'email_err' => '',
          'img_path' => isNull($adminInfo->img_path) 
        ];
        if( strlen($data['name']) > 35) {
          //validate Name
          $data['name_err'] = 'Name can\'t be more than 35 characters long';
          $this->view('dashboard/adminAccountSettings/index', $data);
        } elseif (!filter_var($data['email'], FILTER_VALIDATE_EMAIL) === true) {
          //Validate Email
          $data['email_err'] = 'Kindly enter a valid email address';
          $this->view('dashboard/adminAccountSettings/index', $data);
        } else {
          //Update Admin Details
          $this->adminAccModel->updateAdminDetails($data['email'], $data['name'],$_SESSION['admin_id']);
          $this->resetSession();
          flash('adminDetailsUpdated', 'Successfully updated admin details.');
          redirect('adminAccountSettings/index');
        }
     } else {
      //Data to be send to view
      $data = [
          'name' => isNull($adminInfo->name),
          'name_err' => '',
          'email' => isNull($adminInfo->email),
          'email_err' => '',
          'img_path' => isNull($adminInfo->img_path) 
      ];
      $this->view('dashboard/adminAccountSettings/index', $data);
     }
   }
   //reset Session method
   public function resetSession() {
    $admin = $this->adminAccModel->getAdminInfoById($_SESSION['admin_id']);
    session_start();
    $_SESSION['admin_name'] = $admin->name;
    $_SESSION['admin_email'] = $admin->email;
   }
   //change Password Method
   public function changePassword() {
     if($_SERVER['REQUEST_METHOD'] == 'POST') {
      $data = [
        'old_pwd' => testInput($_POST['old_pwd']),
        'new_pwd' => testInput($_POST['new_pwd']),
        'conf_new_pwd' => testInput($_POST['conf_new_pwd']),
        'old_pwd_err' => '',
        'new_pwd_err' => '',
        'conf_new_pwd_err' => ''
      ];
      //Validate New Password
      if( strlen($data['new_pwd']) < 8 ) {
          $data['new_pwd_err'] = 'Password must be of atleast 8 characters';
          $data['conf_new_pwd'] = '';
          $this->view('dashboard/adminAccountSettings/changePassword', $data);
      } elseif ( !preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $data['new_pwd']) ) {
          $data['new_pwd_err'] = 'Password must contain atleast one special character';
          $data['conf_new_pwd'] = '';
          $this->view('dashboard/adminAccountSettings/changePassword', $data);
      } elseif ( strcmp($data['new_pwd'], $data['conf_new_pwd']) != 0 ) {
          $data['conf_new_pwd_err'] = 'Confirm Password do not match new password';
          $data['conf_new_pwd'] = '';
          $this->view('dashboard/adminAccountSettings/changePassword', $data);
      } else {
          $adminPwdInfo = $this->adminAccModel->getAdminPwdById($_SESSION['admin_id']);
          if( strcmp($data['old_pwd'], $adminPwdInfo->pwd) != 0 ) {
              $data['old_pwd_err'] = 'This is not your current password';
              $this->view('dashboard/adminAccountSettings/changePassword', $data);
          } elseif( strcmp($data['new_pwd'], $adminPwdInfo->pwd) == 0 ) {
              $data['new_pwd_err'] = 'New Password can not be same as current password';
              $data['conf_new_pwd'] = '';
              $this->view('dashboard/adminAccountSettings/changePassword', $data);
          } else {
              $this->adminAccModel->updateAdminPwdById($data['new_pwd'], $_SESSION['admin_id']);
              flash('userPwdUpdateSuccess', 'Your Password has been updated successfully');
              redirect('adminAccountSettings/index');
          }
      }

     } else {
       $data = [
         'old_pwd' => '',
         'old_pwd_err' => '',
         'new_pwd' => '',
         'new_pwd_err' => '',
         'conf_new_pwd' => '',
         'conf_new_pwd_err' => ''
       ];
       $this->view('dashboard/adminAccountSettings/changePassword', $data);
     }
   }
   //Update Admin Image
   public function updateAdminImg() {
     if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['updateImage']) ) {
       $data = [
        'adminImg' => $_FILES['adminImg'],
        'adminImg_err' => ''
       ];
       //Image Details
       $adminImgError = $data['adminImg']['error'];
       if( $adminImgError !== 4) {

         $adminImgName = $data['adminImg']['name'];
         $adminImgTmpName = $data['adminImg']['tmp_name'];
         $adminImgSize = $data['adminImg']['size'];

         //Image Extension
         $adminImgExt = explode('.', $adminImgName);
         $adminImgActualExt = strtolower(end($adminImgExt));
         //Extensions which are allowed
         $allowed = ['jpg','jpeg','png'];
         //Error Handlers
         if( !in_array($adminImgActualExt, $allowed) ) {
           $data['adminImg_err'] = 'Only JPEG/JPG and PNG files are allowed!';
         } else {
           if( $adminImgError !== 0 ) {
             $data['adminImg_err'] = 'There is an error uploading this file!';
           } else {
             if( $adminImgSize > 500000) {
               $data['adminImg_err'] = 'Maximum File size allowed is 500KB!';
             }
           }
         }
       } else {
         $data['adminImg_err'] = 'Something went wrong!! May be no image was selected. Try Again!';
       }
       if( empty($data['adminImg_err']) ) {
          $result = $this->adminAccModel->updateAdminImg($adminImgTmpName, $adminImgActualExt, $_SESSION['admin_id']);
          if( $result !== 'success') {
            die($result);
          } else {
            flash('img_updated','Image successfully updated!');
            $this->index();
          }
       } else {
          flash('img_updated', $data['adminImg_err'], 'alert alert-danger');
          $this->index();
       }
     } elseif ( $_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['deleteImage']) ) {
      $adminInfo = $this->adminAccModel->getAdminInfoById($_SESSION['admin_id']);
      if($adminInfo->img_path != 'noAdminImg.png') {
        $result = $this->adminAccModel->deleteAdminImg($adminInfo->img_path, $_SESSION['admin_id']);
        if( $result !== 'success') {
          die($result);
        } else {
          flash('img_updated','Image successfully deleted!');
          $this->index();
        }
      } else {
        flash('img_updated','No Image is there for deletion!', 'alert alert-danger');
        $this->index();
      }
     }  
   }
  }