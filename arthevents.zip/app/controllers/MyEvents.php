<?php
    class MyEvents extends Controller {
        private $myEventsModel;
        public function __construct() {
            //check if loggedIn
            if( !isLoggedIn() ) {
                redirect('pages/index');
            }
            $this->myEventsModel = $this->model('MyEvent');
        }
        //Default Method
        public function index() {
            $eventOrderObjArr = $this->myEventsModel->getEventOrderObjArr($_SESSION['user_id']);
            //Data to be send to view
            $data = [
                'eventOrderObjArr' => $eventOrderObjArr
            ];
            $this->view('myEvents/index', $data);
        }
        //showEventOrder method
        public function showEventOrder($evOrderId) {
            $eventOrder = $this->myEventsModel->getEventOrderById($evOrderId);
            $evPdIdArr = json_decode($eventOrder->ev_pd_id_array);
            foreach ($evPdIdArr as $pdId) {
                $pd = $this->myEventsModel->getPdObjFromId($pdId);
                $pdObjsArr[] = $pd;
            }
            $data = [
                'eventOrder' => $eventOrder,
                'pdObjsArr' => $pdObjsArr
            ];
            $this->view('myEvents/showEventOrder', $data);
        }
        //Delete EventOrder Method
        public function deleteEventOrder($evOrderId) {
            $this->myEventsModel->delEventOrderById($evOrderId);
            flash('Event Delete Success', 'Event Has Been Deleted Successfully!');
            redirect('myEvents/index');
        }
    }