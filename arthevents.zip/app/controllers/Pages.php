<?php
    class Pages extends Controller {
        public function __construct() {
            
        }
        public function index() {
            //Data to be passed in View
            $data = [
            ];
            //Loading View
            $this->view('pages/index', $data);
        }
    }