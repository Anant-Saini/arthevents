<?php 
class Dashboards extends Controller {
  private $dashboardModel;
  public function __construct() {
    $this->dashboardModel = $this->model('Dashboard');
  }
  //default index method
  public function index() {
    if( !isAdminLoggedIn() ) {
      if( $_SERVER['REQUEST_METHOD'] == 'POST') {
        $data = [
          'email' => testInput($_POST['email']),
          'email_err' => '',
          'pwd' => testInput($_POST['pwd']),
          'pwd_err' => ''
        ];
        //Validate Email
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL) === true) {
          $data['email_err'] = 'It is not a valid email address';
          $this->view('dashboard/pages/index', $data);
        } elseif (!$this->dashboardModel->isEmailRegistered($data['email'])) {
          $data['email_err'] = 'This email is not the required admin email!';
          $this->view('dashboard/pages/index', $data);
        } else {
          //Validate Password
          $admin = $this->dashboardModel->getAdminByEmail($data['email']);
          if(strcmp($data['pwd'], $admin->pwd) != 0) {
              $data['pwd_err'] = 'Either email or password is wrong!!';
              $this->view('dashboard/pages/index', $data);
          } else {
              $this->createSession($admin);
              redirect('dashboards/loggedIn');
          }
        }
      } else {
        //Initialize Data for passing into view
        $data = [
          'email' => '',
          'email_err' => '',
          'pwd' => '',
          'pwd_err' => ''
        ];
        //Load View
        $this->view('dashboard/pages/index', $data);
      }
    } else {
      redirect('dashboards/loggedIn');
    }
    
  }
  //method to create login session
  public function createSession($admin) {
    session_start();
    $_SESSION['admin_id'] = $admin->admin_id;
    $_SESSION['admin_name'] = $admin->name;
    $_SESSION['admin_email'] = $admin->email;
  }
  //method to logout
  public function logout() {
      session_start();
      unset($_SESSION['admin_name']);
      unset($_SESSION['admin_email']);
      session_destroy();
      redirect('dashboards/index');
  }
  //method after successful loggingIn
  public function loggedIn() {
    $numEvents = $this->dashboardModel->getCountUpcomingUncompletedEvents();
    $numUsers = $this->dashboardModel->getCountUsers();
    $numSerProviders = $this->dashboardModel->getCountSerProviders();
    $upcomEventOrders = $this->dashboardModel->getTenUpcomingEventOrders();
    $data = [
      'numEvents' => $numEvents,
      'numUsers' => $numUsers,
      'numSerProviders' => $numSerProviders,
      'upcomEventOrders' => $upcomEventOrders
    ];
    $this->view('dashboard/pages/dashboard', $data);
  }
}