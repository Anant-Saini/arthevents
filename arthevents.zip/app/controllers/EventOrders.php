<?php
    class EventOrders extends Controller {
        private $evOrderModel;
        public function __construct() {
            //If not logged in
            if( !isLoggedIn() ) {
                redirect('pages/index');
            }
            $this->evOrderModel = $this->model('EventOrder');
        }
        //default method
        public function index() {
            $eventTypesObjArr = $this->evOrderModel->getEvTypesObjArr();
            if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['customize'])) { 
                $data = [
                    'name' => testInput($_POST['name']),
                    'event_types' => $eventTypesObjArr,
                    'etype_id' => testInput($_POST['etype_id']),
                    'date' => testInput($_POST['date']),
                    'time' => testInput($_POST['time']),
                    'ev_for' => '',
                    'name_err' => '',
                    'etype_err' => ''
                ];
                $eventFor = testInput($_POST['event_for']);
                switch($eventFor) {
                    case 'person':
                        $data['ev_for'] = testInput($_POST['ev_for_person']);
                        break;
                    case 'company':
                        $data['ev_for'] = testInput($_POST['ev_for_company']);
                        break;
                    case 'couple':
                        $person1 = testInput($_POST['ev_for_person1']);
                        $person2 = testInput($_POST['ev_for_person2']);
                        $data['ev_for'] = $person1.' and '.$person2;
                        break;
                }
                if( strlen($data['name']) > 50 ) {
                    $data['name_err'] = "Event Name can't be more than 50 characters long";
                    $this->view('eventOrders/index', $data); 
                } elseif ($data['etype_id'] === 'none') {
                    $data['etype_err'] = 'Kindly select an event type';
                    $this->view('eventOrders/index', $data);
                } elseif (empty($data['name_err']) && empty($data['etype_err'])) {   
                    session_start();
                    $_SESSION['event_orders_table_data']['name'] = $data['name'];
                    $_SESSION['event_orders_table_data']['date'] = $data['date'];
                    $_SESSION['event_orders_table_data']['time'] = $data['time'];
                    $_SESSION['event_orders_table_data']['ev_for'] = $data['ev_for'];
                    $_SESSION['event_orders_table_data']['etype_id'] = $data['etype_id'];
                    redirect('eventOrders/customize1');
                }

            } else if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['standard'])) {
                $data = [
                    'name' => testInput($_POST['name']),
                    'event_types' => $eventTypesObjArr,
                    'etype_id' => testInput($_POST['etype_id']),
                    'date' => testInput($_POST['date']),
                    'time' => testInput($_POST['time']),
                    'ev_for' => '',
                    'name_err' => '',
                    'etype_err' => ''
                ];
                $eventFor = testInput($_POST['event_for']);
                switch($eventFor) {
                    case 'person':
                        $data['ev_for'] = testInput($_POST['ev_for_person']);
                        break;
                    case 'company':
                        $data['ev_for'] = testInput($_POST['ev_for_company']);
                        break;
                    case 'couple':
                        $person1 = testInput($_POST['ev_for_person1']);
                        $person2 = testInput($_POST['ev_for_person2']);
                        $data['ev_for'] = $person1.' and '.$person2;
                        break;
                }
                if( strlen($data['name']) > 50 ) {
                    $data['name_err'] = 'Event Name can\'t be more than 50 characters long';
                    $this->view('eventOrders/index', $data); 
                } elseif ($data['etype_id'] === 'none') {
                    $data['etype_err'] = 'Kindly select an event type';
                    $this->view('eventOrders/index', $data);
                } elseif (empty($data['name_err']) && empty($data['etype_err'])) {   
                    session_start();
                    $_SESSION['event_orders_table_data']['name'] = $data['name'];
                    $_SESSION['event_orders_table_data']['date'] = $data['date'];
                    $_SESSION['event_orders_table_data']['time'] = $data['time'];
                    $_SESSION['event_orders_table_data']['ev_for'] = $data['ev_for'];
                    $_SESSION['event_orders_table_data']['etype_id'] = $data['etype_id'];
                    redirect('eventOrders/standard');
                }

            } else {
                //data to be passed in view
                $data = [
                    'name' => '',
                    'event_types' => $eventTypesObjArr,
                    'date' => '',
                    'time' => '',
                    'name_err' => '',
                    'etype_err' => ''
                ];
                $this->view('eventOrders/index', $data);
            }  
        }
        //standard method for choosing from packages
        public function standard() {
            $data = [

            ];
            $this->view('eventOrders/standardPackages', $data);
        }
        //customize1 method
        public function customize1() {
            $serviceTypesObjArr = $this->evOrderModel->getServiceTypesObjArr();
            if($_SERVER['REQUEST_METHOD'] == 'POST') {
                $stypeIdArray = !empty($_POST['stype_id']) ? $_POST['stype_id'] : NULL; 
                $data = [
                    'serviceTypesObjArr' => $serviceTypesObjArr,
                    'select_err' => ''
                ];
                if( empty($stypeIdArray) ) {
                    $data['select_err'] = 'Kindly select atleast one service';
                    $this->view('eventOrders/customize1', $data);    
                } else {
                    session_start();
                    $_SESSION['event_orders_table_data']['ev_stypes_id_array'] = json_encode($stypeIdArray);
                    $_SESSION['serTypeIdsArr'] = $stypeIdArray;    
                    redirect('eventOrders/customize2Caller');
                }

            } else {
                $data = [
                    'serviceTypesObjArr' => $serviceTypesObjArr,
                    'select_err' => ''
                ];
                $this->view('eventOrders/customize1', $data);
            }

        }
        //method for getting different products under all service types one by one
        public function customize2Caller() {
            session_start();
            if( empty($_SESSION['serTypeIdsArr']) ) {
                redirect('eventOrders/placeOrder');
            } else {
                $serviceTypeId = array_shift($_SESSION['serTypeIdsArr']);
                redirect('eventOrders/customize2/'. $serviceTypeId);
            }
        }
        //method customize2
        public function customize2($serviceTypeId) {
            
            if($_SERVER['REQUEST_METHOD'] == 'POST') {
                session_start();
                $_SESSION['selectedPdsArr'][] = $_POST[$serviceTypeId];
                redirect('eventOrders/customize2Caller');

            } else {
                //Getting Service Type Name from sTypeId
                $sTypeObj = $this->evOrderModel->getSTypeObjFromId($serviceTypeId);
                //Getting products under a specific sTypeId in array from model
                $pdsUnderStypeArr = $this->evOrderModel->getPdsFromStypeId($serviceTypeId);
                $data = [
                    'sTypeObj' => $sTypeObj,
                    'pdsUnderStypeArr' => $pdsUnderStypeArr
                ];
                $this->view('eventOrders/customize2', $data);
            }
        }
        //method placeOrder
        public function placeOrder() {
            if($_SERVER['REQUEST_METHOD'] == 'POST') {
                $data = [
                    'u_mob1' => testInput($_POST['mob1']),
                    'u_mob2' => testInput($_POST['mob2'])
                ];
                $mob1 = empty($data['u_mob1']) ? NULL : $data['u_mob1'];
                $mob2 = empty($data['u_mob2']) ? NULL : $data['u_mob2'];
                $name = $_SESSION['event_orders_table_data']['name'];
                $date = $_SESSION['event_orders_table_data']['date'];
                $time = $_SESSION['event_orders_table_data']['time'];
                $ev_for = $_SESSION['event_orders_table_data']['ev_for'];
                $etype_id = $_SESSION['event_orders_table_data']['etype_id'];
                $cost_customer = $_SESSION['event_orders_table_data']['ev_cost_customer'];
                $cost_admin = $_SESSION['event_orders_table_data']['ev_cost_admin'];
                $user_id = $_SESSION['user_id'];
                $stypes_id_array = $_SESSION['event_orders_table_data']['ev_stypes_id_array'];
                $pd_id_array = $_SESSION['event_orders_table_data']['ev_pd_id_array'];
                $this->evOrderModel->placeEventOrder($name, $date, $time, $ev_for, $stypes_id_array, $pd_id_array, $cost_customer, $cost_admin, $etype_id, $user_id, $mob1, $mob2);
                flash('Order Placed Success', 'Your Order has been successfully placed!');
                unset($_SESSION['event_orders_table_data']);
                unset($_SESSION['serTypeIdsArr']);
                unset($_SESSION['selectedPdsArr']);
                redirect('myEvents/index');  

            } else {
                $_SESSION['event_orders_table_data']['ev_pd_id_array'] = json_encode($_SESSION['selectedPdsArr']);
                $pdObjsArr = [];
                $evCostCustomer = 0;
                $evCostAdmin = 0;
                foreach ($_SESSION['selectedPdsArr'] as $pdId) {
                    $pdObj = $this->evOrderModel->getPdObjFromId($pdId);
                    $evCostCustomer += $pdObj->price_customer;
                    $evCostAdmin += $pdObj->price_admin;
                    $pdObjsArr[] = $pdObj;
                }
                $_SESSION['event_orders_table_data']['ev_cost_customer'] = $evCostCustomer;
                $_SESSION['event_orders_table_data']['ev_cost_admin'] = $evCostAdmin;
                $eTypeObj = $this->evOrderModel->getEvTypeObjFromId($_SESSION['event_orders_table_data']['etype_id']);
                $mobObj = $this->evOrderModel->getMobObjFromUserId($_SESSION['user_id']);
                $data = [
                    'ev_name' => $_SESSION['event_orders_table_data']['name'],
                    'ev_type' => $eTypeObj->name,
                    'ev_type_img' => $eTypeObj->img_path,
                    'ev_for' => $_SESSION['event_orders_table_data']['ev_for'],
                    'ev_date' => $_SESSION['event_orders_table_data']['date'],
                    'ev_time' => $_SESSION['event_orders_table_data']['time'],
                    'pdObjsArr' => $pdObjsArr,
                    'ev_cost_customer' => $evCostCustomer,
                    'u_mob1' => $mobObj->mob_1,
                    'u_mob2' => $mobObj->mob_2
                ];
                $this->view('eventOrders/placeOrder', $data);
            }       
        }
    }