<?php
    class UserAccountSettings extends Controller {
        private $uAccSettModel;
        public function __construct() {
            //check if loggedIn
            if( !isLoggedIn() ) {
                redirect('pages/index');
            }
            $this->uAccSettModel = $this->model('UserAccountSetting');
        }
        //Default Method
        public function index() {
            $userInfo = $this->uAccSettModel->getUserInfoById($_SESSION['user_id']);
            //Data to be send to view
            $data = [
                'name' => isNull($userInfo->name),
                'email' => isNull($userInfo->email),
                'mob_1' => isNull($userInfo->mob_1),
                'mob_2' => isNull($userInfo->mob_2),
                'house_no' => isNull($userInfo->house_no),
                'street' => isNull($userInfo->street),
                'landmark' => isNull($userInfo->landmark),
                'city' => isNull($userInfo->city),
                'pincode' => isNull($userInfo->pincode),
                'state' => isNull($userInfo->state),
                'country' => isNull($userInfo->country)
            ];
            $this->view('userAccountSettings/index', $data);
        }
        //Method for editing main user info
        public function editMain() {
            if($_SERVER['REQUEST_METHOD'] == 'POST') {
                //Data to be send to view
                $data = [
                    'name' =>   testInput($_POST['name']),
                    'email' => $_SESSION['user_email'],
                    'mob_1' => testInput($_POST['mob_1']),
                    'mob_2' => testInput($_POST['mob_2']),
                    'name_err' => '',
                    'email_err' => '',
                    'mob_1_err' => '',
                    'mob_2_err' => ''
                ];
                //Validate Name
                if(strlen($data['name']) <= 2 ) {
                    $data['name_err'] = 'Name should be atleast 3 characters long';
                } elseif( !preg_match("/^([a-zA-Z' ]+)$/", $data['name'])) {
                    $data['name_err'] = 'Name can only contain alphabets and spaces';
                }
                //Validate MobNumber1
                if(empty($data['mob_1']) || $data['mob_1'] === 'Not Available') {
                    $data['mob_1'] = NULL;
                } elseif(!preg_match('/^\d{10}$/', $data['mob_1'])) {
                    $data['mob_1_err'] = 'Please enter a valid 10 digit mobile number or leave it empty';
                }
                //Validate MobNumber2
                if(empty($data['mob_2']) || $data['mob_2'] === 'Not Available') {
                    $data['mob_2'] = NULL;
                } elseif(!preg_match('/^\d{10}$/', $data['mob_2'])) {
                    $data['mob_2_err'] = 'Please enter a valid 10 digit mobile number or leave it empty';
                }
                //Update Data into Database
                if( empty($data['name_err']) && empty($data['mob_1_err']) && empty($data['mob_2_err']) ) {
                    $this->uAccSettModel->updateUserInfo($data['name'], $data['mob_1'], $data['mob_2'], $_SESSION['user_id']);
                    flash('user_info_update_success', 'Successfully Updated!');
                    redirect('userAccountSettings/index');
                } else {
                    $this->view('userAccountSettings/editMain', $data);
                }

            } else {
                $userInfo = $this->uAccSettModel->getUserInfoById($_SESSION['user_id']);
                //Data to be send to view
                $data = [
                    'name' => isNull($userInfo->name),
                    'email' => isNull($userInfo->email),
                    'mob_1' => isNull($userInfo->mob_1),
                    'mob_2' => isNull($userInfo->mob_2),
                    'name_err' => '',
                    'email_err' => '',
                    'mob_1_err' => '',
                    'mob_2_err' => ''
                ];
                $this->view('userAccountSettings/editMain', $data);
            }
        }
        //Method for editing user address info
        public function editAddress() {
            if($_SERVER['REQUEST_METHOD'] == 'POST') {
                //Data to be send to view
                $data = [
                    'house_no' => testInput($_POST['house_no']),
                    'street' => testInput($_POST['street']),
                    'landmark' => testInput($_POST['landmark']),
                    'city' => testInput($_POST['city']),
                    'pincode' => testInput($_POST['pincode']),
                    'state' => testInput($_POST['state']),
                    'country' => 'India',
                    'house_no_err' => '',
                    'street_err' => '',
                    'landmark_err' => '',
                    'city_err' => '',
                    'pincode_err' => '',
                    'state_err' => '',
                    'country_err' => ''
                ];
                //Validate House Number
                if( empty($data['house_no']) || $data['house_no'] === 'Not Available') {
                    $data['house_no'] = NULL;
                } elseif( strlen($data['house_no']) > 50 ) {
                    $data['house_no_err'] = 'It must not exceed 50 characters';
                }
                //Validate Street
                if( empty($data['street']) || $data['street'] === 'Not Available') {
                    $data['street'] = NULL;
                } elseif( strlen($data['street']) > 100 ) {
                    $data['street_err'] = 'It must not exceed 100 characters';
                } elseif(!preg_match("/^([a-zA-Z', -.]+)$/", $data['street'])) {
                    $data['street_err'] = 'It can only contain alphabets, spaces and some special characters';
                }
                //Validate landmark
                if( empty($data['landmark']) || $data['landmark'] === 'Not Available') {
                    $data['landmark'] = NULL;
                } elseif( strlen($data['landmark']) > 100 ) {
                    $data['landmark_err'] = 'It must not exceed 100 characters';
                } elseif(!preg_match("/^([a-zA-Z', -.]+)$/", $data['landmark'])) {
                    $data['landmark_err'] = 'It can only contain alphabets, spaces and some special characters';
                }
                //Validate city
                if( empty($data['city']) || $data['city'] === 'Not Available') {
                    $data['city'] = NULL;
                } elseif( strlen($data['city']) > 100 ) {
                    $data['city_err'] = 'It must not exceed 100 characters';
                } elseif(!preg_match("/^([a-zA-Z', -.]+)$/", $data['city'])) {
                    $data['city_err'] = 'It can only contain alphabets, spaces and some special characters';
                }
                //Validate state
                if( empty($data['state']) || $data['state'] === 'Not Available') {
                    $data['state'] = NULL;
                } elseif( strlen($data['state']) > 100 ) {
                    $data['state_err'] = 'It must not exceed 100 characters';
                } elseif(!preg_match("/^([a-zA-Z', -.]+)$/", $data['state'])) {
                    $data['state_err'] = 'It can only contain alphabets, spaces and some special characters';
                }
                //Validate Pincode
                if( empty($data['pincode']) || $data['pincode'] === 'Not Available' ) {
                    $data['pincode'] = NULL;
                } elseif( strlen($data['pincode']) != 6 ) {
                    $data['pincode_err'] = 'It must contain exactly 6 digits';
                } elseif(!preg_match("/^\d{6}$/", $data['pincode'])) {
                    $data['pincode_err'] = 'It can only contain digits';
                }

                //Check for No Errors
                if( empty($data['house_no_err']) && empty($data['street_err']) && empty($data['city_err']) && empty($data['landmark_err']) && empty($data['pincode_err']) && empty($data['state_err']) ) {
                    //Enter Updated Data into Database
                    $this->uAccSettModel->updateUserAddrInfo($data['house_no'], $data['street'], $data['landmark'], $data['city'], $data['pincode'], $data['state'], $_SESSION['user_id']);
                    flash('user_address_info_update_success', 'Successfully Updated!');
                    redirect('userAccountSettings/index');

                } else {
                    $this->view('userAccountSettings/editAddress', $data);
                }

            } else {
                $userInfo = $this->uAccSettModel->getUserInfoById($_SESSION['user_id']);
                //Data to be send to view
                $data = [
                    'house_no' => isNull($userInfo->house_no),
                    'street' => isNull($userInfo->street),
                    'landmark' => isNull($userInfo->landmark),
                    'city' => isNull($userInfo->city),
                    'pincode' => isNull($userInfo->pincode),
                    'state' => isNull($userInfo->state),
                    'country' => isNull($userInfo->country),
                    'house_no_err' => '',
                    'street_err' => '',
                    'landmark_err' => '',
                    'city_err' => '',
                    'pincode_err' => '',
                    'state_err' => '',
                    'country_err' => ''
                ];
                $this->view('userAccountSettings/editAddress', $data);
            }
        }
        //method to change or update password
        public function changePassword() {
            if($_SERVER['REQUEST_METHOD'] == 'POST') {
                $data = [
                    'old_pwd' => testInput($_POST['old_pwd']),
                    'new_pwd' => testInput($_POST['new_pwd']),
                    'conf_new_pwd' => testInput($_POST['conf_new_pwd']),
                    'old_pwd_err' => '',
                    'new_pwd_err' => '',
                    'conf_new_pwd_err' => ''
                ];
                //Validate New Password
                if( strlen($data['new_pwd']) < 8 ) {
                    $data['new_pwd_err'] = 'Password must be of atleast 8 characters';
                    $data['conf_new_pwd'] = '';
                    $this->view('userAccountSettings/changePassword', $data);
                } elseif ( !preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $data['new_pwd']) ) {
                    $data['new_pwd_err'] = 'Password must contain atleast one special character';
                    $data['conf_new_pwd'] = '';
                    $this->view('userAccountSettings/changePassword', $data);
                } elseif ( strcmp($data['new_pwd'], $data['conf_new_pwd']) != 0 ) {
                    $data['conf_new_pwd_err'] = 'Confirm Password do not match original password';
                    $data['conf_new_pwd'] = '';
                    $this->view('userAccountSettings/changePassword', $data);
                } else {
                    $userPwdInfo = $this->uAccSettModel->getUserPwdById($_SESSION['user_id']);
                    if( !password_verify($data['old_pwd'], $userPwdInfo->pwd) ) {
                        $data['old_pwd_err'] = 'This is not your current password';
                        $this->view('userAccountSettings/changePassword', $data);
                    } elseif( password_verify($data['new_pwd'], $userPwdInfo->pwd) ) {
                        $data['new_pwd_err'] = 'New Password should not be same as current password';
                        $data['conf_new_pwd'] = '';
                        $this->view('userAccountSettings/changePassword', $data);
                    } else {
                        $data['new_pwd'] = password_hash($data['new_pwd'], PASSWORD_DEFAULT);
                        $this->uAccSettModel->updateUserPwdById($data['new_pwd'], $_SESSION['user_id']);
                        flash('user_pwd_update_success', 'Your Password has been updated successfully');
                        redirect('userAccountSettings/index');
                    }
                }

            } else {
                $data = [
                    'old_pwd' => '',
                    'new_pwd' => '',
                    'conf_new_pwd' => '',
                    'old_pwd_err' => '',
                    'new_pwd_err' => '',
                    'conf_new_pwd_err' => ''
                ];
                $this->view('userAccountSettings/changePassword', $data);
            }
        }
        //method to delete user account permanently
        public function deleteAcc() {
            if($_SERVER['REQUEST_METHOD'] == 'POST') {
                $data = [
                    'user_id' => $_POST['user_id']
                ];
                $this->uAccSettModel->deleteUserAccById($data['user_id']);
                session_start();
                unset($_SESSION['user_id']);
                unset($_SESSION['user_email']);
                flash('account_delete_success', 'Your account has been deleted successfully');
                redirect('pages/index');
            } else {
                $data = [
                    'user_id' => $_SESSION['user_id']
                ];
                $this->view('userAccountSettings/deleteAcc', $data);
            }
        }
    }