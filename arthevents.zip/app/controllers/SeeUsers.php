<?php
  class SeeUsers extends Controller {
    private $seeUsersModel;
    public function __construct() {
      $this->seeUsersModel = $this->model('SeeUser');
      if( !isAdminLoggedIn() ) {
        redirect('dashboards/index');
      }
    }
    //default method
    public function index($currPage = 1) {
      $recordsPerPage = 10;
      $totalRecords = $this->seeUsersModel->getTotalRecords();
      $numOfPages = ceil( $totalRecords / $recordsPerPage );
      $offset = ($currPage - 1) * $recordsPerPage;
      $userData = $this->seeUsersModel->getUsersData($offset, $recordsPerPage);
      $data = [
        'currPage' => $currPage,
        'numOfPages' => $numOfPages,
        'userData' => $userData
      ];
      $this->view('dashboard/seeUsers/index', $data);
    }
    //Method to show user details
    public function showUserDetails($userId) {
      $userDetails = $this->seeUsersModel->getUserDetailById($userId);
      $address = 'House Number: '.$userDetails->house_no.', Street: '.$userDetails->street.', Landmark: '.$userDetails->landmark.', City: '.$userDetails->city.', State: '.$userDetails->state.', Country: '.$userDetails->country.', Pincode: '.$userDetails->pincode;
      $data = [
        'user_id' => $userId,
        'name' => $userDetails->name,
        'email' => $userDetails->email,
        'mob1' => isNull($userDetails->mob_1),
        'mob2' => isNull($userDetails->mob_2),
        'status' => $userDetails->status,
        'created_at' => $userDetails->created_at,
        'address' => $address
      ];
      $this->view('dashboard/seeUsers/showUser', $data); 
    }
    // Method to block or unblock user
    public function changeUserStatusById($userId, $status) {
      $this->seeUsersModel->changeUserStatusById($userId, $status);
      flash('status_changed', 'User Status Successfully Changed');
      redirect('seeUsers/showUserDetails/'.$userId);
    }
    //Method to send user name suggestions using AJAX
    public function giveUserNameSuggestions() {
      $searchInput = testInput($_GET['si']);
      $suggestedNames = [];
      if( !empty($searchInput)) {
        $searchInput = testInput($searchInput);
        $suggestedUserNames = $this->seeUsersModel->userNameSuggestion($searchInput);
        foreach($suggestedUserNames as $userNameObj) {
          $suggestedNames[$userNameObj->name] = null;
        }
        if( empty($suggestedNames) ) {
          $suggestedNames = [
            'No results!' => null
          ];
        }
        echo json_encode($suggestedNames);
      } else {
        $suggestedNames = [
          'No results!' => null
        ];
        echo json_encode($suggestedNames);
      }
    }
    //Method to display user credentials by name
    public function searchUserByName() {
      $userName = testInput($_GET['un']);
      $userData = $this->seeUsersModel->searchUserByName($userName);
      if( empty($userData) ) {
        echo '<div class="row grey lighten-5 z-depth-2"><div class="col s12"><h6 class="blue-text text-darken-3 center">Searched Data</h6><p class="center">No Results Found!</p></div></div>';
      } else {
        echo '<div class="row grey lighten-5 z-depth-2">
        <div class="col s12">
        <h6 class="blue-text text-darken-3 center">Searched Data</h6>
        <div class="container">
        <table class="highlight responsive-table">
        <thead>
          <tr>
            <td><strong>Name</strong></td>
            <td><strong>Email</strong></td>
            <td><strong>Status</strong></td>
            <td></td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>'.$userData->name.'</td>
            <td>'.$userData->email.'</td>
            <td>'.$userData->status.'</td>
            <td><a href="'.URLROOT.'/seeUsers/showUserDetails/'.$userData->user_id.'" class="btn-small blue darken-3 waves-effect waves-light">Details</a></td>
          </tr>
        </tbody>
        </table>
        </div>
        </div>
        </div>';
      }
    }

  }