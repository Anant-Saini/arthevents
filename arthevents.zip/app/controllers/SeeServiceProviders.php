<?php
  class SeeServiceProviders extends Controller {
    private $seeServiceProvidersModel;
    public function __construct() {
      $this->seeServiceProvidersModel = $this->model('SeeServiceProvider');
      if( !isAdminLoggedIn() ) {
        redirect('dashboards/index');
      }
    }
    //default method
    public function index($currPage = 1) {
      $recordsPerPage = 10;
      $totalRecords = $this->seeServiceProvidersModel->getTotalRecords();
      $numOfPages = ceil( $totalRecords / $recordsPerPage );
      $offset = ($currPage - 1) * $recordsPerPage;
      $serProvidersData = $this->seeServiceProvidersModel->getSerProvidersData($offset, $recordsPerPage);
      $data = [
        'currPage' => $currPage,
        'numOfPages' => $numOfPages,
        'serProvidersData' => $serProvidersData
      ];
      $this->view('dashboard/seeServiceProviders/index', $data);
    }
    //Method to show service provider details
    public function showSPDetails($spId) {
      $spDetails = $this->seeServiceProvidersModel->getSPDetailById($spId);
      $spProductsArray = $this->seeServiceProvidersModel->getSPProductsBySPId($spId);
      $address = 'House Number: '.$spDetails->office_no.', Street: '.$spDetails->street.', City: '.$spDetails->city.', State: '.$spDetails->state.', Country: '.$spDetails->country.', Pincode: '.$spDetails->pincode;
      $data = [
        'spId' => $spId,
        'stypeId' => $spDetails->stype_id,
        'company_name' => $spDetails->company_name,
        'owner_name' => $spDetails->name,
        'sp_type' => $spDetails->sp_type,
        'email' => isNull($spDetails->email),
        'mob1' => isNull($spDetails->mob_1),
        'mob2' => isNull($spDetails->mob_2),
        'address' => $address,
        'spProductsArray' => $spProductsArray
      ];
      $this->view('dashboard/seeServiceProviders/showServiceProvider', $data); 
    }
    //Method to show Product
    public function showProduct($pdId, $spId) {
      $pdDetails = $this->seeServiceProvidersModel->getPdDetailsById($pdId);
      $data = [
        'spId' => $spId,
        'pdId' => $pdId,
        'name' => $pdDetails->pd_name,
        'stype' => $pdDetails->service_type,
        'priceCustomer' => $pdDetails->price_customer,
        'companyName' => $pdDetails->company_name,
        'priceAdmin' => $pdDetails->price_admin,
        'feature1' => $pdDetails->pd_feature1,
        'feature2' => $pdDetails->pd_feature2,
        'feature3' => $pdDetails->pd_feature3,
        'feature4' => $pdDetails->pd_feature4,
        'feature5' => $pdDetails->pd_feature5,
        'imgPath' => $pdDetails->pd_img_path

      ];
      $this->view('dashboard/seeServiceProviders/showProduct', $data);
    }
    //method to add service provider
    public function addServiceProvider() {
      if( $_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['addSerPro']) ) {
        //If Service Provider is added without Product
        //Take service types from database
        $serviceTypes = $this->seeServiceProvidersModel->getServiceTypes();
        //data to be send to view
        $data = [
          'companyName' => testInput($_POST['companyName']),
          'companyName_err' => '',
          'name' => testInput($_POST['name']),
          'name_err' => '',
          'serviceTypes' => $serviceTypes,
          'stypeId' => testInput($_POST['stypeId']),
          'stypeId_err' => '',
          'email' => testInput($_POST['email']),
          'email_err' => '',
          'mob1' => testInput($_POST['mob1']),
          'mob1_err' => '',
          'mob2' => testInput($_POST['mob2']),
          'mob2_err' => '',
          'officeNo' => testInput($_POST['officeNo']),
          'officeNo_err' => '',
          'street' => testInput($_POST['street']),
          'street_err' => '',
          'city' => testInput($_POST['city']),
          'city_err' => '',
          'pincode' => testInput($_POST['pincode']),
          'pincode_err' => '',
          'state' => testInput($_POST['state']),
          'state_err' => '',
          'country' => testInput($_POST['country']),
          'country_err' => '',
          'pdName' => '',
          'pdName_err' => '',
          'pdImg_err' => '',
          'feature1' => '',
          'feature1_err' => '',
          'feature2' => '',
          'feature2_err' => '',
          'feature3' => '',
          'feature3_err' => '',
          'feature4' => '',
          'feature4_err' => '',
          'feature5' => '',
          'feature5_err' => '',
          'priceCustomer' => '',
          'priceCustomer_err' => '',
          'priceAdmin' => '',
          'priceAdmin_err' => '',
          'show' => false
        ];
        //Validate Company Name
        if( empty($data['companyName']) ) {
          $data['companyName'] = null;
        } else if( strlen($data['companyName'])  <= 1 ) {
          $data['companyName_err'] = 'Company name must be atleast one character long';
        }
        //Validate Service Provider Name
        if(strlen($data['name']) <= 2 ) {
          $data['name_err'] = 'Name should be atleast 3 characters long';
        } elseif( !preg_match("/^([a-zA-Z' ]+)$/", $data['name'])) {
          $data['name_err'] = 'Name can only contain alphabets and spaces';
        }
        //Validate service type id
        if( $data['stypeId'] == 'none' ) {
          $data['stypeId_err'] = 'Kindly select a service type from given list';
        }
        //Validate email
        if( empty($data['email']) ) {
          $data['email'] = null;
        } else if( !filter_var($data['email'], FILTER_VALIDATE_EMAIL) === true ) {
          $data['email_err'] = 'It is not a valid email address';
        }
        //Validate mob1
        if( !preg_match('/^\d{10}$/', $data['mob1']) ) {
          $data['mob1_err'] = 'Please enter a valid 10 digit mobile number';
        }
        //Validate mob2
        if( empty($data['mob2']) ) {
          $data['mob2'] = NULL;
        } else if(!preg_match('/^\d{10}$/', $data['mob2'])) {
            $data['mob2_err'] = 'Please enter a valid 10 digit mobile number or leave it empty';
        }
        //Validate Office Number
        if( empty($data['officeNo']) ) {
          $data['officeNo'] = NULL;
        } elseif( strlen($data['officeNo']) > 50 ) {
            $data['officeNo_err'] = 'It must not exceed 50 characters';
        }
        //Validate Street
        if( empty($data['street']) ) {
            $data['street'] = NULL;
        } elseif( strlen($data['street']) > 100 ) {
            $data['street_err'] = 'It must not exceed 100 characters';
        } elseif(!preg_match("/^([a-zA-Z', -.]+)$/", $data['street'])) {
            $data['street_err'] = 'It can only contain alphabets, spaces and some special characters';
        }
        //Validate city
        if( empty($data['city']) ) {
            $data['city'] = NULL;
        } elseif( strlen($data['city']) > 100 ) {
            $data['city_err'] = 'It must not exceed 100 characters';
        } elseif(!preg_match("/^([a-zA-Z', -.]+)$/", $data['city'])) {
            $data['city_err'] = 'It can only contain alphabets, spaces and some special characters';
        }
        //Validate state
        if( empty($data['state'])  ) {
            $data['state'] = NULL;
        } elseif( strlen($data['state']) > 100 ) {
            $data['state_err'] = 'It must not exceed 100 characters';
        } elseif(!preg_match("/^([a-zA-Z', -.]+)$/", $data['state'])) {
            $data['state_err'] = 'It can only contain alphabets, spaces and some special characters';
        }
        //Validate Pincode
        if( empty($data['pincode']) ) {
            $data['pincode'] = NULL;
        } elseif( strlen($data['pincode']) != 6 ) {
            $data['pincode_err'] = 'It must contain exactly 6 digits';
        } elseif(!preg_match("/^\d{6}$/", $data['pincode'])) {
            $data['pincode_err'] = 'It can only contain digits';
        }
        //Validate Country
        if( empty($data['country']) ) {
          $data['country'] = 'India';
        } elseif( strlen($data['country']) > 100 ) {
          $data['country_err'] = 'It must not exceed 100 characters';
        } elseif(!preg_match("/^([a-zA-Z', -.]+)$/", $data['country'])) {
            $data['country_err'] = 'It can only contain alphabets, spaces and some special characters';
        }
        //Check for errors
        if( empty($data['companyName_err']) && empty($data['name_err']) && empty($data['stypeId_err']) && empty($data['email_err']) && empty($data['mob1_err']) && empty($data['mob2_err']) && empty($data['officeNo_err']) && empty($data['street_err']) && empty($data['city_err']) && empty($data['pincode_err']) && empty($data['state_err']) && empty($data['country_err']) ) {

          //Enter Updated Data into Database
          $result = $this->seeServiceProvidersModel->insertSerProviderInfo($data['companyName'], $data['name'], $data['stypeId'], $data['email'], $data['mob1'], $data['mob2'], $data['officeNo'], $data['street'], $data['city'], $data['pincode'], $data['state'], $data['country']);
          if( $result  != 'success' ) {
            die($result);
          } else {
              flash('service_provider_added_successfully', 'Service Provider has been added successfully');
              redirect('seeServiceProviders/index');
          }

        } else {
          $this->view('dashboard/seeServiceProviders/addServiceProvider', $data);
        }

      } else if( $_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['addSerProWithPd']) ) {
        //If service provider is added with a product
        //Take service types from database
        $serviceTypes = $this->seeServiceProvidersModel->getServiceTypes();
        //data to be send to view
        $data = [
          'companyName' => testInput($_POST['companyName']),
          'companyName_err' => '',
          'name' => testInput($_POST['name']),
          'name_err' => '',
          'serviceTypes' => $serviceTypes,
          'stypeId' => testInput($_POST['stypeId']),
          'stypeId_err' => '',
          'email' => testInput($_POST['email']),
          'email_err' => '',
          'mob1' => testInput($_POST['mob1']),
          'mob1_err' => '',
          'mob2' => testInput($_POST['mob2']),
          'mob2_err' => '',
          'officeNo' => testInput($_POST['officeNo']),
          'officeNo_err' => '',
          'street' => testInput($_POST['street']),
          'street_err' => '',
          'city' => testInput($_POST['city']),
          'city_err' => '',
          'pincode' => testInput($_POST['pincode']),
          'pincode_err' => '',
          'state' => testInput($_POST['state']),
          'state_err' => '',
          'country' => testInput($_POST['country']),
          'country_err' => '',
          'pdName' => testInput($_POST['pdName']),
          'pdName_err' => '',
          'pdImg' => $_FILES['pdImg'],
          'pdImg_err' => '',
          'feature1' => testInput($_POST['feature1']),
          'feature1_err' => '',
          'feature2' => testInput($_POST['feature2']),
          'feature2_err' => '',
          'feature3' => testInput($_POST['feature3']),
          'feature3_err' => '',
          'feature4' => testInput($_POST['feature4']),
          'feature4_err' => '',
          'feature5' => testInput($_POST['feature5']),
          'feature5_err' => '',
          'priceCustomer' => testInput($_POST['priceCustomer']),
          'priceCustomer_err' => '',
          'priceAdmin' => testInput($_POST['priceAdmin']),
          'priceAdmin_err' => '',
          'show' => true
        ];
        //Validate Company Name
        if( empty($data['companyName']) ) {
          $data['companyName'] = null;
        } else if( strlen($data['companyName'])  <= 1 ) {
          $data['companyName_err'] = 'Company name must be atleast one character long';
        }
        //Validate Service Provider Name
        if(strlen($data['name']) <= 2 ) {
          $data['name_err'] = 'Name should be atleast 3 characters long';
        } elseif( !preg_match("/^([a-zA-Z' ]+)$/", $data['name'])) {
          $data['name_err'] = 'Name can only contain alphabets and spaces';
        }
        //Validate service type id
        if( $data['stypeId'] == 'none' ) {
          $data['stypeId_err'] = 'Kindly select a service type from given list';
        }
        //Validate email
        if( empty($data['email']) ) {
          $data['email'] = null;
        } else if( !filter_var($data['email'], FILTER_VALIDATE_EMAIL) === true ) {
          $data['email_err'] = 'It is not a valid email address';
        }
        //Validate mob1
        if( !preg_match('/^\d{10}$/', $data['mob1']) ) {
          $data['mob1_err'] = 'Please enter a valid 10 digit mobile number';
        }
        //Validate mob2
        if( empty($data['mob2']) ) {
          $data['mob2'] = NULL;
        } else if(!preg_match('/^\d{10}$/', $data['mob2'])) {
            $data['mob2_err'] = 'Please enter a valid 10 digit mobile number or leave it empty';
        }
        //Validate Office Number
        if( empty($data['officeNo']) ) {
          $data['officeNo'] = NULL;
        } elseif( strlen($data['officeNo']) > 50 ) {
            $data['officeNo_err'] = 'It must not exceed 50 characters';
        }
        //Validate Street
        if( empty($data['street']) ) {
            $data['street'] = NULL;
        } elseif( strlen($data['street']) > 100 ) {
            $data['street_err'] = 'It must not exceed 100 characters';
        } elseif(!preg_match("/^([a-zA-Z', -.]+)$/", $data['street'])) {
            $data['street_err'] = 'It can only contain alphabets, spaces and some special characters';
        }
        //Validate city
        if( empty($data['city']) ) {
            $data['city'] = NULL;
        } elseif( strlen($data['city']) > 100 ) {
            $data['city_err'] = 'It must not exceed 100 characters';
        } elseif(!preg_match("/^([a-zA-Z', -.]+)$/", $data['city'])) {
            $data['city_err'] = 'It can only contain alphabets, spaces and some special characters';
        }
        //Validate state
        if( empty($data['state'])  ) {
            $data['state'] = NULL;
        } elseif( strlen($data['state']) > 100 ) {
            $data['state_err'] = 'It must not exceed 100 characters';
        } elseif(!preg_match("/^([a-zA-Z', -.]+)$/", $data['state'])) {
            $data['state_err'] = 'It can only contain alphabets, spaces and some special characters';
        }
        //Validate Pincode
        if( empty($data['pincode']) ) {
            $data['pincode'] = NULL;
        } elseif( strlen($data['pincode']) != 6 ) {
            $data['pincode_err'] = 'It must contain exactly 6 digits';
        } elseif(!preg_match("/^\d{6}$/", $data['pincode'])) {
            $data['pincode_err'] = 'It can only contain digits';
        }
        //Validate Country
        if( empty($data['country']) ) {
          $data['country'] = 'India';
        } elseif( strlen($data['country']) > 100 ) {
          $data['country_err'] = 'It must not exceed 100 characters';
        } elseif(!preg_match("/^([a-zA-Z', -.]+)$/", $data['country'])) {
            $data['country_err'] = 'It can only contain alphabets, spaces and some special characters';
        }
        //Validate Product Name
        if( empty($data['pdName']) ) {
          $data['pdName_err'] = 'Product Name can\'t be empty';
        } elseif(strlen($data['pdName']) <= 2 ) {
          $data['pdName_err'] = 'Name should be atleast 3 characters long';
        }
        //Validate Feature1
        if( empty($data['feature1']) ) {
          $data['feature1_err'] = 'Feature One of Product cannot be empty';
        } elseif(strlen($data['feature1']) <= 2) {
          $data['feature1_err'] = 'Product feature should be atleast 3 characters long';
        }
        //Validate Feature2
        if( empty($data['feature2']) ) {
          $data['feature2'] = NULL;
        } elseif(strlen($data['feature2']) <= 2) {
          $data['feature2_err'] = 'Product feature should be atleast 3 characters long';
        }
        //Validate Feature3
        if( empty($data['feature3']) ) {
          $data['feature3'] = NULL;
        } elseif(strlen($data['feature3']) <= 2) {
          $data['feature3_err'] = 'Product feature should be atleast 3 characters long';
        }
        //Validate Feature4
        if( empty($data['feature4']) ) {
          $data['feature4'] = NULL;
        } elseif(strlen($data['feature4']) <= 2) {
          $data['feature4_err'] = 'Product feature should be atleast 3 characters long';
        }
        //Validate Feature5
        if( empty($data['feature5']) ) {
          $data['feature5'] = NULL;
        } elseif(strlen($data['feature5']) <= 2) {
          $data['feature5_err'] = 'Product feature should be atleast 3 characters long';
        }
        //Validate Price Customer
        if( empty($data['priceCustomer']) ) {
          $data['priceCustomer_err'] = 'Price Customer can\'t be empty';
        }
        //Validate Price Admin
        if( empty($data['priceAdmin']) ) {
          $data['priceAdmin_err'] = 'Price Admin can\'t be empty';
        }
        //Validate Product Image File
        //Image Details
        $pdImgError = $data['pdImg']['error'];
        if( $pdImgError !== 4) {

          $pdImgName = $data['pdImg']['name'];
          $pdImgTmpName = $data['pdImg']['tmp_name'];
          $pdImgSize = $data['pdImg']['size'];

          //Image Extension
          $pdImgExt = explode('.', $pdImgName);
          $pdImgActualExt = strtolower(end($pdImgExt));
          //Extensions which are allowed
          $allowed = ['jpg','jpeg','png'];
          //Error Handlers
          if( !in_array($pdImgActualExt, $allowed) ) {
            $data['pdImg_err'] = 'Only JPEG/JPG and PNG files are allowed!';
          } else {
            if( $pdImgError !== 0 ) {
              $data['pdImg_err'] = 'There is an error uploading this file!';
            } else {
              if( $pdImgSize > 500000) {
                $data['pdImg_err'] = 'Maximum File size allowed is 500KB!';
              }
            }
          }
        } else {
          $pdImgTmpName = NULL;
          $pdImgActualExt = 'png';
        }
        
        //Check for errors
        if( empty($data['companyName_err']) && empty($data['name_err']) && empty($data['stypeId_err']) && empty($data['email_err']) && empty($data['mob1_err']) && empty($data['mob2_err']) && empty($data['officeNo_err']) && empty($data['street_err']) && empty($data['city_err']) && empty($data['pincode_err']) && empty($data['state_err']) && empty($data['country_err']) && empty($data['pdName_err']) && empty($data['pdImg_err']) && empty($data['feature1_err']) && empty($data['feature2_err']) && empty($data['feature3_err']) && empty($data['feature4_err']) && empty($data['feature5_err']) && empty($data['priceAdmin_err']) && empty($data['priceCustomer_err'])) {

          //Enter Updated Data into Database
          $result = $this->seeServiceProvidersModel->insertSerProviderInfoWithProdInfo($data['companyName'], $data['name'], $data['stypeId'], $data['email'], $data['mob1'], $data['mob2'], $data['officeNo'], $data['street'], $data['city'], $data['pincode'], $data['state'], $data['country'], $data['pdName'], $data['priceCustomer'], $data['priceAdmin'], $data['feature1'], $data['feature2'], $data['feature3'], $data['feature4'], $data['feature5'], $pdImgActualExt, $pdImgTmpName);
          if( $result  != 'success' ) {
            die($result);
          } else {
              flash('service_provider_added_successfully', 'Service Provider has been added successfully');
              redirect('seeServiceProviders/index');
          }

        } else {
          $this->view('dashboard/seeServiceProviders/addServiceProvider', $data);
        }


      } else {
        //Take service types from database
        $serviceTypes = $this->seeServiceProvidersModel->getServiceTypes();
        //data to be send to view
        $data = [
          'companyName' => '',
          'companyName_err' => '',
          'name' => '',
          'name_err' => '',
          'serviceTypes' => $serviceTypes,
          'stypeId' => 'none',          
          'stypeId_err' => '',
          'email' => '',
          'email_err' => '',
          'mob1' => '',
          'mob1_err' => '',
          'mob2' => '',
          'mob2_err' => '',
          'officeNo' => '',
          'officeNo_err' => '',
          'street' => '',
          'street_err' => '',
          'city' => '',
          'city_err' => '',
          'pincode' => '',
          'pincode_err' => '',
          'state' => '',
          'state_err' => '',
          'country' => '',
          'country_err' => '',
          'pdName' => '',
          'pdName_err' => '',
          'pdImg_err' => '',
          'feature1' => '',
          'feature1_err' => '',
          'feature2' => '',
          'feature2_err' => '',
          'feature3' => '',
          'feature3_err' => '',
          'feature4' => '',
          'feature4_err' => '',
          'feature5' => '',
          'feature5_err' => '',
          'priceCustomer' => '',
          'priceCustomer_err' => '',
          'priceAdmin' => '',
          'priceAdmin_err' => '',
          'show' => false
        ];
        $this->view('dashboard/seeServiceProviders/addServiceProvider', $data);
      }
    }
    //Method to edit service provider details
    public function editServiceProvider($spId) {
      //Take service types from database
      $serviceTypes = $this->seeServiceProvidersModel->getServiceTypes();
      if( $_SERVER['REQUEST_METHOD'] == 'POST') {
        $data = [
          'spId' => $spId,
          'companyName' => testInput($_POST['companyName']),
          'companyName_err' => '',
          'name' => testInput($_POST['name']),
          'name_err' => '',
          'serviceTypes' => $serviceTypes,
          'stypeId' => testInput($_POST['stypeId']),          
          'stypeId_err' => '',
          'email' => testInput($_POST['email']),
          'email_err' => '',
          'mob1' => testInput($_POST['mob1']),
          'mob1_err' => '',
          'mob2' => testInput($_POST['mob2']),
          'mob2_err' => '',
          'officeNo' => testInput($_POST['officeNo']),
          'officeNo_err' => '',
          'street' => testInput($_POST['street']),
          'street_err' => '',
          'city' => testInput($_POST['city']),
          'city_err' => '',
          'pincode' => testInput($_POST['pincode']),
          'pincode_err' => '',
          'state' => testInput($_POST['state']),
          'state_err' => '',
          'country' => testInput($_POST['country']),
          'country_err' => ''
        ];
        //Validate Company Name
        if( empty($data['companyName']) || $data['companyName'] == 'Not Available' ) {
          $data['companyName'] = null;
        } else if( strlen($data['companyName'])  <= 1 ) {
          $data['companyName_err'] = 'Company name must be atleast one character long';
        }
        //Validate Service Provider Name
        if(strlen($data['name']) <= 2 ) {
          $data['name_err'] = 'Name should be atleast 3 characters long';
        } elseif( !preg_match("/^([a-zA-Z' ]+)$/", $data['name'])) {
          $data['name_err'] = 'Name can only contain alphabets and spaces';
        }
        //Validate service type id
        if( !is_numeric($data['stypeId']) ) {
          $data['stypeId_err'] = 'Something Wrong With Your Selection. Try Again!';
        }
        //Validate email
        if( empty($data['email']) || $data['email'] == 'Not Available' ) {
          $data['email'] = null;
        } else if( !filter_var($data['email'], FILTER_VALIDATE_EMAIL) === true ) {
          $data['email_err'] = 'It is not a valid email address';
        }
        //Validate mob1
        if( !preg_match('/^\d{10}$/', $data['mob1']) ) {
          $data['mob1_err'] = 'Please enter a valid 10 digit mobile number';
        }
        //Validate mob2
        if( empty($data['mob2']) || $data['mob2'] == 'Not Available' ) {
          $data['mob2'] = NULL;
        } else if(!preg_match('/^\d{10}$/', $data['mob2'])) {
            $data['mob2_err'] = 'Please enter a valid 10 digit mobile number or leave it empty';
        }
        //Validate Office Number
        if( empty($data['officeNo']) || $data['officeNo'] == 'Not Available' ) {
          $data['officeNo'] = NULL;
        } elseif( strlen($data['officeNo']) > 50 ) {
            $data['officeNo_err'] = 'It must not exceed 50 characters';
        }
        //Validate Street
        if( empty($data['street']) || $data['street'] == 'Not Available' ) {
            $data['street'] = NULL;
        } elseif( strlen($data['street']) > 100 ) {
            $data['street_err'] = 'It must not exceed 100 characters';
        } elseif(!preg_match("/^([a-zA-Z', -.]+)$/", $data['street'])) {
            $data['street_err'] = 'It can only contain alphabets, spaces and some special characters';
        }
        //Validate city
        if( empty($data['city']) || $data['city'] == 'Not Available' ) {
            $data['city'] = NULL;
        } elseif( strlen($data['city']) > 100 ) {
            $data['city_err'] = 'It must not exceed 100 characters';
        } elseif(!preg_match("/^([a-zA-Z', -.]+)$/", $data['city'])) {
            $data['city_err'] = 'It can only contain alphabets, spaces and some special characters';
        }
        //Validate state
        if( empty($data['state']) || $data['state'] == 'Not Available'  ) {
            $data['state'] = NULL;
        } elseif( strlen($data['state']) > 100 ) {
            $data['state_err'] = 'It must not exceed 100 characters';
        } elseif(!preg_match("/^([a-zA-Z', -.]+)$/", $data['state'])) {
            $data['state_err'] = 'It can only contain alphabets, spaces and some special characters';
        }
        //Validate Pincode
        if( empty($data['pincode']) || $data['pincode'] == 'Not Available' ) {
            $data['pincode'] = NULL;
        } elseif( strlen($data['pincode']) != 6 ) {
            $data['pincode_err'] = 'It must contain exactly 6 digits';
        } elseif(!preg_match("/^\d{6}$/", $data['pincode'])) {
            $data['pincode_err'] = 'It can only contain digits';
        }
        //Validate Country
        if( empty($data['country']) || $data['country'] == 'Not Available' ) {
          $data['country'] = 'India';
        } elseif( strlen($data['country']) > 100 ) {
          $data['country_err'] = 'It must not exceed 100 characters';
        } elseif(!preg_match("/^([a-zA-Z', -.]+)$/", $data['country'])) {
            $data['country_err'] = 'It can only contain alphabets, spaces and some special characters';
        }
        //Checking For Errors
        if( empty($data['companyName_err']) && empty($data['name_err']) && empty($data['stypeId_err']) && empty($data['email_err']) && empty($data['mob1_err']) && empty($data['mob2_err']) && empty($data['officeNo_err']) && empty($data['street_err']) && empty($data['city_err']) && empty($data['pincode_err']) && empty($data['state_err']) && empty($data['country_err']) ) {
          //Enter Updated Data into Database
          $result = $this->seeServiceProvidersModel->updateSerProviderInfo($data['companyName'], $data['name'], $data['stypeId'], $data['email'], $data['mob1'], $data['mob2'], $data['officeNo'], $data['street'], $data['city'], $data['pincode'], $data['state'], $data['country'], $spId);
          if( $result  != 'success' ) {
            die($result);
          } else {
            flash('service_provider_updated_successfully', 'Service Provider details has been updated successfully');
            redirect('seeServiceProviders/editServiceProvider/'.$spId);
          }
        } else {
          $this->view('dashboard/seeServiceProviders/editServiceProvider', $data);
        }

      } else {
        //Take Service Provider Details from Database
        $spDetails = $this->seeServiceProvidersModel->getSPDetailById($spId);
        $data = [
          'spId' => $spId,
          'companyName' => isNull($spDetails->company_name),
          'companyName_err' => '',
          'name' => isNull($spDetails->name),
          'name_err' => '',
          'serviceTypes' => $serviceTypes,
          'stypeId' => $spDetails->stype_id,          
          'stypeId_err' => '',
          'email' => isNull($spDetails->email),
          'email_err' => '',
          'mob1' => isNull($spDetails->mob_1),
          'mob1_err' => '',
          'mob2' => isNull($spDetails->mob_2),
          'mob2_err' => '',
          'officeNo' => isNull($spDetails->office_no),
          'officeNo_err' => '',
          'street' => isNull($spDetails->street),
          'street_err' => '',
          'city' => isNull($spDetails->city),
          'city_err' => '',
          'pincode' => isNull($spDetails->pincode),
          'pincode_err' => '',
          'state' => isNull($spDetails->state),
          'state_err' => '',
          'country' => isNull($spDetails->country),
          'country_err' => ''
        ];
        $this->view('dashboard/seeServiceProviders/editServiceProvider', $data);
      }
    }
    //funcion to delete service provider
    public function deleteServiceProvider() {
      if($_SERVER['REQUEST_METHOD'] == 'POST') {
        $data = [
            'spId' => $_POST['spId']
        ];
        $this->seeServiceProvidersModel->deleteServiceProvider($data['spId']);
        flash('service_provider_delete_success', 'Service Provider has been deleted successfully');
        redirect('seeServiceProviders/index');
      } 
    }
    //function to add product to a service provider
    public function addProduct($spId, $stypeId) {
      if($_SERVER['REQUEST_METHOD'] == 'POST') {
        $data = [
          'spId' => $spId,
          'stypeId' => $stypeId,
          'pdName' => testInput($_POST['pdName']),
          'pdName_err' => '',
          'pdImg' => $_FILES['pdImg'],
          'pdImg_err' => '',
          'feature1' => testInput($_POST['feature1']),
          'feature1_err' => '',
          'feature2' => testInput($_POST['feature2']),
          'feature2_err' => '',
          'feature3' => testInput($_POST['feature3']),
          'feature3_err' => '',
          'feature4' => testInput($_POST['feature4']),
          'feature4_err' => '',
          'feature5' => testInput($_POST['feature5']),
          'feature5_err' => '',
          'priceCustomer' => testInput($_POST['priceCustomer']),
          'priceCustomer_err' => '',
          'priceAdmin' => testInput($_POST['priceAdmin']),
          'priceAdmin_err' => ''
        ];
        //Validate Product Name
        if( empty($data['pdName']) ) {
          $data['pdName_err'] = 'Product Name can\'t be empty';
        } elseif(strlen($data['pdName']) <= 2 ) {
          $data['pdName_err'] = 'Name should be atleast 3 characters long';
        }
        //Validate Feature1
        if( empty($data['feature1']) ) {
          $data['feature1_err'] = 'Feature One of Product cannot be empty';
        } elseif(strlen($data['feature1']) <= 2) {
          $data['feature1_err'] = 'Product feature should be atleast 3 characters long';
        }
        //Validate Feature2
        if( empty($data['feature2']) ) {
          $data['feature2'] = NULL;
        } elseif(strlen($data['feature2']) <= 2) {
          $data['feature2_err'] = 'Product feature should be atleast 3 characters long';
        }
        //Validate Feature3
        if( empty($data['feature3']) ) {
          $data['feature3'] = NULL;
        } elseif(strlen($data['feature3']) <= 2) {
          $data['feature3_err'] = 'Product feature should be atleast 3 characters long';
        }
        //Validate Feature4
        if( empty($data['feature4']) ) {
          $data['feature4'] = NULL;
        } elseif(strlen($data['feature4']) <= 2) {
          $data['feature4_err'] = 'Product feature should be atleast 3 characters long';
        }
        //Validate Feature5
        if( empty($data['feature5']) ) {
          $data['feature5'] = NULL;
        } elseif(strlen($data['feature5']) <= 2) {
          $data['feature5_err'] = 'Product feature should be atleast 3 characters long';
        }
        //Validate Price Customer
        if( empty($data['priceCustomer']) ) {
          $data['priceCustomer_err'] = 'Price Customer can\'t be empty';
        }
        //Validate Price Admin
        if( empty($data['priceAdmin']) ) {
          $data['priceAdmin_err'] = 'Price Admin can\'t be empty';
        }
        //Validate Product Image File
        //Image Details
        $pdImgError = $data['pdImg']['error'];
        if( $pdImgError !== 4) {

          $pdImgName = $data['pdImg']['name'];
          $pdImgTmpName = $data['pdImg']['tmp_name'];
          $pdImgSize = $data['pdImg']['size'];

          //Image Extension
          $pdImgExt = explode('.', $pdImgName);
          $pdImgActualExt = strtolower(end($pdImgExt));
          //Extensions which are allowed
          $allowed = ['jpg','jpeg','png'];
          //Error Handlers
          if( !in_array($pdImgActualExt, $allowed) ) {
            $data['pdImg_err'] = 'Only JPEG/JPG and PNG files are allowed!';
          } else {
            if( $pdImgError !== 0 ) {
              $data['pdImg_err'] = 'There is an error uploading this file!';
            } else {
              if( $pdImgSize > 500000) {
                $data['pdImg_err'] = 'Maximum File size allowed is 500KB!';
              }
            }
          }
        } else {
          $pdImgTmpName = NULL;
          $pdImgActualExt = 'png';
        }
        
        //Check for errors
        if( empty($data['pdName_err']) && empty($data['pdImg_err']) && empty($data['feature1_err']) && empty($data['feature2_err']) && empty($data['feature3_err']) && empty($data['feature4_err']) && empty($data['feature5_err']) && empty($data['priceAdmin_err']) && empty($data['priceCustomer_err'])) {

          //Enter Updated Data into Database
          $result = $this->seeServiceProvidersModel->insertProductInfo($spId, $stypeId, $data['pdName'], $data['priceCustomer'], $data['priceAdmin'], $data['feature1'], $data['feature2'], $data['feature3'], $data['feature4'], $data['feature5'], $pdImgActualExt, $pdImgTmpName);
          if( $result  != 'success' ) {
            die($result);
          } else {
              flash('product_added_successfully', 'Product has been added successfully');
              redirect('seeServiceProviders/addProduct/'.$spId.'/'.$stypeId);
          }
        } else {
          $this->view('dashboard/seeServiceProviders/addProduct', $data);
        }

      } else {
        $data = [
          'spId' => $spId,
          'stypeId' => $stypeId,
          'pdName' => '',
          'pdName_err' => '',
          'pdImg_err' => '',
          'feature1' => '',
          'feature1_err' => '',
          'feature2' => '',
          'feature2_err' => '',
          'feature3' => '',
          'feature3_err' => '',
          'feature4' => '',
          'feature4_err' => '',
          'feature5' => '',
          'feature5_err' => '',
          'priceCustomer' => '',
          'priceCustomer_err' => '',
          'priceAdmin' => '',
          'priceAdmin_err' => ''
        ];
        $this->view('dashboard/seeServiceProviders/addProduct', $data);
      }
    }
    //funcion to delete product
    public function deleteProduct($spId) {
      if($_SERVER['REQUEST_METHOD'] == 'POST') {
        $data = [
            'pdId' => $_POST['pdId']
        ];
        $this->seeServiceProvidersModel->deleteProduct($data['pdId']);
        flash('product_delete_success', 'Product has been deleted successfully');
        redirect('seeServiceProviders/showSPDetails/'.$spId);
      } 
    }
    //Method to send service provider name suggestions using AJAX
    public function giveSerProNameSuggestions() {
      $searchInput = testInput($_GET['si']);
      $suggestedNames = [];
      if( !empty($searchInput)) {
        $searchInput = testInput($searchInput);
        $suggestedSerProNames = $this->seeServiceProvidersModel->serProNameSuggestion($searchInput);
        foreach($suggestedSerProNames as $serProNameObj) {
          $suggestedNames[$serProNameObj->name] = null;
        }
        if( empty($suggestedNames) ) {
          $suggestedNames = [
            'No results!' => null
          ];
        }
        echo json_encode($suggestedNames);
      } else {
        $suggestedNames = [
          'No results!' => null
        ];
        echo json_encode($suggestedNames);
      }
    }
    //Method to display service provider credentials by name
    public function searchSerProByName() {
      $serProName = testInput($_GET['spn']);
      $serProData = $this->seeServiceProvidersModel->searchSerProByName($serProName);
      if( empty($serProData) ) {
        echo '<div class="row grey lighten-5 z-depth-2"><div class="col s12"><h6 class="blue-text text-darken-3 center">Searched Data</h6><p class="center">No Results Found!</p></div></div>';
      } else {
        echo '<div class="row grey lighten-5 z-depth-2">
        <div class="col s12">
        <h6 class="blue-text text-darken-3 center">Searched Data</h6>
        <div class="container">
        <table class="highlight responsive-table">
        <thead>
          <tr>
            <td><strong>Name</strong></td>
            <td><strong>Company Name</strong></td>
            <td><strong>Email</strong></td>
            <td></td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>'.$serProData->name.'</td>
            <td>'.$serProData->company_name.'</td>
            <td>'.$serProData->email.'</td>
            <td><a href="'.URLROOT.'/seeServiceProviders/showSPDetails/'.$serProData->sp_id.'" class="btn-small blue darken-3 waves-effect waves-light">Details</a></td>
          </tr>
        </tbody>
        </table>
        </div>
        </div>
        </div>';
      }
    }
  }