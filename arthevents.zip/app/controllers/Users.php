<?php
    class Users extends Controller {
        private $userModel;
        public function __construct() {
            $this->userModel = $this->model('User');
        }
        // default method
        public function index() {
            redirect('pages/index');
        }
        // method to test input data
        private function testInput($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        // method to register user
        public function register() {
            if($_SERVER['REQUEST_METHOD'] == 'POST') {
                $data = [
                    'name' => $this->testInput($_POST['name']),
                    'email' => $this->testInput($_POST['email']),
                    'pwd' => $this->testInput($_POST['pwd']),
                    'confirm_pwd' => $this->testInput($_POST['confirm_pwd']),
                    'name_err' => '',
                    'email_err' => '',
                    'pwd_err' => '',
                    'confirm_pwd_err' => ''
                ];
                //Validate Name
                if( empty($data['name']) ) {
                    $data['name_err'] = 'Name can not be empty';
                }
                //Validate Email
                if( empty($data['email']) ) {
                    $data['email_err'] = "Email can't be empty";
                } elseif (!filter_var($data['email'], FILTER_VALIDATE_EMAIL) === true) {
                    $data['email_err'] = 'It is not a valid email';
                } elseif ($this->userModel->isEmailRegistered($data['email'])) {
                    $data['email_err'] = 'This email is already registered!';
                }
                //Validate Password
                if( empty( $data['pwd']) ) {
                    $data['pwd_err'] = 'Password can\'t be empty';
                } elseif( strlen($data['pwd']) < 8 ) {
                    $data['pwd_err'] = 'Password must be of atleast 8 characters';
                } elseif( !preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $data['pwd']) ) {
                    $data['pwd_err'] = 'Password must contain atleast one special character';
                }
                //Validate Confirm Password
                if( empty($data['confirm_pwd']) ) {
                    $data['confirm_pwd_err'] = 'Confirm Password can not be empty.';
                } elseif ( strcmp($data['pwd'], $data['confirm_pwd']) != 0 ) {
                    $data['confirm_pwd_err'] = 'Confirm Password doesn\'t match original password';
                }
                //If all err fields are empty
                if( empty($data['name_err']) && empty($data['email_err']) && empty($data['pwd_err']) && empty($data['confirm_pwd_err']) ) {
                    //register
                    $data['pwd'] = password_hash($data['pwd'], PASSWORD_DEFAULT);
                    $result = $this->userModel->isRegister($data['name'], $data['email'], $data['pwd']);
                    if( $result  != 'success' ) {
                        die($result);
                    } else {
                        flash('register_success', 'Your Registration is successful. Kindly Login.');
                        redirect('users/login');
                    }
                } else {
                    $this->view('users/register', $data);
                }


            } else {
                //Data to be passed in View
                $data = [
                    'name' => '',
                    'email' => '',
                    'pwd' => '',
                    'confirm_pwd' => '',
                    'name_err' => '',
                    'email_err' => '',
                    'pwd_err' => '',
                    'confirm_pwd_err' => ''
                ];
                //Loading View
                $this->view('users/register', $data);
            }
        }
        public function login() {
            if($_SERVER['REQUEST_METHOD'] == 'POST') {
                //Data to be passed in View
                $data = [
                    'email' => $this->testInput($_POST['email']),
                    'pwd' => $this->testInput($_POST['pwd']),
                    'email_err' => '',
                    'pwd_err' => ''
                ];
                //Validate Email
                if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL) === true) {
                    $data['email_err'] = 'It is not a valid email address';
                    $this->view('users/login', $data);
                } elseif (!$this->userModel->isEmailRegistered($data['email'])) {
                    $data['email_err'] = 'This email is not registered!';
                    $this->view('users/login', $data);
                } else {
                    //Validate Password
                    $user = $this->userModel->getUserByEmail($data['email']);
                    if(!password_verify($data['pwd'], $user->pwd)) {
                        $data['pwd_err'] = 'Either email or password is wrong!!';
                        $this->view('users/login', $data);
                    } elseif ( $user->status != 'allowed' ) {
                        $data['pwd_err'] = 'You are blocked by the site owner.';
                        $this->view('users/login', $data);
                    } else {
                        $this->createSession($user);
                        flash('login_success', 'You are successfully Logged In');
                        redirect('eventOrders/index');
                    }
                }

            } else {
                //Data to be passed in View
                $data = [
                    'email' => '',
                    'pwd' => '',
                    'email_err' => '',
                    'pwd_err' => ''
                ];
                //Loading View
                $this->view('users/login', $data);
            }
        }
        //method to create login session
        public function createSession($user) {
            session_start();
            $_SESSION['user_id'] = $user->user_id;
            $_SESSION['user_email'] = $user->email;
        }
        //method to logout
        public function logout() {
            session_start();
            unset($_SESSION['user_id']);
            unset($_SESSION['user_email']);
            session_destroy();
            redirect('pages/index');
        }
    }