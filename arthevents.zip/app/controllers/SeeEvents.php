<?php
  class SeeEvents extends Controller {
    private $seeEventsModel;
    public function __construct() {
      $this->seeEventsModel = $this->model('SeeEvent');
      if( !isAdminLoggedIn() ) {
        redirect('dashboards/index');
      }
    }
    //default method
    public function index($currPage = 1) {
      $recordsPerPage = 10;
      $totalRecords = $this->seeEventsModel->getTotalRecords();
      $numOfPages = ceil( $totalRecords / $recordsPerPage );
      $offset = ($currPage - 1) * $recordsPerPage;
      $eventData = $this->seeEventsModel->getEventsData($offset, $recordsPerPage);
      $data = [
        'currPage' => $currPage,
        'numOfPages' => $numOfPages,
        'eventData' => $eventData
      ];
      $this->view('dashboard/seeEvents/index', $data);
    }
    //Method to show Event details
    public function showEventDetails($eventId) {
      $eventDetails = $this->seeEventsModel->getEventDetailsById($eventId);
      $pdIdArray = json_decode($eventDetails->ev_pd_id_array);
      $pdInfoArr = [];
      foreach ($pdIdArray as $pdId) {
        $pdInfo = $this->seeEventsModel->getPdInfoById($pdId);
        $pdInfoArr[] = $pdInfo;
      }
      $data = [
        'imgPath' => $eventDetails->img_path,
        'name' => $eventDetails->name,
        'evId' => $eventDetails->ev_order_id,
        'evStatus' => $eventDetails->ev_status,
        'evType' => $eventDetails->type,
        'date' => date("d-m-Y", strtotime($eventDetails->date)),
        'time' => $eventDetails->time,
        'evFor' => $eventDetails->ev_for,
        'mob1' => isNull($eventDetails->mob_1),
        'mob2' => isNull($eventDetails->mob_2),
        'evPriceCustomer' => $eventDetails->ev_cost_customer,
        'evPriceAdmin' => $eventDetails->ev_cost_admin,
        'pdInfoArr' => $pdInfoArr
      ];
      $this->view('dashboard/seeEvents/showEvent', $data); 
    }
    //Method for productFulfillDEtails
    public function productFulfillDetails($pdId, $evId) {
      $pdFulfillmentInfo = $this->seeEventsModel->getProductFulfillDetailsById($pdId);
      $address = 'House Number: '.$pdFulfillmentInfo->office_no.', Street: '.$pdFulfillmentInfo->street.', City: '.$pdFulfillmentInfo->city.', State: '.$pdFulfillmentInfo->state.', Country: '.$pdFulfillmentInfo->country.', Pincode: '.$pdFulfillmentInfo->pincode;
      $data = [
        'evId' => $evId,
        'imgPath' => $pdFulfillmentInfo->pd_img_path,
        'pdName' => $pdFulfillmentInfo->pd_name,
        'feature1' => $pdFulfillmentInfo->pd_feature1,
        'feature2' => $pdFulfillmentInfo->pd_feature2,
        'feature3' => $pdFulfillmentInfo->pd_feature3,
        'feature4' => $pdFulfillmentInfo->pd_feature4,
        'feature5' => $pdFulfillmentInfo->pd_feature5,
        'spName' => $pdFulfillmentInfo->spName,
        'companyName' => $pdFulfillmentInfo->company_name,
        'stype' => $pdFulfillmentInfo->stype,
        'spEmail' => isNull($pdFulfillmentInfo->email),
        'mob1' => isNull($pdFulfillmentInfo->mob_1),
        'mob2' => isNull($pdFulfillmentInfo->mob_2),
        'address' => $address,
        'priceCustomer' => $pdFulfillmentInfo->price_customer,
        'priceAdmin' => $pdFulfillmentInfo->price_admin
      ];
      $this->view('dashboard/seeEvents/productFulfillDetails', $data);
    }
    //Method to change EventOrder Status
    public function changeEventStatus($evId, $status) {
      $this->seeEventsModel->changeEventStatus($evId, $status);
      flash('event_status_changed', 'Event has been marked as <strong>'.$status.'</strong> successfully!');
      redirect('seeEvents/showEventDetails/'.$evId);
    }
    //Fulfill events Method
    public function fulfillEvents($currPage = 1, $status = 'uncompleted', $dateStatus = 'upcoming') {
      $recordsPerPage = 10;
      $totalRecords = $this->seeEventsModel->getTotalRecordsByCategory($status, $dateStatus);
      $numOfPages = ceil( $totalRecords / $recordsPerPage );
      $offset = ($currPage - 1) * $recordsPerPage;
      $eventData = $this->seeEventsModel->getEventsDataByCategory($offset, $recordsPerPage, $status, $dateStatus);
      $data = [
        'currPage' => $currPage,
        'status' => $status,
        'dateStatus' => $dateStatus,
        'numOfPages' => $numOfPages,
        'eventData' => $eventData
      ];
      $this->view('dashboard/seeEvents/fulfillEvents', $data);
    }
    //Method to send event name suggestions using AJAX
    public function giveEventNameSuggestions() {
      $searchInput = testInput($_GET['si']);
      $suggestedNames = [];
      if( !empty($searchInput)) {
        $searchInput = testInput($searchInput);
        $suggestedEventNames = $this->seeEventsModel->eventNameSuggestion($searchInput);
        foreach($suggestedEventNames as $eventNameObj) {
          $suggestedNames[$eventNameObj->name] = null;
        }
        if( empty($suggestedNames) ) {
          $suggestedNames = [
            'No results!' => null
          ];
        }
        echo json_encode($suggestedNames);
      } else {
        $suggestedNames = [
          'No results!' => null
        ];
        echo json_encode($suggestedNames);
      }
    }
    //Method to display event credentials by name
    public function searchEventByName() {
      $eventName = testInput($_GET['en']);
      $eventData = $this->seeEventsModel->searchEventByName($eventName);
      if( empty($eventData) ) {
        echo '<div class="row grey lighten-5 z-depth-2"><div class="col s12"><h6 class="blue-text text-darken-3 center">Searched Data</h6><p class="center">No Results Found!</p></div></div>';
      } else {
        echo '<div class="row grey lighten-5 z-depth-2">
        <div class="col s12">
        <h6 class="blue-text text-darken-3 center">Searched Data</h6>
        <div class="container">
        <table class="highlight responsive-table">
        <thead>
          <tr>
            <td><strong>Name</strong></td>
            <td><strong>Date</strong></td>
            <td><strong>Cost</strong></td>
            <td><strong>Status</strong></td>
            <td></td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>'.$eventData->name.'</td>
            <td>'.date("d-m-Y", strtotime($eventData->date)).'</td>
            <td>'.$eventData->ev_cost_customer.'</td>
            <td>'.$eventData->ev_status.'</td>
            <td><a href="'.URLROOT.'/seeEvents/showEventDetails/'.$eventData->ev_order_id.'" class="btn-small blue darken-3 waves-effect waves-light">Details</a></td>
          </tr>
        </tbody>
        </table>
        </div>
        </div>
        </div>';
      }
    }
  }