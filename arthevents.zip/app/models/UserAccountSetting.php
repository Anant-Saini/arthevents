<?php
    class UserAccountSetting {
        private $db;
        public function __construct() {
            $this->db = new Database();
        }
        //get User Infomation from user_id
        public function getUserInfoById($userId) {
            try {
                $sql = 'SELECT users.name, users.email, users.mob_1, users.mob_2, user_addresses.house_no, user_addresses.street, user_addresses.city, user_addresses.landmark, user_addresses.pincode, user_addresses.state, user_addresses.country 
                FROM users
                INNER JOIN user_addresses ON users.user_id = user_addresses.user_id WHERE users.user_id = :userID';
                $this->db->query($sql);
                $this->db->bind(':userID', $userId);
                $userInfo = $this->db->single();

                return $userInfo;

            } catch(PDOException $e) {
                die('Error: '.$e->getMessage());
            }
        }
        //Get Current User Password By ID
        public function getUserPwdById($userId) {
            try {
                $sql = 'SELECT pwd FROM users WHERE user_id = :userID';
                $this->db->query($sql);
                $this->db->bind(':userID', $userId);
                $userPwdInfo = $this->db->single();
                return $userPwdInfo;

            } catch (PDOException $e) {
                die('Error: '.$e->getMessage());
            }
        }
        //Update User Info
        public function updateUserInfo($formName, $formMob1, $formMob2, $userId){  try {
            $sql = 'UPDATE users SET name = :formName, mob_1 = :formMob1, mob_2 = :formMob2 WHERE user_id = :userID';
            $this->db->query($sql);
            $this->db->bind(':userID', $userId);
            $this->db->bind(':formName', $formName);
            $this->db->bind(':formMob1', $formMob1);
            $this->db->bind(':formMob2', $formMob2);
            $this->db->execute();
            } catch(PDOException $e) {
                die('Error: '.$e->getMessage());
            }
        }
        //Update User Address Info
        public function updateUserAddrInfo($formHouseNo, $formStreet, $formLandmark, $formCity, $formPincode, $formState, $userId) {  
            try {
            $sql = 'UPDATE user_addresses SET house_no = :formHouseNo, street = :formStreet, landmark = :formLandmark, city = :formCity, pincode = :formPincode, state = :formState WHERE user_id = :userID';
            $this->db->query($sql);
            $this->db->bind(':userID', $userId);
            $this->db->bind(':formHouseNo', $formHouseNo);
            $this->db->bind(':formStreet', $formStreet);
            $this->db->bind(':formLandmark', $formLandmark);
            $this->db->bind(':formCity', $formCity);
            $this->db->bind(':formPincode', $formPincode);
            $this->db->bind(':formState', $formState);
            $this->db->execute();
            } catch(PDOException $e) {
                die('Error: '.$e->getMessage());
            }
        }
        //Update User Password by UserId
        public function updateUserPwdById($formPwd, $userId) {  
            try {
            $sql = 'UPDATE users SET pwd = :formPwd WHERE user_id = :userID';
            $this->db->query($sql);
            $this->db->bind(':userID', $userId);
            $this->db->bind(':formPwd', $formPwd);
            $this->db->execute();
            } catch(PDOException $e) {
                die('Error: '.$e->getMessage());
            }
        }
        //Delete User Account By userId
        public function deleteUserAccById($userId) {
            try {
                $sql = 'DELETE FROM users WHERE user_id = :userID';
                $this->db->query($sql);
                $this->db->bind(':userID', $userId);
                $this->db->execute();
            } catch(PDOException $e) {
                die('Error: '.$e->getMessage());
            }
        }
    }