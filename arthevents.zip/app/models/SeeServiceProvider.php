<?php
  class SeeServiceProvider {
    private $db;
    public function __construct() {
      $this->db = new Database();
    }
    //function to get number of records from database table
    public function getTotalRecords() {
      try {
        $sql = 'SELECT sp_id FROM service_providers';
        $this->db->query($sql);
        $this->db->execute();
        $numOfSerProviders = $this->db->rowCount();
        return $numOfSerProviders;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to get user records from database table using limit and offset
    public function getSerProvidersData($offset = 0, $limit = 10) {
      try {
        $sql = 'SELECT sp_id, company_name, name, email FROM service_providers ORDER BY sp_id DESC LIMIT :offset, :limit';
        $this->db->query($sql);
        $this->db->bind(':offset', $offset);
        $this->db->bind(':limit', $limit);
        $serProvidersData = $this->db->resultSet();
        return $serProvidersData;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to get service provider details by spID
    public function getSPDetailById($spId) {
      try {
        $sql = 'SELECT sp.company_name, sp.name, sp.email, sp.mob_1, sp.mob_2, sp.sp_stype_id AS stype_id, spa.office_no, spa.street, spa.city, spa.state, spa.country, spa.pincode, st.name AS sp_type FROM service_providers AS sp INNER JOIN service_providers_addresses AS spa ON sp.sp_id = spa.sp_addr_sp_id INNER JOIN service_types AS st ON sp.sp_stype_id = st.stype_id WHERE sp.sp_id = :spId';
        $this->db->query($sql);
        $this->db->bind(':spId', $spId);
        $spDetails = $this->db->single();
        return $spDetails;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to get all products of a service provider by spID
    public function getSPProductsBySPId($spId) {
      try {
        $sql = 'SELECT pd.pd_id, pd.pd_name, pd.price_customer, pd.price_admin FROM products AS pd WHERE pd.pd_sp_id = :spId';
        $this->db->query($sql);
        $this->db->bind(':spId', $spId);
        $products = $this->db->resultSet();
        return $products;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to get product details by pdID
    public function getPdDetailsById($pdId) {
      try {
        $sql = 'SELECT pd.pd_name, pd.price_customer, pd.price_admin, pdd.pd_feature1, pdd.pd_feature2, pdd.pd_feature3, pdd.pd_feature4, pdd.pd_feature5, pdd.pd_img_path, st.name AS service_type, sp.company_name  FROM products AS pd INNER JOIN service_types AS st ON pd.pd_stype_id = st.stype_id INNER JOIN product_details AS pdd ON pd.pd_id = pdd.pdetails_pd_id INNER JOIN service_providers AS sp ON pd.pd_sp_id = sp.sp_id WHERE pd.pd_id = :pdId';
        $this->db->query($sql);
        $this->db->bind(':pdId', $pdId);
        $product = $this->db->single();
        return $product;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to get service types 
    public function getServiceTypes() {
      try {
        $sql = 'SELECT * FROM service_types';
        $this->db->query($sql);
        $this->db->resultSet();
        $serviceTypes = $this->db->resultSet();
        return $serviceTypes;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to insert service provider 
    public function insertSerProviderInfo($companyName, $name, $stypeId, $email, $mob1, $mob2, $officeNo, $street, $city, $pincode, $state, $country) {
      try {
          $this->db->beginTransaction();
          $sql = 'INSERT INTO service_providers(company_name, name, email, mob_1, mob_2, sp_stype_id) VALUES(:companyName, :name, :email, :mob1, :mob2, :stypeId)';
          $this->db->query($sql);
          $this->db->bind(':companyName', $companyName);
          $this->db->bind(':name', $name);
          $this->db->bind(':email', $email);
          $this->db->bind(':mob1', $mob1);
          $this->db->bind(':mob2', $mob2);
          $this->db->bind(':stypeId', $stypeId);
          $this->db->execute();
          $sql = 'INSERT INTO service_providers_addresses(office_no, street, city, pincode, state, country, sp_addr_sp_id) VALUES(:officeNo, :street, :city, :pincode, :state, :country, :spID)';
          $this->db->query($sql);
          $this->db->bind(':officeNo', $officeNo);
          $this->db->bind(':street', $street);
          $this->db->bind(':city', $city);
          $this->db->bind(':pincode', $pincode);
          $this->db->bind(':state', $state);
          $this->db->bind(':country', $country);
          $this->db->bind(':spID', $this->db->lastInsertId());
          $this->db->execute();
          $this->db->commit();
          return 'success';
      } catch (PDOException $e) {
          $this->db->rollback();
          return 'Error: '.$e->getMessage();
      }
    }
    //function to insert service provider with Product Info 
    public function insertSerProviderInfoWithProdInfo($companyName, $name, $stypeId, $email, $mob1, $mob2, $officeNo, $street, $city, $pincode, $state, $country, $pdName, $priceCustomer, $priceAdmin, $feature1, $feature2, $feature3, $feature4, $feature5, $pdImgActualExt = 'png', $pdImgTmpName = null) {
      try {
          $this->db->beginTransaction();
          $sql = 'INSERT INTO service_providers(company_name, name, email, mob_1, mob_2, sp_stype_id) VALUES(:companyName, :name, :email, :mob1, :mob2, :stypeId)';
          $this->db->query($sql);
          $this->db->bind(':companyName', $companyName);
          $this->db->bind(':name', $name);
          $this->db->bind(':email', $email);
          $this->db->bind(':mob1', $mob1);
          $this->db->bind(':mob2', $mob2);
          $this->db->bind(':stypeId', $stypeId);
          $this->db->execute();
          $generatedSpId = $this->db->lastInsertId();
          $sql = 'INSERT INTO service_providers_addresses(office_no, street, city, pincode, state, country, sp_addr_sp_id) VALUES(:officeNo, :street, :city, :pincode, :state, :country, :spID)';
          $this->db->query($sql);
          $this->db->bind(':officeNo', $officeNo);
          $this->db->bind(':street', $street);
          $this->db->bind(':city', $city);
          $this->db->bind(':pincode', $pincode);
          $this->db->bind(':state', $state);
          $this->db->bind(':country', $country);
          $this->db->bind(':spID', $generatedSpId);
          $this->db->execute();
          $sql = 'INSERT INTO products(pd_name, price_customer, price_admin, pd_sp_id, pd_stype_id) VALUES(:pdName, :priceCustomer, :priceAdmin, :pdSpId, :pdStypeId)';
          $this->db->query($sql);
          $this->db->bind(':pdName', $pdName);
          $this->db->bind(':priceCustomer', $priceCustomer);
          $this->db->bind(':priceAdmin', $priceAdmin);
          $this->db->bind(':pdSpId', $generatedSpId);
          $this->db->bind(':pdStypeId', $stypeId);
          $this->db->execute();
          $generatedPdId = $this->db->lastInsertId();
          $sql = 'INSERT INTO product_details(pd_feature1, pd_feature2, pd_feature3, pd_feature4, pd_feature5, pd_img_path, pdetails_pd_id, pdetails_sp_id) VALUES(:feature1, :feature2, :feature3, :feature4, :feature5, :pdImgName, :pdId, :spId)';
          $this->db->query($sql);
          if( empty($pdImgTmpName) ) {
            $pdImgNewName = "noImageAvailable".".".$pdImgActualExt;
          } else {
            $pdImgNewName = "pd_id_".$generatedPdId.".".$pdImgActualExt;
          }
          
          $this->db->bind(':feature1', $feature1);
          $this->db->bind(':feature2', $feature2);
          $this->db->bind(':feature3', $feature3);
          $this->db->bind(':feature4', $feature4);
          $this->db->bind(':feature5', $feature5);
          $this->db->bind(':pdImgName', $pdImgNewName);
          $this->db->bind(':pdId', $generatedPdId);
          $this->db->bind(':spId', $generatedSpId);
          $this->db->execute();
          //Finally upload the file to destination folder
          if( !empty($pdImgTmpName)) {
            //Img Destination
            $pdImgDestination = PUBLICROOT.'/img/productImgs/'.$pdImgNewName;
            if( !move_uploaded_file($pdImgTmpName, $pdImgDestination) ) {
              throw new Exception("Sorry, Unable to Upload Image to server. Error Occured!");
            }
          }
          $this->db->commit();
          return 'success';
      } catch (PDOException $e) {
          $this->db->rollback();
          return 'Error: '.$e->getMessage();
      } catch (Exception $e) {
          $this->db->rollback();
          return 'Error: '.$e->getMessage();
      }
    }
    //function to update service provider info 
    public function updateSerProviderInfo($companyName, $name, $stypeId, $email, $mob1, $mob2, $officeNo, $street, $city, $pincode, $state, $country, $spId) {
      try {
          $this->db->beginTransaction();
          $sql = 'UPDATE service_providers SET company_name = :companyName, name = :name, email = :email, mob_1 = :mob1, mob_2 = :mob2, sp_stype_id = :stypeId WHERE sp_id = :spId';
          $this->db->query($sql);
          $this->db->bind(':companyName', $companyName);
          $this->db->bind(':name', $name);
          $this->db->bind(':email', $email);
          $this->db->bind(':mob1', $mob1);
          $this->db->bind(':mob2', $mob2);
          $this->db->bind(':stypeId', $stypeId);
          $this->db->bind(':spId', $spId);
          $this->db->execute();
          $sql = 'UPDATE service_providers_addresses SET office_no = :officeNo, street = :street, city = :city, pincode = :pincode, state = :state, country = :country WHERE sp_addr_sp_id = :spId';
          $this->db->query($sql);
          $this->db->bind(':officeNo', $officeNo);
          $this->db->bind(':street', $street);
          $this->db->bind(':city', $city);
          $this->db->bind(':pincode', $pincode);
          $this->db->bind(':state', $state);
          $this->db->bind(':country', $country);
          $this->db->bind(':spId', $spId);
          $this->db->execute();
          $this->db->commit();
          return 'success';
      } catch (PDOException $e) {
          $this->db->rollback();
          return 'Error: '.$e->getMessage();
      }
    }
    //function to delete service provider
    public function deleteServiceProvider($spId) {
      try {
        $sql = 'DELETE FROM service_providers WHERE sp_id = :spId';
        $this->db->query($sql);
        $this->db->bind(':spId', $spId);
        $this->db->execute();
      } catch(PDOException $e) {
        return 'Error: '.$e->getMessage();
      }
    }
    //function to add product to a given service provider
    public function insertProductInfo($spId, $stypeId, $pdName, $priceCustomer, $priceAdmin, $feature1, $feature2, $feature3, $feature4, $feature5, $pdImgActualExt = 'png', $pdImgTmpName = null) {
      try {
        $this->db->beginTransaction();
        $sql = 'INSERT INTO products(pd_name, price_customer, price_admin, pd_sp_id, pd_stype_id) VALUES(:pdName, :priceCustomer, :priceAdmin, :pdSpId, :pdStypeId)';
          $this->db->query($sql);
          $this->db->bind(':pdName', $pdName);
          $this->db->bind(':priceCustomer', $priceCustomer);
          $this->db->bind(':priceAdmin', $priceAdmin);
          $this->db->bind(':pdSpId', $spId);
          $this->db->bind(':pdStypeId', $stypeId);
          $this->db->execute();
          $generatedPdId = $this->db->lastInsertId();
          $sql = 'INSERT INTO product_details(pd_feature1, pd_feature2, pd_feature3, pd_feature4, pd_feature5, pd_img_path, pdetails_pd_id, pdetails_sp_id) VALUES(:feature1, :feature2, :feature3, :feature4, :feature5, :pdImgName, :pdId, :spId)';
          $this->db->query($sql);
          if( empty($pdImgTmpName) ) {
            $pdImgNewName = "noImageAvailable".".".$pdImgActualExt;
          } else {
            $pdImgNewName = "pd_id_".$generatedPdId.".".$pdImgActualExt;
          }

          $this->db->bind(':feature1', $feature1);
          $this->db->bind(':feature2', $feature2);
          $this->db->bind(':feature3', $feature3);
          $this->db->bind(':feature4', $feature4);
          $this->db->bind(':feature5', $feature5);
          $this->db->bind(':pdImgName', $pdImgNewName);
          $this->db->bind(':pdId', $generatedPdId);
          $this->db->bind(':spId', $spId);
          $this->db->execute();
          //Finally upload the file to destination folder
          if( !empty($pdImgTmpName) ) {
            //Img Destination
            $pdImgDestination = PUBLICROOT.'/img/productImgs/'.$pdImgNewName;
            if( !move_uploaded_file($pdImgTmpName, $pdImgDestination) ) {
              throw new Exception("Sorry, Unable to Upload Image to server. Error Occured!");
            }
          }
          $this->db->commit();
          return 'success';

      } catch(PDOException $e) {
        $this->db->rollback();
        return 'Error: '.$e->getMessage();
      } catch (Exception $e) {
        $this->db->rollback();
        return 'Error: '.$e->getMessage();
      }
    }
    //function to delete product 
    public function deleteProduct($pdId) {
      try {
        $sql = 'DELETE FROM products WHERE pd_id = :pdId';
        $this->db->query($sql);
        $this->db->bind(':pdId', $pdId);
        $this->db->execute();
      } catch(PDOException $e) {
        return 'Error: '.$e->getMessage();
      }
    }
    //function to give service provider name suggestion
    public function serProNameSuggestion($searchInput) {
      try {
        $searchInput = "%".$searchInput."%";
        $sql = "SELECT name FROM service_providers WHERE name LIKE :searchInput";
        $this->db->query($sql);
        $this->db->bind(':searchInput', $searchInput);
        $suggestedSerProNames = $this->db->resultSet();
        return $suggestedSerProNames;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to search service provider by name
    public function searchSerProByName($serProName) {
      try {
        $sql = 'SELECT sp_id, company_name, name, email FROM service_providers WHERE name = :serproname';
        $this->db->query($sql);
        $this->db->bind(':serproname', $serProName);
        $serProData = $this->db->single(); 
        return $serProData;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
  }