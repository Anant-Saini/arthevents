<?php
    class MyEvent {
        private $db;
        public function __construct() {
            $this->db = new Database();
        }
        //Get All Event Orders associated with a particular user
        public function getEventOrderObjArr($userId) {
            try {
                $sql = 'SELECT eo.ev_order_id, et.img_path, eo.name, et.name et_name, eo.date, eo.time, eo.ev_for, eo.ev_cost_customer, eo.ev_status FROM event_orders eo INNER JOIN event_types et ON eo.ev_order_etype_id = et.etype_id WHERE eo.ev_order_user_id = :userId';
                $this->db->query($sql);
                $this->db->bind(':userId', $userId);
                $eventOrderObjArr = $this->db->resultSet();
                return $eventOrderObjArr;
            } catch(PDOException $e) {
                die('Error: '.$e->getMessage());
            }
        }
        //Get a particular event order by ID
        public function getEventOrderById($evOrderId) {
            try {
                $sql = 'SELECT eo.ev_order_id, et.img_path, eo.name, et.name et_name, eo.date, eo.time, eo.ev_for, eo.ev_cost_customer, eo.ev_status, eo.ev_pd_id_array FROM event_orders eo INNER JOIN event_types et ON eo.ev_order_etype_id = et.etype_id WHERE eo.ev_order_id = :evOrderId';
                $this->db->query($sql);
                $this->db->bind(':evOrderId', $evOrderId);
                $eventOrder = $this->db->single();
                return $eventOrder;
            } catch(PDOException $e) {
                die('Error: '.$e->getMessage());
            }
        }
        //get PdObj from PdId
        public function getPdObjFromId($pdId) {
            try {
                $sql = 'SELECT p.pd_id, p.pd_name, pd.pd_img_path, st.name, sp.company_name, p.price_customer FROM products p INNER JOIN service_types st ON p.pd_stype_id = st.stype_id INNER JOIN service_providers sp ON p.pd_sp_id = sp.sp_id INNER JOIN product_details as pd ON p.pd_id = pd.pdetails_pd_id  WHERE p.pd_id = :pdId';
                $this->db->query($sql);
                $this->db->bind(':pdId', $pdId);
                $pdObj = $this->db->single();
                return $pdObj;
            } catch(PDOException $e) {
                die('Error: '.$e->getMessage());
            }
        }
        //Delete Event Order By Id
        public function delEventOrderById($evOrderId) {
            try {
                $sql = 'DELETE FROM event_orders WHERE ev_order_id = :evOrderId';
                $this->db->query($sql);
                $this->db->bind(':evOrderId', $evOrderId);
                $this->db->execute();
            } catch(PDOException $e) {
                die('Error: '.$e->getMessage());
            }
        } 
    }