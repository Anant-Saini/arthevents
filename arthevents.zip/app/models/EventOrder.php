<?php
    class EventOrder {
        private $db;
        public function __construct() {
            $this->db = new Database();
        }
        //get event types object array 
        public function getEvTypesObjArr() {
            try {
                $sql = 'SELECT * FROM event_types';
                $this->db->query($sql);
                $eventTypesObjArr = $this->db->resultSet();
                return $eventTypesObjArr;
            } catch(PDOException $e) {
                die('Error: '.$e->getMessage());
            }
        }
        //get event type Obj from event_type ID
        public function getEvTypeObjFromId($eventTypeId) {
            try {
                $sql = 'SELECT etype_id, name, img_path FROM event_types WHERE etype_id = :eventTypeId';
                $this->db->query($sql);
                $this->db->bind(':eventTypeId', $eventTypeId);
                $eventTypeObj = $this->db->single();
                return $eventTypeObj;
            } catch(PDOException $e) {
                die('Error: '.$e->getMessage());
            }
        }
        //get services types object array 
        public function getServiceTypesObjArr() {
            try {
                $sql = 'SELECT * FROM service_types';
                $this->db->query($sql);
                $serviceTypesObjArr = $this->db->resultSet();
                return $serviceTypesObjArr;
            } catch(PDOException $e) {
                die('Error: '.$e->getMessage());
            }
        }
        //get service type Obj from service ID
        public function getSTypeObjFromId($serviceTypeId) {
            try {
                $sql = 'SELECT stype_id, name FROM service_types WHERE stype_id = :serviceTypeId';
                $this->db->query($sql);
                $this->db->bind(':serviceTypeId', $serviceTypeId);
                $serviceTypeObj = $this->db->single();
                return $serviceTypeObj;
            } catch(PDOException $e) {
                die('Error: '.$e->getMessage());
            }
        }
        //get all products under a specific service type in an obj array
        public function getPdsFromStypeId($serviceTypeId) {
            try {
                $sql = 'SELECT sp.company_name, p.pd_id, p.pd_name, pd.pd_feature1, pd.pd_feature2, pd.pd_feature3, pd.pd_feature4, pd.pd_feature5, pd.pd_img_path, p.price_customer FROM products p INNER JOIN product_details pd ON p.pd_id = pd.pdetails_pd_id INNER JOIN service_providers sp ON p.pd_sp_id = sp.sp_id WHERE p.pd_stype_id = :serviceTypeId';
                $this->db->query($sql);
                $this->db->bind(':serviceTypeId', $serviceTypeId);
                $pdsUnderStypeObjArr = $this->db->resultSet();
                return $pdsUnderStypeObjArr;
            } catch(PDOException $e) {
                die('Error: '.$e->getMessage());
            }
        }
        //get PdObj from PdId
        public function getPdObjFromId($pdId) {
            try {
                $sql = 'SELECT p.pd_id, p.pd_name, pd.pd_img_path, st.name, sp.company_name, p.price_customer, p.price_admin FROM products p INNER JOIN service_types st ON p.pd_stype_id = st.stype_id INNER JOIN service_providers sp ON p.pd_sp_id = sp.sp_id INNER JOIN product_details as pd ON p.pd_id = pd.pdetails_pd_id  WHERE p.pd_id = :pdId';
                $this->db->query($sql);
                $this->db->bind(':pdId', $pdId);
                $pdObj = $this->db->single();
                return $pdObj;
            } catch(PDOException $e) {
                die('Error: '.$e->getMessage());
            }
        }
        //get Both Mobile Numbers from Users by UserId
        public function getMobObjFromUserId($userId) {
            try {
                $sql = 'SELECT mob_1, mob_2 FROM users WHERE user_id = :userId';
                $this->db->query($sql);
                $this->db->bind(':userId', $userId);
                $mobObj = $this->db->single();
                return $mobObj;
            } catch(PDOException $e) {
                die('Error: '.$e->getMessage());
            }
        }
        //Insert Event Order inside event_orders table
        public function placeEventOrder($name, $date, $time, $ev_for, $stypes_id_array, $pd_id_array, $cost_customer, $cost_admin, $etype_id, $user_id, $mob1, $mob2) {
            try {
                $this->db->beginTransaction();
                $sql = 'INSERT INTO event_orders( name, date, time, ev_for,ev_stypes_id_array, ev_pd_id_array, ev_cost_customer, ev_cost_admin,	ev_order_etype_id, ev_order_user_id ) VALUES(:name, :date, :time, :ev_for, :stypes_id_array, :pd_id_array, :cost_customer, :cost_admin, :etype_id, :user_id)';
                $this->db->query($sql);
                $this->db->bind(':name', $name);
                $this->db->bind(':date', $date);
                $this->db->bind(':time', $time);
                $this->db->bind(':ev_for', $ev_for);
                $this->db->bind(':stypes_id_array', $stypes_id_array);
                $this->db->bind(':pd_id_array', $pd_id_array);
                $this->db->bind(':cost_customer', $cost_customer);
                $this->db->bind(':cost_admin', $cost_admin);
                $this->db->bind(':etype_id', $etype_id);
                $this->db->bind(':user_id', $user_id);
                $this->db->execute();
                $sql = 'UPDATE users SET mob_1 = :mob1, mob_2 = :mob2 WHERE user_id = :user_id';
                $this->db->query($sql);
                $this->db->bind(':mob1', $mob1);
                $this->db->bind(':mob2', $mob2);
                $this->db->bind(':user_id', $user_id);
                $this->db->execute();
                $this->db->commit();
            } catch(PDOException $e) {
                $this->db->rollback();
                die('Order Placing Failed: '.$e->getMessage());
            }
        }
    }