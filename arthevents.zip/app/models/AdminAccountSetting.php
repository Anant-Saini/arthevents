<?php
 class AdminAccountSetting {
    private $db;
    public function __construct() {
      $this->db = new Database();
    }
    //get Admin Infomation from admin_id
    public function getAdminInfoById($adminId) {
      try {
        $sql = 'SELECT name, email, img_path FROM admin WHERE admin_id = :adminID';
        $this->db->query($sql);
        $this->db->bind(':adminID', $adminId);
        $adminInfo = $this->db->single();
        return $adminInfo;

      } catch(PDOException $e) {
        die('Error: '.$e->getMessage());
      }
    }
    //update admin details method
    public function updateAdminDetails($email, $name, $adminId) {
      try {
        $sql = 'UPDATE admin SET name = :name, email = :email WHERE admin_id = :adminID';
        $this->db->query($sql);
        $this->db->bind(':name', $name);
        $this->db->bind(':email', $email);
        $this->db->bind(':adminID', $adminId);
        $this->db->execute();

      } catch(PDOException $e) {
        die('Error: '.$e->getMessage());
      }
    }
    //Get Current Admin Password By ID
    public function getAdminPwdById($adminId) {
      try {
          $sql = 'SELECT pwd FROM admin WHERE admin_id = :adminId';
          $this->db->query($sql);
          $this->db->bind(':adminId', $adminId);
          $adminPwdInfo = $this->db->single();
          return $adminPwdInfo;

      } catch (PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //Update Admin Password by adminId
    public function updateAdminPwdById($formPwd, $adminId) {  
      try {
      $sql = 'UPDATE admin SET pwd = :formPwd WHERE admin_id = :adminId';
      $this->db->query($sql);
      $this->db->bind(':adminId', $adminId);
      $this->db->bind(':formPwd', $formPwd);
      $this->db->execute();
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //Update Admin Image
    public function updateAdminImg($adminImgTmpName = null, $adminImgActualExt = 'png', $adminId) {  
      try {
      if( empty($adminImgTmpName) ) {
        $adminImgNewName = "noAdminImg".".".$adminImgActualExt;
      } else {
        $adminImgNewName = "adminImg".".".$adminImgActualExt;
      }
      //Img Destination
      $adminImgDestination = PUBLICROOT.'/img/dashboardImgs/'.$adminImgNewName;
      $sql = 'UPDATE admin SET img_path = :imgPath WHERE admin_id = :adminId';
      $this->db->query($sql);
      $this->db->bind(':adminId', $adminId);
      $this->db->bind(':imgPath', $adminImgNewName);
      //Move (Upload) Image
      if( !empty($adminImgTmpName) ) {
        if( !move_uploaded_file($adminImgTmpName, $adminImgDestination) ) {
          throw new Exception("Sorry, Unable to Upload Image to server. Error Occured!");
        }
      }
      $this->db->execute();
      return 'success';
      } catch(PDOException $e) {
        return 'Error: '.$e->getMessage();
      } catch (Exception $e) {
        return 'Error: '.$e->getMessage();
      }
    }
    //Delete Admin Image
    public function deleteAdminImg($imgName, $adminId) {
      try {
        $adminImgNewName = "noAdminImg.png";
        //Img Destination
        $adminImgDestination = PUBLICROOT.'/img/dashboardImgs/'.$imgName;
        $sql = 'UPDATE admin SET img_path = :imgPath WHERE admin_id = :adminId';
        $this->db->query($sql);
        $this->db->bind(':adminId', $adminId);
        $this->db->bind(':imgPath', $adminImgNewName);
        //Unlink (delete) Image
        if( file_exists($adminImgDestination) ) {
          unlink($adminImgDestination);
        } else {
          throw new Exception("Sorry, Unable to delete Image from server. Error Occured!");
        }
        $this->db->execute();
        return 'success';
      } catch(PDOException $e) {
        return 'Error: '.$e->getMessage();
      } catch (Exception $e) {
        return 'Error: '.$e->getMessage();
      }
    }

 }