<?php
    class User {
        private $db;
        public function __construct() {
            $this->db = new Database();
        }
        //register user
        public function isRegister($userName, $userEmail, $userPwd) {
            try {
                $this->db->beginTransaction();
                $sql = 'INSERT INTO users(name, email, pwd) VALUES(:name, :email, :pwd)';
                $this->db->query($sql);
                $this->db->bind(':name', $userName);
                $this->db->bind(':email', $userEmail);
                $this->db->bind(':pwd', $userPwd);
                $this->db->execute();
                $sql = 'INSERT INTO user_addresses(user_id) VALUES(:userID)';
                $this->db->query($sql);
                $this->db->bind(':userID', $this->db->lastInsertId());
                $this->db->execute();
                $this->db->commit();
                return 'success';
            } catch (PDOException $e) {
                $this->db->rollback();
                return 'Error: '.$e->getMessage();
            }
        }
        //isEmailRegistered
        public function isEmailRegistered($formEmail) {
            try {
                $sql = 'SELECT * FROM users WHERE email = :email';
                $this->db->query($sql);
                $this->db->bind(':email', $formEmail);
                $this->db->execute();
                $rowCount = $this->db->rowCount();
                if( $rowCount > 0) {
                    return true;
                } else {
                    return false;
                }
            } catch (PDOException $e) {
                die('Error: '.$e->getMessage());
            }
        }
        //getUserByEmail
        public function getUserByEmail($formEmail) {
            try {
                $sql = 'SELECT * FROM users WHERE email = :email';
                $this->db->query($sql);
                $this->db->bind(':email', $formEmail);
                $user = $this->db->single();
                return $user;
            } catch (PDOException $e) {
                die('Error: '.$e->getMessage());
            }
        }

    }