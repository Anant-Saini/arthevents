<?php
  class SeeEvent {
    private $db;
    public function __construct() {
      $this->db = new Database();
    }
    //function to get number of records from database table
    public function getTotalRecords() {
      try {
        $sql = 'SELECT ev_order_id FROM event_orders';
        $this->db->query($sql);
        $this->db->execute();
        $numOfEvents = $this->db->rowCount();
        return $numOfEvents;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to get user records from database table using limit and offset
    public function getEventsData($offset = 0, $limit = 10) {
      try {
        $sql = 'SELECT ev_order_id, name, date, ev_cost_customer, ev_status FROM event_orders LIMIT :offset, :limit';
        $this->db->query($sql);
        $this->db->bind(':offset', $offset);
        $this->db->bind(':limit', $limit);
        $eventData = $this->db->resultSet();
        return $eventData;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to get event details by evID
    public function getEventDetailsById($evId) {
      try {
        $sql = 'SELECT et.img_path, eo.ev_order_id, eo.ev_status, eo.name, et.name AS type, eo.date, eo.time, eo.ev_for, eo.ev_pd_id_array, eo.ev_cost_customer, eo.ev_cost_admin, u.mob_1, u.mob_2 FROM event_orders AS eo INNER JOIN event_types AS et ON eo.ev_order_etype_id = et.etype_id INNER JOIN users AS u ON eo.ev_order_user_id = u.user_id WHERE eo.ev_order_id = :evId';
        $this->db->query($sql);
        $this->db->bind(':evId', $evId);
        $event = $this->db->single();
        return $event;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to get some product details by ID
    public function getPdInfoById($pdId) {
      try {
        $sql = 'SELECT pd.pd_id, pd.pd_name, pd.price_customer, pd.price_admin, st.name AS type, sp.company_name FROM products AS pd INNER JOIN service_types AS st ON pd.pd_stype_id = st.stype_id INNER JOIN service_providers AS sp ON sp.sp_id = pd.pd_sp_id WHERE pd.pd_id = :pdId';
        $this->db->query($sql);
        $this->db->bind(':pdId', $pdId);
        $pdInfo = $this->db->single();
        return $pdInfo;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to get product fulfill details by product ID
    public function getProductFulfillDetailsById($pdId) {
      try {
        $sql = 'SELECT pdd.pd_img_path, pd.pd_name, pdd.pd_feature1, pdd.pd_feature2, pdd.pd_feature3, pdd.pd_feature4, pdd.pd_feature5, sp.name AS spName, sp.company_name, st.name AS stype, sp.mob_1, sp.mob_2, sp.email, spa.office_no, spa.street, spa.city, spa.pincode, spa.state, spa.country, pd.price_customer, pd.price_admin FROM products AS pd INNER JOIN product_details AS pdd ON pd.pd_id = pdd.pdetails_pd_id INNER JOIN service_types AS st ON pd.pd_stype_id = st.stype_id INNER JOIN service_providers AS sp ON sp.sp_id = pd.pd_sp_id INNER JOIN service_providers_addresses AS spa ON sp.sp_id = spa.sp_addr_sp_id WHERE pd.pd_id = :pdId';
        $this->db->query($sql);
        $this->db->bind(':pdId', $pdId);
        $pdFulfillmentInfo = $this->db->single();
        return $pdFulfillmentInfo;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //Function to change event status
    public function changeEventStatus($evId, $status) {
      try {
        $sql = 'UPDATE event_orders SET ev_status = :newStatus WHERE ev_order_id = :evId';
        $this->db->query($sql);
        $this->db->bind(':newStatus', $status);
        $this->db->bind(':evId', $evId);
        $this->db->execute();
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to get number of records from database table with constraints
    public function getTotalRecordsByCategory($status, $dateStatus) {
      try {
        if($dateStatus == 'upcoming') {
          $sql = 'SELECT ev_order_id FROM event_orders WHERE ev_status = :status AND date >= CURDATE()';
        } else {
          $sql = 'SELECT ev_order_id FROM event_orders WHERE ev_status = :status AND date < CURDATE()';
        }
        
        $this->db->query($sql);
        $this->db->bind(':status', $status);
        $this->db->execute();
        $numOfEvents = $this->db->rowCount();
        return $numOfEvents;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to get user records from database table using limit and offset
    public function getEventsDataByCategory($offset = 0, $limit = 10, $status, $dateStatus) {
      try {
        if($dateStatus == 'upcoming') {
          $sql = 'SELECT ev_order_id, name, date, ev_cost_customer, ev_status FROM event_orders WHERE ev_status = :status AND date >= CURDATE() ORDER BY date ASC LIMIT :offset, :limit';
        } else {
          $sql = 'SELECT ev_order_id, name, date, ev_cost_customer, ev_status FROM event_orders WHERE ev_status = :status AND date < CURDATE() ORDER BY date DESC LIMIT :offset, :limit';
        }
        $this->db->query($sql);
        $this->db->bind(':status', $status);
        $this->db->bind(':offset', $offset);
        $this->db->bind(':limit', $limit);
        $eventData = $this->db->resultSet();
        return $eventData;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to give event name suggestion
    public function eventNameSuggestion($searchInput) {
      try {
        $searchInput = "%".$searchInput."%";
        $sql = "SELECT name FROM event_orders WHERE name LIKE :searchInput";
        $this->db->query($sql);
        $this->db->bind(':searchInput', $searchInput);
        $suggestedEventNames = $this->db->resultSet();
        return $suggestedEventNames;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to search event by name
    public function searchEventByName($eventName) {
      try {
        $sql = 'SELECT ev_order_id, name, date, ev_cost_customer, ev_status FROM event_orders WHERE name = :eventname';
        $this->db->query($sql);
        $this->db->bind(':eventname', $eventName);
        $eventData = $this->db->single(); 
        return $eventData;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
  }