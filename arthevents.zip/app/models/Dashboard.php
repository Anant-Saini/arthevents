<?php
  class Dashboard {
    private $db;
    public function __construct() {
      $this->db = new Database();
    }
    //isEmailRegistered
    public function isEmailRegistered($formEmail) {
      try {
        $sql = 'SELECT * FROM admin WHERE email = :formEmail';
        $this->db->query($sql);
        $this->db->bind(':formEmail', $formEmail);
        $this->db->execute();
        $rowCount = $this->db->rowCount();
        if( $rowCount > 0) {
          return True;
        } else {
          return False;
        }
      } catch(PDOException $e) {
        die('Error: '.$e->getMessage());
      }
    }
    //getUserByEmail
    public function getAdminByEmail($formEmail) {
      try {
          $sql = 'SELECT * FROM admin WHERE email = :formEmail';
          $this->db->query($sql);
          $this->db->bind(':formEmail', $formEmail);
          $admin = $this->db->single();
          return $admin;
      } catch (PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //get Uncompleted User Count
    public function getCountUpcomingUncompletedEvents() {
      try {
          $sql = 'SELECT * FROM event_orders WHERE ev_status = :evStatus AND date >= CURDATE()';
          $this->db->query($sql);
          $this->db->bind(':evStatus', "uncompleted");
          $this->db->execute();
          $count = $this->db->rowCount();
          return $count;
      } catch (PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //getUserByEmail
    public function getCountUsers() {
      try {
        $sql = 'SELECT * FROM users';
        $this->db->query($sql);
        $this->db->execute();
        $count = $this->db->rowCount();
        return $count;
      } catch (PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //getUserByEmail
    public function getCountSerProviders() {
      try {
        $sql = 'SELECT * FROM service_providers';
        $this->db->query($sql);
        $this->db->execute();
        $count = $this->db->rowCount();
        return $count;
      } catch (PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //get first 10 Event Orders by date
    public function getTenUpcomingEventOrders() {
      try {
        $sql = 'SELECT ev_order_id, name, date, ev_cost_customer FROM event_orders WHERE date > CURDATE() AND ev_status = :status ORDER BY date ASC LIMIT 10';
        $this->db->query($sql);
        $this->db->bind(':status', 'uncompleted');
        $resultSet = $this->db->resultSet();
        return $resultSet;
      } catch (PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }

  }
  