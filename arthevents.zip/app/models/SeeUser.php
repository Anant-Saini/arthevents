<?php
  class SeeUser {
    private $db;
    public function __construct() {
      $this->db = new Database();
    }
    //function to get number of records from database table
    public function getTotalRecords() {
      try {
        $sql = 'SELECT user_id FROM users';
        $this->db->query($sql);
        $this->db->execute();
        $numOfUsers = $this->db->rowCount();
        return $numOfUsers;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to get user records from database table using limit and offset
    public function getUsersData($offset = 0, $limit = 10) {
      try {
        $sql = 'SELECT user_id, name, email, status FROM users LIMIT :offset, :limit';
        $this->db->query($sql);
        $this->db->bind(':offset', $offset);
        $this->db->bind(':limit', $limit);
        $userData = $this->db->resultSet();
        return $userData;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to get user details by userID
    public function getUserDetailById($userId) {
      try {
        $sql = 'SELECT u.name, u.email, u.status, u.mob_1, u.mob_2, u.created_at, ua.house_no, ua.street, ua.city, ua.state, ua.country, ua.landmark, ua.pincode FROM users AS u INNER JOIN user_addresses AS ua ON u.user_id = ua.user_id WHERE u.user_id = :userId';
        $this->db->query($sql);
        $this->db->bind(':userId', $userId);
        $userDetails = $this->db->single();
        return $userDetails;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to change user status by userID
    public function changeUserStatusById($userId, $status) {
      try {
        $sql = 'UPDATE users SET status = :status WHERE user_id = :userId';
        $this->db->query($sql);
        $this->db->bind(':status', $status);
        $this->db->bind(':userId', $userId);
        $this->db->execute();
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to give user name suggestion
    public function userNameSuggestion($searchInput) {
      try {
        $searchInput = "%".$searchInput."%";
        $sql = "SELECT name FROM users WHERE name LIKE :searchInput";
        $this->db->query($sql);
        $this->db->bind(':searchInput', $searchInput);
        $suggestedUserNames = $this->db->resultSet();
        return $suggestedUserNames;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
    //function to search user by name
    public function searchUserByName($userName) {
      try {
        $sql = 'SELECT user_id, name, email, status FROM users WHERE name = :username';
        $this->db->query($sql);
        $this->db->bind(':username', $userName);
        $userData = $this->db->single(); 
        return $userData;
      } catch(PDOException $e) {
          die('Error: '.$e->getMessage());
      }
    }
  }