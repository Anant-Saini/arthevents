-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2020 at 02:33 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `arthevents`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` text NOT NULL,
  `pwd` text NOT NULL,
  `img_path` text NOT NULL DEFAULT 'noAdminImg.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `name`, `email`, `pwd`, `img_path`) VALUES
(1, 'Anant Saini', 'anantsaini.india@gmail.com', 'anant_saini', 'adminImg.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `basic_packages`
--

CREATE TABLE `basic_packages` (
  `basic_pkg_id` int(11) NOT NULL,
  `pd_id_array` text DEFAULT NULL,
  `pkg_price_customer` int(11) DEFAULT NULL,
  `pkg_price_admin` int(11) DEFAULT NULL,
  `basic_pkg_etype_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `classic_packages`
--

CREATE TABLE `classic_packages` (
  `classic_pkg_id` int(11) NOT NULL,
  `pd_id_array` text DEFAULT NULL,
  `pkg_price_customer` int(11) DEFAULT NULL,
  `pkg_price_admin` int(11) DEFAULT NULL,
  `classic_pkg_etype_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `event_orders`
--

CREATE TABLE `event_orders` (
  `ev_order_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `date` date DEFAULT NULL,
  `time` time NOT NULL DEFAULT '00:00:00',
  `ev_for` varchar(255) NOT NULL DEFAULT 'N/A',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `ev_stypes_id_array` text DEFAULT NULL,
  `ev_pd_id_array` text DEFAULT NULL,
  `ev_cost_customer` int(11) NOT NULL,
  `ev_cost_admin` int(11) NOT NULL,
  `ev_status` varchar(255) NOT NULL DEFAULT 'uncompleted',
  `ev_order_etype_id` int(11) NOT NULL,
  `ev_order_user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `event_orders`
--

INSERT INTO `event_orders` (`ev_order_id`, `name`, `date`, `time`, `ev_for`, `created_at`, `ev_stypes_id_array`, `ev_pd_id_array`, `ev_cost_customer`, `ev_cost_admin`, `ev_status`, `ev_order_etype_id`, `ev_order_user_id`) VALUES
(19, 'Shiva\'s Birthday', '2020-10-10', '20:30:00', 'Shiva Sharma', '2020-09-17 22:06:14', '[\"1\",\"2\",\"4\",\"5\",\"10\"]', '[\"1\",\"5\",\"11\",\"14\",\"29\"]', 115000, 90500, 'completed', 2, 35),
(20, 'Aadya\'s Birthday', '2020-10-12', '19:30:00', 'Aadya Saini', '2020-09-17 22:09:55', '[\"2\",\"4\",\"5\",\"10\"]', '[\"5\",\"10\",\"14\",\"29\"]', 80500, 63000, 'completed', 2, 37),
(21, 'Marriage Anniversary', '2020-12-08', '19:30:00', 'Kishor Saini and Rachna Saini', '2020-09-17 22:29:35', '[\"1\",\"2\",\"4\",\"5\",\"6\",\"9\",\"10\"]', '[\"2\",\"5\",\"11\",\"14\",\"17\",\"26\",\"29\"]', 188000, 155500, 'declined', 2, 37),
(22, 'Nitin\'s Wedding', '2020-10-23', '21:00:00', 'Nitin and Shailza', '2020-09-17 22:33:04', '[\"1\",\"2\",\"4\",\"5\",\"6\",\"8\",\"9\"]', '[\"2\",\"5\",\"11\",\"14\",\"17\",\"23\",\"25\"]', 195000, 169000, 'completed', 1, 38),
(23, 'Nitin\'s Birthday', '2020-11-07', '19:30:00', 'Nitin Pundir', '2020-09-17 22:35:04', '[\"2\",\"4\",\"5\",\"10\"]', '[\"5\",\"11\",\"14\",\"28\"]', 85000, 68000, 'declined', 2, 38),
(24, 'Diksha\'s Birthday', '2020-10-16', '20:00:00', 'Diksha Pundir', '2020-09-17 22:38:33', '[\"2\",\"4\",\"5\",\"10\"]', '[\"4\",\"10\",\"13\",\"28\"]', 25500, 19500, 'completed', 2, 39),
(25, 'Diksha\'s Wedding', '2020-12-20', '20:30:00', 'Diksha and Naman', '2020-09-17 22:40:53', '[\"1\",\"2\",\"4\",\"5\",\"6\",\"7\",\"8\",\"9\"]', '[\"2\",\"5\",\"11\",\"14\",\"17\",\"20\",\"23\",\"26\"]', 216000, 181000, 'declined', 1, 39),
(26, 'Annual Day Function', '2021-01-25', '09:00:00', 'Hitanshu Group of Schools', '2020-09-17 22:44:12', '[\"2\",\"4\",\"6\",\"8\"]', '[\"6\",\"11\",\"17\",\"23\"]', 205000, 167000, 'completed', 4, 40),
(27, 'Papli\'s Funeral', '2020-09-25', '18:30:00', 'Papli Saini', '2020-09-17 22:45:48', '[\"2\",\"3\"]', '[\"5\",\"8\"]', 58000, 45000, 'uncompleted', 3, 40),
(28, 'Aman\'s Birthday', '2020-11-04', '18:30:00', 'Aman Verma', '2020-09-17 22:49:08', '[\"1\",\"2\",\"4\",\"5\",\"6\",\"8\",\"9\",\"10\"]', '[\"1\",\"4\",\"10\",\"13\",\"16\",\"22\",\"25\",\"28\"]', 130500, 109500, 'declined', 2, 41),
(29, 'Aman\'s Party Night', '2021-02-16', '21:00:00', 'Aman Verma', '2020-09-17 22:50:34', '[\"1\",\"2\",\"5\",\"10\"]', '[\"1\",\"4\",\"13\",\"28\"]', 45000, 35000, 'completed', 5, 41),
(30, 'Atul\'s Wedding', '2020-10-22', '21:00:00', 'Atul and Anusha', '2020-09-17 23:07:59', '[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"8\",\"9\"]', '[\"2\",\"5\",\"8\",\"11\",\"14\",\"17\",\"23\",\"26\"]', 216000, 179000, 'completed', 1, 42),
(31, 'Mom\'s Funeral', '2020-11-21', '09:00:00', 'Sudha Yadav', '2020-09-17 23:10:37', '[\"2\",\"3\",\"9\"]', '[\"4\",\"7\",\"25\"]', 20000, 21000, 'completed', 3, 42),
(32, 'Sambhav\'s Birthday', '2020-10-04', '06:00:00', 'Sambhav Jain', '2020-09-17 23:14:18', '[\"1\",\"2\",\"4\",\"5\",\"6\",\"8\",\"9\",\"10\"]', '[\"1\",\"4\",\"10\",\"13\",\"16\",\"22\",\"25\",\"29\"]', 135500, 112000, 'declined', 2, 43),
(33, 'Party of The Life', '2020-12-17', '22:00:00', 'Sambhav Jain', '2020-09-17 23:16:02', '[\"1\",\"2\",\"5\",\"10\"]', '[\"1\",\"4\",\"13\",\"28\"]', 45000, 35000, 'declined', 5, 43),
(34, 'Engagement Party', '2020-09-26', '20:30:00', 'Shweta and Ankur', '2020-09-18 18:20:59', '[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"8\",\"9\"]', '[\"2\",\"4\",\"8\",\"12\",\"13\",\"18\",\"24\",\"27\"]', 268000, 214000, 'uncompleted', 1, 44),
(35, 'Pihu\'s Wedding', '2020-10-28', '19:30:00', 'Pihu and Ankur', '2020-09-27 22:14:11', '[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"8\",\"9\"]', '[\"3\",\"5\",\"8\",\"10\",\"14\",\"17\",\"23\",\"26\"]', 201500, 169000, 'declined', 1, 35),
(36, 'Shray\'s Birthday', '2020-10-21', '07:30:00', 'Shray', '2020-10-01 00:44:33', '[\"2\",\"10\"]', '[\"4\",\"28\"]', 10000, 7000, 'completed', 2, 41),
(37, 'Mom\'s Funeral', '2020-11-18', '18:30:00', 'Urmila Tagore', '2020-10-01 00:46:26', '[\"2\",\"3\"]', '[\"5\",\"8\"]', 58000, 45000, 'declined', 3, 41),
(38, 'Gaurav\'s Birthday', '2020-10-17', '05:30:00', 'Gaurav', '2020-10-01 00:48:16', '[\"2\",\"5\",\"10\"]', '[\"6\",\"14\",\"28\"]', 120000, 91000, 'completed', 2, 40),
(39, 'Papa\'s Funeral', '2020-10-17', '17:30:00', 'Bablu Saini', '2020-10-01 00:53:17', '[\"2\",\"3\"]', '[\"4\",\"8\"]', 13000, 8000, 'completed', 3, 40),
(40, 'My Birthday', '2020-10-30', '19:30:00', 'Shweta', '2020-10-01 00:56:36', '[\"1\",\"2\",\"5\",\"10\"]', '[\"1\",\"4\",\"13\",\"28\"]', 45000, 35000, 'declined', 2, 44),
(41, 'Nitin\'s Birthday', '2020-12-17', '17:30:00', 'Nitin Sona', '2020-10-01 00:58:28', '[\"2\",\"4\",\"5\",\"10\"]', '[\"5\",\"11\",\"14\",\"29\"]', 90000, 70500, 'declined', 2, 44),
(42, 'Vipul\'s Birthday', '2020-10-25', '18:30:00', 'Vipul Yadav', '2020-10-01 01:02:03', '[\"1\",\"3\",\"4\",\"10\"]', '[\"1\",\"7\",\"11\",\"28\"]', 50000, 39000, 'completed', 2, 42),
(43, 'Parent\'s Anniversary', '2020-12-17', '21:00:00', 'Cuto and Balina', '2020-10-01 01:04:41', '[\"1\",\"2\",\"4\",\"5\",\"6\",\"10\"]', '[\"2\",\"5\",\"11\",\"14\",\"18\",\"28\"]', 200000, 158000, 'declined', 2, 42),
(44, 'Annual Sport Meet', '2020-12-19', '09:00:00', 'Varun Sen And Academy', '2020-10-01 01:08:31', '[\"2\",\"4\",\"6\",\"8\",\"11\"]', '[\"6\",\"10\",\"17\",\"22\",\"33\"]', 305500, 249500, 'completed', 4, 52),
(45, 'Smita\'s Birthday', '2021-01-13', '17:30:00', 'Smita Seth', '2020-10-01 01:11:58', '[\"2\",\"4\",\"5\",\"6\",\"10\"]', '[\"4\",\"11\",\"13\",\"17\",\"29\"]', 100000, 84500, 'uncompleted', 2, 52),
(46, 'Pai\'s Funeral', '2020-12-16', '18:00:00', 'Pai Sen', '2020-10-01 01:14:32', '[\"2\",\"3\",\"9\"]', '[\"4\",\"7\",\"25\"]', 20000, 21000, 'uncompleted', 3, 49),
(47, 'Parent\'s Anniversary', '2020-12-19', '19:00:00', 'Nina and Vasudev', '2020-10-01 01:16:03', '[\"2\",\"4\",\"5\",\"10\"]', '[\"4\",\"10\",\"13\",\"28\"]', 25500, 19500, 'uncompleted', 2, 49),
(49, 'Shakti\'s Wedding', '2020-11-30', '18:30:00', 'Shakti and Priya', '2020-11-28 00:41:32', '[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\",\"9\",\"10\",\"11\"]', '[\"2\",\"5\",\"9\",\"12\",\"15\",\"16\",\"19\",\"36\",\"25\",\"29\",\"31\"]', 295000, 226000, 'uncompleted', 1, 35);

-- --------------------------------------------------------

--
-- Table structure for table `event_types`
--

CREATE TABLE `event_types` (
  `etype_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `img_path` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `event_types`
--

INSERT INTO `event_types` (`etype_id`, `name`, `img_path`) VALUES
(1, 'Wedding', 'wedding.jpg'),
(2, 'Birthday or Anniversary', 'birthdayOrAnniversary.jpg'),
(3, 'Funeral', 'funeral.jpg'),
(4, 'Award or Company Events', 'companyOrAwardEvent.jpg'),
(5, 'Bachelor Party', 'bachelorParty.jpg'),
(6, 'Other', 'other.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `exquisite_packages`
--

CREATE TABLE `exquisite_packages` (
  `exquisite_pkg_id` int(11) NOT NULL,
  `pd_id_array` text DEFAULT NULL,
  `pkg_price_customer` int(11) DEFAULT NULL,
  `pkg_price_admin` int(11) DEFAULT NULL,
  `exquisite_pkg_etype_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pd_id` int(11) NOT NULL,
  `pd_name` varchar(255) NOT NULL,
  `price_customer` int(11) NOT NULL,
  `price_admin` int(11) NOT NULL,
  `pd_sp_id` int(11) NOT NULL,
  `pd_stype_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pd_id`, `pd_name`, `price_customer`, `price_admin`, `pd_sp_id`, `pd_stype_id`) VALUES
(1, '5 Acre Farmhouse', 25000, 20000, 1, 1),
(2, 'Banquet Hall', 15000, 10000, 2, 1),
(3, 'Durga Banquet', 10000, 7500, 3, 1),
(4, 'Bajaj Annapurnam', 5000, 3000, 4, 2),
(5, '5 Star Pack', 50000, 40000, 5, 2),
(6, 'Best Price Food', 100000, 75000, 6, 2),
(7, 'All Hindu Smarta', 5000, 3000, 7, 3),
(8, 'Sharma Pandit Vale', 8000, 5000, 8, 3),
(9, 'Advaita Rituals', 10000, 7500, 9, 3),
(10, 'Flowers Paradise', 5500, 4500, 10, 4),
(11, 'Looks Matter', 15000, 12000, 11, 4),
(12, 'Pretty Decor', 30000, 28000, 12, 4),
(13, 'DJ All Night', 10000, 8000, 13, 5),
(14, 'Party Music', 15000, 12000, 14, 5),
(15, 'Dance and DJ', 25000, 20000, 15, 5),
(16, 'Best Photos', 50000, 40000, 16, 6),
(17, 'Dera Videos & Filming', 60000, 55000, 17, 6),
(18, 'Delhi Event Videos', 100000, 80000, 18, 6),
(19, 'Carry All', 5000, 4000, 19, 7),
(20, 'Lets Travel', 8000, 7000, 20, 7),
(21, 'Drive It', 15000, 12500, 21, 7),
(22, 'Especial Gifts', 20000, 15000, 22, 8),
(23, 'Jewellery and Gifts ', 30000, 25000, 23, 8),
(24, 'Guest Gift Items', 50000, 40000, 24, 8),
(25, 'Let\'s Invite', 10000, 15000, 25, 9),
(26, 'Invi To All', 23000, 20000, 26, 9),
(27, 'Auspicious Invite', 50000, 40000, 27, 9),
(28, '5 star Cakes', 5000, 4000, 28, 10),
(29, 'Best Event Cake', 10000, 6500, 29, 10),
(30, 'Bakery Items', 15000, 13500, 30, 10),
(31, 'Stars and Entertainers', 50000, 30000, 31, 11),
(32, 'Anchors and Pop Stars', 100000, 75000, 32, 11),
(33, 'Entertainers and Laughs', 120000, 100000, 33, 11),
(36, 'Gifts with Grace', 40000, 25000, 38, 8),
(42, 'Khoobsurat Nikah', 5000, 5000, 35, 3),
(43, 'Shaan-e-Bahaar', 10000, 8600, 34, 4),
(45, 'Nikahnama', 5000, 4500, 39, 3);

-- --------------------------------------------------------

--
-- Table structure for table `product_details`
--

CREATE TABLE `product_details` (
  `pd_details_id` int(11) NOT NULL,
  `pd_feature1` text NOT NULL,
  `pd_feature2` text DEFAULT NULL,
  `pd_feature3` text DEFAULT NULL,
  `pd_feature4` text DEFAULT NULL,
  `pd_feature5` text DEFAULT NULL,
  `pd_img_path` text NOT NULL DEFAULT 'noImageAvailable.png',
  `pdetails_pd_id` int(11) NOT NULL,
  `pdetails_sp_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_details`
--

INSERT INTO `product_details` (`pd_details_id`, `pd_feature1`, `pd_feature2`, `pd_feature3`, `pd_feature4`, `pd_feature5`, `pd_img_path`, `pdetails_pd_id`, `pdetails_sp_id`) VALUES
(1, 'Fully Air Conditioned Rooms', 'Spacious Changing Rooms', 'Exclusive lawn & garden', 'Three Storey Building', 'Private Swimming Pool', 'pd_id_1.jpg', 1, 1),
(2, 'Spacious Banquet Hall', 'Enough for 200 people', 'Bar For Cocktails', 'Exclusive guest rooms', 'Modern Toilets', 'pd_id_2.jpg', 2, 2),
(3, '500 People Capacity', 'Exclusive Lawn Area', 'Licensed Bar Section', 'Hoisted Stage', 'Special Dining hall', 'pd_id_3.jpg', 3, 3),
(4, 'max. 100 Plates', '2 Course Meal', '15 Dishes', 'Hygienic and Safe', NULL, 'pd_id_4.jpg', 4, 4),
(5, 'max. 250 plates', '20 dishes', 'International Chefs & waiters', 'Completely Safe and Organic', 'made with love', 'pd_id_5.jpg', 5, 5),
(6, 'max. 500 plates', 'Best Indian Chefs', 'Certified Organic Ingredients', 'Dissatisfaction Refund Policy', NULL, 'pd_id_6.jpg', 6, 6),
(7, 'All Samagri Included', 'Completely Cashless', 'Best Vedic Scholars', 'No Hidden Fees', NULL, 'pd_id_7.jpg', 7, 7),
(8, 'Samagri Ingredients included', 'Certified Vedic Practitioners', 'Best in class Sanskrit Chants', 'ISKCON Supported', 'Timely Execution', 'pd_id_8.jpg', 8, 8),
(9, 'Samagri Included', 'No Hidden Cost', 'Best in class Mantra Recitation', 'No Superstions', 'Logical Explanation of each ritual', 'pd_id_9.jpg', 9, 9),
(10, 'All Event Covered', 'Imported Flowers Decoration', 'Best in Class Styling', NULL, NULL, 'pd_id_10.jpg', 10, 10),
(11, 'Best In Industry', 'Chandelier and Other Items included', 'Best Flowers', 'Gold Themed Designs', NULL, 'pd_id_11.jpg', 11, 11),
(12, 'All Event Area Covered', 'Gold and Royal Design theme', 'Best in class designers', 'Certified Proffessionals', 'Best In class Experience', 'pd_id_12.jpg', 12, 12),
(13, 'Certified Professional DJs', 'Best In Class Music', 'All Party 300 Capacity Dance Floor', 'DJ Ball', NULL, 'pd_id_13.jpg', 13, 13),
(14, 'Best Performance artists', 'Best In Class Musicians', 'Big Modern Speakers', 'Professional DJs', 'Pop Music On Demand', 'pd_id_14.jpg', 14, 14),
(15, 'Modern Sony Boofers', 'All Night non-stop DJs', 'Best In Industry EDM ', 'Famous Pop Stars & Icons Available', 'Best DJ Floor', 'pd_id_15.jpg', 15, 15),
(16, 'Full Event Videography', 'Best In Class Quality', 'Complete Photo Album with Latest Trends', 'Best Professional Photographers', NULL, 'pd_id_16.jpg', 16, 16),
(17, 'Best Professional Cameramen', 'Best In class Video Equipments\r\n', 'Complete Album and Video Film', 'Complete Event Covered: Ist to Last', 'No Timing Issues', 'pd_id_17.jpg', 17, 17),
(18, 'Best In Class Professionals', 'High Tech Digital Cameras and Drones', 'Best Capturing Practices', 'Full Event Coverage including live screens', 'Free Editing and Consultation', 'pd_id_18.jpg', 18, 18),
(19, 'max 100 passengers', 'All time availability', 'Best in class vehicles', 'Clean and Safe ', NULL, 'pd_id_19.jpg', 19, 19),
(20, 'max. 200 passengers', 'A.C. Vehicles', 'Safety and Hygiene Consious', 'Seperate Cabins in Buses', NULL, 'pd_id_20.jpg', 20, 20),
(21, 'max. 500 passengers', 'A.C. Vehicles', 'Travel Insurance for passengers ', 'High Safety and Hygiene Standards', '10+ Years Experienced Drivers', 'pd_id_21.jpg', 21, 21),
(22, 'max. 100 person covered', 'Gifts Decided by You', 'Exclusively made by us', 'Personalized Messages for each guest', NULL, 'pd_id_22.jpg', 22, 22),
(23, 'max. 250 person covered', 'personalized messages with gifts', 'packing and gift designed by you', 'Extremely Rare Gifts', 'Crafted by professionals', 'pd_id_23.jpg', 23, 23),
(24, 'max. 500 person covered', 'Personalized Messages', 'Well crafted by industry experts', 'Gift Warranties Included', 'Designed by You', 'pd_id_24.jpg', 24, 24),
(25, 'max. 100 person covered', 'Best In Class Designs', 'New Trending Ideas', 'paperback + hardbase', 'Best for Casual Invites', 'pd_id_25.jpg', 25, 25),
(26, 'max. 250 people covered', 'exclusive handmade designs', 'Well Crafted handmade paper', 'Includes Digital Invitation', 'Certified Professionals', 'pd_id_26.jpg', 26, 26),
(27, 'max. 500 people covered', 'Exclusive Handwritten personalized messages', 'Based on Design Thinking and Visual Art', 'Includes Complete Digital Invitation Package', 'Top Industry Professionals', 'pd_id_27.jpg', 27, 27),
(28, '5 Kg Cake', 'Best Eggless Chocolate Cake ', 'Hygienic and Nutritious', 'Freshly Baked', NULL, 'pd_id_28.jpg', 28, 28),
(29, '7.5 Kg Chocolate Cake', 'Loaded with melted chocolate filling ', '100% Vegan , No Preservatives', 'Customized Designs', 'Freshly Baked, No Storing', 'pd_id_29.jpg', 29, 29),
(30, '10 kg any event cake', 'Atleast 3 stages tall', 'customized design and flavouring', '100% Vegan Option available', 'No Preservatives, No Food Colouring', 'pd_id_30.jpg', 30, 30),
(31, 'Industry Top Artists & Performers', 'Best In Class Stage Equipments', 'Added Anchoring Mentoring if required', 'Best Stage Setup and Workers', NULL, 'pd_id_31.jpg', 31, 31),
(32, 'Tie Up with Bollywood Stars and Singers', 'Added Public Speaking Mentoring for Customer', 'No Nonsense Event Content', 'Pure Entertainment Guaranteed', 'Clear Refund Policy', 'pd_id_32.jpg', 32, 32),
(33, 'Top Artists and Performers', 'Exclusive in person interaction of family members with celebrities ', 'Clear Refund Policy', 'Best In Class Planning and Management', 'Added Mentoring and Training for Customer\'s On stage Fears', 'pd_id_33.jpg', 33, 33),
(36, 'Best Mid-Range Gifts for your guests', 'Personalised Choices Available', 'Optimum for mid-size (200 persons) event', NULL, NULL, 'pd_id_36.jpg', 36, 38),
(41, 'All Religious Rituals', 'Reasonable Mehar', 'Timely Completion', 'No Hidden Charges', NULL, 'pd_id_42.jpg', 42, 35),
(42, 'Artistic Golden Decoration', 'Reasonable Pricing', 'Cultural and Symbolic', 'Skilled Artisans', NULL, 'noImageAvailable.png', 43, 34),
(44, 'All Religious Rituals', 'Appropriate Mehar', NULL, NULL, NULL, 'noImageAvailable.png', 45, 39);

-- --------------------------------------------------------

--
-- Table structure for table `service_providers`
--

CREATE TABLE `service_providers` (
  `sp_id` int(11) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mob_1` varchar(255) NOT NULL,
  `mob_2` varchar(255) DEFAULT NULL,
  `sp_stype_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service_providers`
--

INSERT INTO `service_providers` (`sp_id`, `company_name`, `name`, `email`, `mob_1`, `mob_2`, `sp_stype_id`) VALUES
(1, 'Kalicharan Venues', 'Kalicharan Gupta', 'kalicharan@gmail.com', '5674345621', NULL, 1),
(2, 'Aggarwal Farmhouses', 'Deepak Aggarwal', NULL, '4532414322', NULL, 1),
(3, 'Durga MarriageHalls', 'Narayan Dixit', 'dixit4532@gmail.com', '9878675467', NULL, 1),
(4, 'Bajaj Caterers', 'Sheela Bajaj', 'narayanbajaj@gmail.com', '7898765667', '9878987654', 2),
(5, '5 Star Services', 'Punit Singh', 'singh564@gmail.com', '9876786767', NULL, 2),
(6, 'Vibhu Foods', 'Vibhu Saini', 'vibhu675@gmail.com', '8976546123', NULL, 2),
(7, 'All_Brahmins Corp.', 'Shyam Mishra', 'mishrabrothers@gmail.com', '8978675643', NULL, 3),
(8, 'SharmaJi_Ceremonial_Services', 'Vishwa Narayan Sharma', NULL, '8978665431', '7765453421', 3),
(9, 'Vedic Scholars', 'Ramprasad Hari', 'hariVedicScholars@gmail.com', '8978675567', '7867564532', 3),
(10, 'Vibhuti Flourist', 'Vibhuti Shakya', 'shakyaVibhuti@gmail.com', '9878675645', '7867564589', 4),
(11, 'Event Decorations', 'Shoaib Bakshi', 'bakshiHanuman@gmail.com', '9878675643', NULL, 4),
(12, 'Hema Pandey Prettier', 'Hema Pandey', 'padeyHema@gmail.com', '9878675645', NULL, 4),
(13, 'Amavasya DJs', 'Atul Dinesh', 'dinesh231@gmail.com', '9878688765', '8978675645', 5),
(14, 'Varun Music Opera', 'Varun Pruthi', 'pruthiseth@gmail.com', '8978675645', '7867564534', 5),
(15, 'Hariom Dance Corp.', 'Jaichand Hare', 'jaichand@gmail.com', '9878675678', '8978675678', 5),
(16, 'Dulhan Photos', 'Maria Abraham', 'abrahamcoly@gmail.com', '9878675645', NULL, 6),
(17, 'Dera Videos & Functions', 'Swamipreet Kaur', 'swamipreetdera@gmail.com', '9876567676', '9878675645', 6),
(18, 'Camera & Lights Delhi', 'Munendra Bhardwaj', 'bhardwaj@gmail.com', '9876567654', '9878675645', 6),
(19, 'Bharti Travellers', 'Hinesha Bharti', 'bhartiHinesha@gmail.com', '9878675645', NULL, 7),
(20, 'Borona Roadways', 'Bella Fernandiz', 'bellaFernandiz@gmail.com', '7867564534', '9878675645', 7),
(21, 'Hisar Logistics', 'Bhairavi Kumari', 'kumaribhairavi@gmail.com', '8978675645', '7867564534', 7),
(22, 'Vanshit Toys', 'Vaishali Gupta', 'vaishali@gmail.com', '8978675645', NULL, 8),
(23, 'Bhima Awards & Jewellry', 'Akshit Dhiman', 'varunAkshitDhiman@gmail.com', '8978675645', '5645342312', 8),
(24, 'Moksha Nirupam Products', 'Mahesh Nirupam', 'maheshnirupam@gmail.com', '8978675645', NULL, 8),
(25, 'Jaina Cards', 'Sambhav Jain', 'sambhavjain@gmail.com', '8978675645', NULL, 9),
(26, 'Vashist Wedding Invitations', 'Vinayak Vashista', 'vinayakvashistha@gmail.com', '8976564534', NULL, 9),
(27, 'Vashita Planners', 'Marpu Ihita', 'marpuihita@gmail.com', '9878564534', NULL, 9),
(28, '5 Star Bakers', 'Arundhiti Deshmukh', 'arundhiti@gmail.com', '7867564534', '7867564534', 10),
(29, 'Shiya Moka Confectionery', 'Shiya Gurkha', 'shiyagurkha@gmail.com', '7867564534', NULL, 10),
(30, 'Bakers &amp; Others', 'Veerappan Bahadur', 'veerapanBahadur@gmail.com', '8978675645', '8978675645', 10),
(31, 'Ahuja Media & Services ', 'Aparna Ahuja', 'aparna@gmail.com', '9878453423', NULL, 11),
(32, 'Vera Advertising And Anchors', 'Suchita Tyagi', 'suchita@gmail.com', '8978675645', NULL, 11),
(33, 'Om Actors & Entertainment', 'Aarushi Jain', 'aarushi342@gmail.com', '7867675645', '8978675645', 11),
(34, 'Barista Decors &amp; Designers', 'Balkha Sen', 'balkhasendesigns@gmail.com', '6735353556', NULL, 4),
(35, 'Mustafa Nikah Essentials', 'Masood Ulema', 'mustafa.nikah@gmail.com', '7656745345', '8978654535', 3),
(38, 'Kristine Jewels and Gems', 'Rekha Subartha', 'rekha.subartha56@gmail.com', '7865544564', NULL, 8),
(39, 'Ansari Albarriduin Maulvis', 'Akbar Aalam', 'ansarimaulvis23@gmail.com', '6789564536', NULL, 3);

-- --------------------------------------------------------

--
-- Table structure for table `service_providers_addresses`
--

CREATE TABLE `service_providers_addresses` (
  `sp_addr_id` int(11) NOT NULL,
  `office_no` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) NOT NULL DEFAULT 'India',
  `sp_addr_sp_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service_providers_addresses`
--

INSERT INTO `service_providers_addresses` (`sp_addr_id`, `office_no`, `street`, `city`, `pincode`, `state`, `country`, `sp_addr_sp_id`) VALUES
(1, 'H-342', 'Laxminagar Town', 'Delhi', '678564', 'Delhi', 'India', 1),
(2, '78-HBFG', 'Knowledge Park 3', 'Greater Noida', '789675', 'Uttar Pradesh', 'India', 2),
(3, '78-KJUI', 'Vyasnagar Colony', 'Gurugram', '786787', 'Haryana', 'India', 10),
(4, '89-C', 'Varshita Industrial Area ', 'Delhi', '897867', 'Delhi', 'India', 3),
(5, '9-08Y', 'New City Industrial Complex', 'Faridabad', '786765', 'Uttar Pradesh', 'India', 4),
(6, '78YHG', 'Bakshis Industrial Complex', 'Gaziabad', '897675', 'Uttar Pradesh', 'India', 5),
(7, '786YT', 'Varshi Dekshi Colony', 'Greater Noida', '897675', 'Uttar Pradesh', 'India', 6),
(8, '67', 'Worli Siyaram Complex', 'Noida', '786567', 'Uttar Pradesh', 'India', 7),
(9, '897675', 'Gondwana Complex', 'Greater Noida', '786564', 'Uttar Pradesh', 'India', 8),
(10, 'c-89', 'JagatFarm', 'Greater Noida', '786567', 'Uttar Pradesh', 'India', 9),
(12, 'B-180', 'Varsheti Puram Mall', 'Gurugram', '786765', 'Haryana', 'India', 11),
(13, '789-BH', 'Gururam Nagar', 'Ghaziabad', '897897', 'Uttar Pradesh', 'India', 12),
(14, '897-Y', 'Varuna Pradesh', 'Noida', '789789', 'Uttar Pradesh', 'India', 13),
(15, 'B-908', 'Veerappan', 'Saharanpur', '247001', 'Uttar Pradesh', 'India', 14),
(16, 'B-908', 'Worli Era Complex', 'Saharanpur', '247001', 'Uttar Pradesh', 'India', 15),
(17, '897', 'Avaas Vikas Colony', 'Greater Noida', '786787', 'Uttar Pradesh', 'India', 16),
(18, '987-89', 'Kalicharan Marg Road', 'Seemapur', '897686', 'Delhi', 'India', 17),
(19, '9087', 'Cersda Complex', 'New Delhi', '786567', 'Delhi', 'India', 18),
(20, '89-H', 'Worli Nagar Marathwada', 'Panchkula', '897678', 'Haryana', 'India', 19),
(21, '98-JI', 'Mohali Nagar', 'Chandigarh', '897865', 'Chandigarh', 'India', 20),
(22, '89-H', 'Laxmanpuram Colony', 'saharanpur', '876541', 'Uttar Pradesh', 'India', 21),
(23, '878-H', 'Bakshis Nagar', 'Panchkula', '897675', 'Haryana', 'India', 22),
(24, '87-C', 'Vishishtha Puram Nagar', 'Ghaziabad', '897678', 'Uttar Pradesh', 'India', 23),
(25, '89-C', 'Moksha Fram Market', 'Greater Noida', '678564', 'Uttar Pradesh', 'India', 24),
(26, 'c-908', 'Hyena Ali Marg', 'Moradabad', '897865', 'Uttar Pradesh', 'India', 25),
(27, '67-C', 'Gurdaspur Hariom Tower', 'Gurdaspur', '765436', 'Punjab', 'India', 26),
(28, '786', 'Area 5123', 'Noida', '786543', 'Uttar Pradesh', 'India', 27),
(29, '987-C', 'Mayapur Harishwar Nagar', 'Kashi', '675453', 'Uttar Pradesh', 'India', 28),
(30, '897-VB', 'Alien Nagar', 'Sahibabad', '765454', 'Uttar Pradesh', 'India', 29),
(31, '7865-VG', 'Verana Bundiya Kheda', 'Aligarh', '876660', 'Uttar Pradesh', 'India', 30),
(32, '765-CV', 'Worli South', 'Mumbai', '786564', 'Maharashtra', 'India', 31),
(33, '86-CGH', 'Mahateerth Nagar', 'Pune', '897656', 'Maharashtra', 'India', 32),
(34, '98-C6', 'Malviya Nagar, Jaggu Complex', 'New Delhi', '897678', 'Delhi', 'India', 33),
(35, 'Shop-456, Pacificadium Mall', 'Shivpuri Road', 'Delhi', '675467', 'Delhi', 'India', 34),
(36, NULL, NULL, NULL, NULL, NULL, 'India', 35),
(39, '78-C', 'Puneet Nagar', 'Gurugram', '675421', 'Haryana', 'India', 38),
(40, 'Mosque Fatehi', 'Begu Sheikh Road', 'Noida', '567786', 'Uttar Pradesh', 'India', 39);

-- --------------------------------------------------------

--
-- Table structure for table `service_types`
--

CREATE TABLE `service_types` (
  `stype_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service_types`
--

INSERT INTO `service_types` (`stype_id`, `name`) VALUES
(1, 'Venue'),
(2, 'Catering'),
(3, 'Rituals & Priest'),
(4, 'Decoration'),
(5, 'Music & Dance'),
(6, 'Camera & Videography'),
(7, 'Transportation'),
(8, 'Gifts & Awards'),
(9, 'Invitations'),
(10, 'Cakes & Bakers'),
(11, 'Anchoring & Entertainment');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pwd` text NOT NULL,
  `mob_1` varchar(255) DEFAULT NULL,
  `mob_2` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'allowed',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `pwd`, `mob_1`, `mob_2`, `status`, `created_at`) VALUES
(35, 'Anant Saini', 'anantsaini.india@gmail.com', '$2y$10$8eznTPXMNVwjp.aJRSoPS.CPkBXU9UiplZsnaNBkqXHwyU3lBzvCa', '9667925115', NULL, 'allowed', '2020-08-03 01:34:00'),
(37, 'Aadya Saini', 'aadyasaini@gmail.com', '$2y$10$K.3Wbklcri4avzae2eQWW.YhCiQLWyooVF3jEK409roiYOpzSP0.q', '8445406117', '9786543123', 'allowed', '2020-09-17 22:07:55'),
(38, 'Nitin Pundir', 'nitinpundir@gmail.com', '$2y$10$ovFNbN2ZvLVrvempjWBt4O8A6hC848SsHw0/joceuCS4XmqDtXCt.', '7654356786', '8532356765', 'allowed', '2020-09-17 22:30:22'),
(39, 'Diksha Pundir', 'dikshapundir@gmail.com', '$2y$10$rHlua0M6pwZNZpAyQWq2XuIJwszpYylrZSzfYbPRhYF9vnI69UoHO', '9876786544', '8765786543', 'allowed', '2020-09-17 22:35:51'),
(40, 'Hitanshu Saini', 'hitanshusaini@gmail.com', '$2y$10$fHm8qijhuzL034/uF1Q2y.ryldNhUYdGfn5EIcqWzYql1waPnMqJK', '7897654567', '8987656785', 'allowed', '2020-09-17 22:41:39'),
(41, 'Aman Verma', 'amanverma@gmail.com', '$2y$10$VFyJFg0h5ickCOd93kN/SeTcZCqKb7FXf9spz7bdx1nEHxX0RN0tS', '6754356788', '9876556654', 'allowed', '2020-09-17 22:46:30'),
(42, 'Atul Yadav', 'atulyadav@gmail.com', '$2y$10$Jf0i7SnAYZj/JxKYvmXYuObzasn/Ezn4AcWB68zZzkbA1ADvHGPpe', '9876789656', '6765477865', 'allowed', '2020-09-17 22:51:11'),
(43, 'Sambhav Jain', 'sambhavjain@gmail.com', '$2y$10$tbKSV1hNQXjP3hFM1bdxIOTv6OH7FxPnbe5MytbZxPT4waVRHI.La', '7689765456', '8435678763', 'allowed', '2020-09-17 23:11:41'),
(44, 'Shweta Pandita', 'shwetapandita@gmail.com', '$2y$10$z0TYS.HClcxcAwrQWaAhVexFuShzd8.HuKpUnJp8Xt7kDuSn4jAfq', '6754324551', '9837736266', 'allowed', '2020-09-18 18:18:00'),
(45, 'Aman Garg', 'amangarg@gmail.com', '$2y$10$CQMUi6pwdNKevvufaPdbZu1TtKt5TsowURMBUjqCUkFpKJ1vqHwze', NULL, NULL, 'allowed', '2020-09-21 23:00:08'),
(46, 'Rahul Sen', 'rahulsen@gmail.com', '$2y$10$OzZVJfYHbcmG5YRn1XAnm.PeCWH7gaFtFanym6M1ud078EPrLP20a', NULL, NULL, 'allowed', '2020-09-21 23:00:39'),
(47, 'Rahul Negi', 'rahulnegi@gmail.com', '$2y$10$/XxMrvw68E1gSu5NhGKTsuWr2rBIZDfU2vtbjehzjhuixeP5Q1N6e', NULL, NULL, 'allowed', '2020-09-21 23:01:12'),
(48, 'Veena Saini', 'veenasaini@gmail.com', '$2y$10$xGtfFJI/HUMiTYOUfxXL4eGtU/hC2Rswh3jIz2IOO1413K7Vc.eyi', NULL, NULL, 'allowed', '2020-09-21 23:01:46'),
(49, 'Manoj Rastogi', 'manojrastogi@gmail.com', '$2y$10$8CuhhL7LMao4N9fCHf/op.g.qdHjeClc4NHyt8cCjzosTFFgwpUIa', '8364422267', '8748939929', 'allowed', '2020-09-21 23:02:22'),
(50, 'Bukhul Buali', 'bukhulbuali@gmail.com', '$2y$10$7eWMP5TDi31.JuOOmz5Fte3rDtUtjoSGsbb.IRSaNswVDJmDgC6.u', NULL, NULL, 'allowed', '2020-09-21 23:03:36'),
(51, 'Banti Verma', 'bantiverma@gmail.com', '$2y$10$FVmUMR5w3uIYFhhQqtxTk.LD.A9yTwHxDJ0D2AtrF8s5QrJiW/66C', NULL, NULL, 'allowed', '2020-09-21 23:04:19'),
(52, 'Smita Seth', 'smitaseth@gmail.com', '$2y$10$/6O6LlMmzXJtv9e9Q71e1O1FAkxrN1XlbYrMdCgtZlBbgvB8.fnHG', '6735342425', '5453632728', 'allowed', '2020-09-21 23:04:59'),
(53, 'Amartya Sen', 'amartyasen@gmail.com', '$2y$10$7x8tTNbqU3hRqZtpqlUX..wJ7aU4I6leS3mohqONU.u/tVydiPBM6', NULL, NULL, 'allowed', '2020-09-21 23:06:00'),
(54, 'Vaishnavi Verma', 'vaishnaviverma@gmail.com', '$2y$10$d6AlDXbcdKw47dWjBG86JeEi7RzW1oav6sXlRKE1WLY/2r6RVOh4e', NULL, NULL, 'allowed', '2020-09-21 23:06:53'),
(55, 'Bagula Seth', 'bagulaseth@gmail.com', '$2y$10$ZAXmaJQkYwbYZgcQw9LRw./8rvpQptddz5.Oxhj6.aaRmsvcoQJmi', NULL, NULL, 'allowed', '2020-09-21 23:07:20'),
(56, 'Alia Bhatt', 'aliabhatt@gmail.com', '$2y$10$hLZgqx9zqdERsKCJAXukLewcskUYKImRgI3XqD9AhOp0ABb26hPOm', NULL, NULL, 'allowed', '2020-09-21 23:07:48'),
(57, 'Varun Dhawan', 'varundhawan@gmail.com', '$2y$10$DsrpWsEB5D4mk2h72xefcOt9aZTF0bzbkUgLO9hMnC4K5FgMQkeme', NULL, NULL, 'allowed', '2020-09-21 23:08:45'),
(58, 'Tiger Shroff', 'tigershroff@gmail.com', '$2y$10$d1fNnIMzh.O/p4ekteor.emM0w7nmgnf2BKzKPqUVrYjp.eoF84QK', NULL, NULL, 'allowed', '2020-09-21 23:09:16'),
(59, 'Deepika Padukone', 'deepikapadukone@gmail.com', '$2y$10$l696ZT5Shhn1vQccl3jnr.c49UMx/dV2l2dXoQ8X6rrhro.lo/P/G', NULL, NULL, 'allowed', '2020-09-21 23:10:07'),
(60, 'Ranbir Kapoor', 'ranbirkapoor@gmail.com', '$2y$10$pP1XxhzLRp4CQFZ.yMkoIu/c64P8ujotoX4g.KQEOKNUAnsubMLvS', NULL, NULL, 'allowed', '2020-09-21 23:10:55'),
(61, 'Ranvir Singh', 'ranvirsingh@gmail.com', '$2y$10$weqJ8eFhALZvqwaPWzFuv.7NHGOU2.Dh/PtEDhrCjEAE.LXqX5DTm', NULL, NULL, 'allowed', '2020-09-21 23:11:37'),
(62, 'Shahid Kapoor', 'shahidkapoor@gmail.com', '$2y$10$K5sFu.srTRkkh9yxT5wy/.EdLhaAdseqH2DJrT9n/2z4Nfcrhr61G', NULL, NULL, 'allowed', '2020-09-21 23:15:09'),
(63, 'Meena Jaiswal', 'meenajaiswal@gmail.com', '$2y$10$AXf.8iVeIka4v2oka9KkSuur53JwMvrOXoKFctilkvRS0NOgFnX4W', NULL, NULL, 'allowed', '2020-09-21 23:15:46'),
(64, 'Irfan Khan', 'irfankhan@gmail.com', '$2y$10$Dk1PzXUHi4Q.WRTEKK1y8eCjESxsP7Zracg5tv8EyDyplFjGWqoIq', NULL, NULL, 'allowed', '2020-09-21 23:16:37'),
(65, 'Baby Singh', 'babysingh@gmail.com', '$2y$10$atffUTQgmCvot.RdVOhUC..kob41eJYecinXdCpk06awQ6H7.QpAi', NULL, NULL, 'allowed', '2020-09-21 23:17:19'),
(66, 'Shree Goel', 'shreegoel@gmail.com', '$2y$10$yHc5.Ho6U49QvlK/UOaOpuNu3qETzpDJRe52TH6X75OTFsr7yd/ga', NULL, NULL, 'allowed', '2020-09-21 23:17:57'),
(67, 'Bablu Saini', 'bablusaini@gmail.com', '$2y$10$L.u6ilrJn8V5FAsZAJp/NeIKnDF1MGqjt2HoC5NeQXhAwxkG4Yd0i', NULL, NULL, 'allowed', '2020-09-21 23:18:29'),
(68, 'Vedansh Vats', 'vedanshvats@gmail.com', '$2y$10$Fus/o6NpE63M5m8AUR8z/u1LNzDXJPON1dMF8F3LdxkZ/0knrR9fm', NULL, NULL, 'allowed', '2020-09-21 23:19:02'),
(69, 'Bossy Dev', 'bossydev@gmail.com', '$2y$10$vuSKPkw0ix6YnTtLNw5h8uw279bpP5TIBPnRkjaOKieV0PjEkMTXS', NULL, NULL, 'allowed', '2020-09-21 23:19:28'),
(70, 'Shikshita Seth', 'shikshitaseth@gmail.com', '$2y$10$wjuzQ.fZxt96erF2vBuciucvm1LEvNuYBBUdcMVUvAMm3g6qLU93.', NULL, NULL, 'allowed', '2020-09-21 23:20:08'),
(71, 'Bilhaal Singh', 'bilhaalsingh@gmail.com', '$2y$10$9.igwjTaY4/rwNXJ0Q49TOiPCCeX/Q4x6n86BVVi0Golm.J5eTyXa', NULL, NULL, 'allowed', '2020-09-21 23:20:42'),
(72, 'Puttar Lekhpal', 'puttarlekhpal@gmail.com', '$2y$10$yAxZ4canLMmZMvJaAht/duJqhJajzb0xXMHV4o4qLPd9ONlH4U/jS', NULL, NULL, 'allowed', '2020-09-21 23:21:28'),
(73, 'Vikrant Messy', 'vikrantmessy@gmail.com', '$2y$10$0RhcB7Yy0Q0VbgtVinCXvepeT3uMEtFpHp1lA/kTHEmD9YHU2Gdc6', NULL, NULL, 'allowed', '2020-09-21 23:22:03'),
(74, 'Prajakta Singh', 'prajaktasingh@gmail.com', '$2y$10$Upqgmz7V28NMbWjnWbKU.efSBBnuKXg7ES/LE2i1AvtOmxfAEnDOS', NULL, NULL, 'allowed', '2020-09-21 23:22:39'),
(75, 'Matsya Singh', 'matsyasingh@gmail.com', '$2y$10$795p0x5a18JbsuGaSRwhE.kTi8i8RZlC9tnp7NGSb1P5KqMx9GYn.', NULL, NULL, 'allowed', '2020-09-21 23:23:18'),
(76, 'Rekha Sharma', 'rekhasharma@gmail.com', '$2y$10$2.J.KxCANqStC9lzj7yC6.MesEXtL8Rk34rIzCt.iMFYxynPoRliS', NULL, NULL, 'allowed', '2020-09-21 23:24:08'),
(77, 'Waver Sujit', 'waversujit@gmail.com', '$2y$10$uTnPSAlEZazDUywM2gOWe.K519OJ2xa9yok6nn5og8K7OLAR5sJoe', NULL, NULL, 'allowed', '2020-09-21 23:24:38');

-- --------------------------------------------------------

--
-- Table structure for table `user_addresses`
--

CREATE TABLE `user_addresses` (
  `user_addr_id` int(11) NOT NULL,
  `house_no` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) NOT NULL DEFAULT 'India',
  `landmark` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_addresses`
--

INSERT INTO `user_addresses` (`user_addr_id`, `house_no`, `street`, `city`, `state`, `country`, `landmark`, `pincode`, `user_id`) VALUES
(11, 'B-4', 'Laxmanpuram Colony', 'Saharanpur', 'Uttar Pradesh', 'India', 'T.P. Nagar', '247001', 35),
(13, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 37),
(14, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 38),
(15, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 39),
(16, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 40),
(17, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 41),
(18, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 42),
(19, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 43),
(20, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 44),
(21, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 45),
(22, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 46),
(23, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 47),
(24, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 48),
(25, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 49),
(26, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 50),
(27, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 51),
(28, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 52),
(29, 'AB-767', 'MurliVilas Flats', 'Pune', 'Maharashtra', 'India', 'Gokul Nagar', '564277', 53),
(30, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 54),
(31, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 55),
(32, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 56),
(33, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 57),
(34, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 58),
(35, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 59),
(36, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 60),
(37, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 61),
(38, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 62),
(39, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 63),
(40, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 64),
(41, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 65),
(42, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 66),
(43, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 67),
(44, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 68),
(45, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 69),
(46, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 70),
(47, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 71),
(48, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 72),
(49, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 73),
(50, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 74),
(51, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 75),
(52, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 76),
(53, NULL, NULL, NULL, NULL, 'India', NULL, NULL, 77);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `basic_packages`
--
ALTER TABLE `basic_packages`
  ADD PRIMARY KEY (`basic_pkg_id`),
  ADD UNIQUE KEY `basic_pkg_etype_id` (`basic_pkg_etype_id`);

--
-- Indexes for table `classic_packages`
--
ALTER TABLE `classic_packages`
  ADD PRIMARY KEY (`classic_pkg_id`),
  ADD UNIQUE KEY `classic_pkg_etype_id` (`classic_pkg_etype_id`);

--
-- Indexes for table `event_orders`
--
ALTER TABLE `event_orders`
  ADD PRIMARY KEY (`ev_order_id`),
  ADD KEY `fk_ev_orders_event_types_id` (`ev_order_etype_id`),
  ADD KEY `fk_ev_orders_users_id` (`ev_order_user_id`);

--
-- Indexes for table `event_types`
--
ALTER TABLE `event_types`
  ADD PRIMARY KEY (`etype_id`);

--
-- Indexes for table `exquisite_packages`
--
ALTER TABLE `exquisite_packages`
  ADD PRIMARY KEY (`exquisite_pkg_id`),
  ADD UNIQUE KEY `exquisite_pkg_etype_id` (`exquisite_pkg_etype_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`pd_id`),
  ADD KEY `fk_pd_service_providers_id` (`pd_sp_id`),
  ADD KEY `fk_pd_service_types` (`pd_stype_id`);

--
-- Indexes for table `product_details`
--
ALTER TABLE `product_details`
  ADD PRIMARY KEY (`pd_details_id`),
  ADD KEY `fk_pd_details_products_id` (`pdetails_pd_id`),
  ADD KEY `fk_pd_details_service_providers_id` (`pdetails_sp_id`);

--
-- Indexes for table `service_providers`
--
ALTER TABLE `service_providers`
  ADD PRIMARY KEY (`sp_id`),
  ADD KEY `fk_service_types_id` (`sp_stype_id`);

--
-- Indexes for table `service_providers_addresses`
--
ALTER TABLE `service_providers_addresses`
  ADD PRIMARY KEY (`sp_addr_id`),
  ADD KEY `fk_service_providers_id` (`sp_addr_sp_id`);

--
-- Indexes for table `service_types`
--
ALTER TABLE `service_types`
  ADD PRIMARY KEY (`stype_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_addresses`
--
ALTER TABLE `user_addresses`
  ADD PRIMARY KEY (`user_addr_id`),
  ADD KEY `fk_users_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `basic_packages`
--
ALTER TABLE `basic_packages`
  MODIFY `basic_pkg_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `classic_packages`
--
ALTER TABLE `classic_packages`
  MODIFY `classic_pkg_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `event_orders`
--
ALTER TABLE `event_orders`
  MODIFY `ev_order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `event_types`
--
ALTER TABLE `event_types`
  MODIFY `etype_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `exquisite_packages`
--
ALTER TABLE `exquisite_packages`
  MODIFY `exquisite_pkg_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `pd_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `product_details`
--
ALTER TABLE `product_details`
  MODIFY `pd_details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `service_providers`
--
ALTER TABLE `service_providers`
  MODIFY `sp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `service_providers_addresses`
--
ALTER TABLE `service_providers_addresses`
  MODIFY `sp_addr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `service_types`
--
ALTER TABLE `service_types`
  MODIFY `stype_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `user_addresses`
--
ALTER TABLE `user_addresses`
  MODIFY `user_addr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `basic_packages`
--
ALTER TABLE `basic_packages`
  ADD CONSTRAINT `fk_basic_pkgs_event_types_id` FOREIGN KEY (`basic_pkg_etype_id`) REFERENCES `event_types` (`etype_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `classic_packages`
--
ALTER TABLE `classic_packages`
  ADD CONSTRAINT `fk_classic_pkgs_event_types_id` FOREIGN KEY (`classic_pkg_etype_id`) REFERENCES `event_types` (`etype_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `event_orders`
--
ALTER TABLE `event_orders`
  ADD CONSTRAINT `fk_ev_orders_event_types_id` FOREIGN KEY (`ev_order_etype_id`) REFERENCES `event_types` (`etype_id`),
  ADD CONSTRAINT `fk_ev_orders_users_id` FOREIGN KEY (`ev_order_user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `exquisite_packages`
--
ALTER TABLE `exquisite_packages`
  ADD CONSTRAINT `fk_exquisite_pkgs_event_types_id` FOREIGN KEY (`exquisite_pkg_etype_id`) REFERENCES `event_types` (`etype_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_pd_service_providers_id` FOREIGN KEY (`pd_sp_id`) REFERENCES `service_providers` (`sp_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pd_service_types` FOREIGN KEY (`pd_stype_id`) REFERENCES `service_types` (`stype_id`);

--
-- Constraints for table `product_details`
--
ALTER TABLE `product_details`
  ADD CONSTRAINT `fk_pd_details_products_id` FOREIGN KEY (`pdetails_pd_id`) REFERENCES `products` (`pd_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pd_details_service_providers_id` FOREIGN KEY (`pdetails_sp_id`) REFERENCES `service_providers` (`sp_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `service_providers`
--
ALTER TABLE `service_providers`
  ADD CONSTRAINT `fk_service_types_id` FOREIGN KEY (`sp_stype_id`) REFERENCES `service_types` (`stype_id`);

--
-- Constraints for table `service_providers_addresses`
--
ALTER TABLE `service_providers_addresses`
  ADD CONSTRAINT `fk_service_providers_id` FOREIGN KEY (`sp_addr_sp_id`) REFERENCES `service_providers` (`sp_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_addresses`
--
ALTER TABLE `user_addresses`
  ADD CONSTRAINT `fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
