document.addEventListener('DOMContentLoaded', function() {
    //SideNav
    const sideNavElems = document.querySelectorAll('.sidenav');
    M.Sidenav.init(sideNavElems, { edge: 'left' });
    //Parallax
    const parallaxElems = document.querySelectorAll('.parallax');
    M.Parallax.init(parallaxElems, {});
    //Tabs
    const tabElems = document.querySelectorAll('.tabs');
    M.Tabs.init(tabElems, { swipeable: true });
    //Collapsible
    const collapsibleElems = document.querySelectorAll('.collapsible');
    M.Collapsible.init(collapsibleElems, {});
    //Flash Message Close Functionality
    const flashMsgElem = document.getElementById('flash-msg');
    if( flashMsgElem ) {
        document.querySelector('#flash-msg').addEventListener('click', (e) => {
          if( e.target.className === 'material-icons' ) {
            document.getElementById('flash-msg').style.display = 'none';
          }
      });
    }
  });