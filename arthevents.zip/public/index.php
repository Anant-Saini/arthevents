<?php
    require_once('../app/bootstrap.php');
    //Initialize Core class
    $init = new Core();